package com.corejava.AirlineResevation;



	
import java.awt.EventQueue;
import javax.swing.JFrame;
import javax.swing.JLabel;
import java.awt.Font;

import javax.swing.AbstractButton;
import javax.swing.JButton;
import javax.swing.JOptionPane;
import javax.swing.JTextField;
import javax.swing.JRadioButton;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.Statement;
import java.util.Enumeration;

import javax.swing.ButtonGroup;

import com.mysql.jdbc.PreparedStatement;

public class PaymentDetails{

	private JFrame frame;
	private JTextField tno;
	private JTextField cname;
	private JTextField fid;
	private JTextField amt;
	private final ButtonGroup buttonGroup = new ButtonGroup();

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					PaymentDetails window = new PaymentDetails();
					window.frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the application.
	 */
	public PaymentDetails() {
		initialize();
	}

	/**
	 * Initialize the contents of the frame.
	 */
	private void initialize() {
		frame = new JFrame();
		frame.setBounds(100, 100, 700, 440);
		frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		frame.getContentPane().setLayout(null);
		
		JLabel lblPaymentDetails = new JLabel("PAYMENT DETAILS");
		lblPaymentDetails.setFont(new Font("Times New Roman", Font.BOLD, 22));
		lblPaymentDetails.setBounds(241, 18, 269, 60);
		frame.getContentPane().add(lblPaymentDetails);
		
		JLabel lblTicketNo = new JLabel("TICKET NO");
		lblTicketNo.setFont(new Font("Times New Roman", Font.BOLD, 15));
		lblTicketNo.setBounds(94, 91, 141, 14);
		frame.getContentPane().add(lblTicketNo);
		
		JLabel lblCustomerName = new JLabel("CUSTOMER NAME");
		lblCustomerName.setFont(new Font("Times New Roman", Font.BOLD, 15));
		lblCustomerName.setBounds(94, 128, 141, 14);
		frame.getContentPane().add(lblCustomerName);
		
		JLabel lblFlightId = new JLabel("FLIGHT ID");
		lblFlightId.setFont(new Font("Times New Roman", Font.BOLD, 15));
		lblFlightId.setBounds(94, 166, 141, 14);
		frame.getContentPane().add(lblFlightId);
		
		JLabel lblAmount = new JLabel("AMOUNT");
		lblAmount.setFont(new Font("Times New Roman", Font.BOLD, 15));
		lblAmount.setBounds(94, 204, 206, 14);
		frame.getContentPane().add(lblAmount);
		
		JLabel lblMode = new JLabel("MODE");
		lblMode.setFont(new Font("Times New Roman", Font.BOLD, 15));
		lblMode.setBounds(94, 242, 154, 14);
		frame.getContentPane().add(lblMode);
		
		JButton btnSave = new JButton("SAVE");
		btnSave.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				
try {
					
					Class.forName("com.mysql.jdbc.Driver");
					Connection con=DriverManager.getConnection("jdbc:mysql://localhost:3306/airline","root","root");
					Statement st=con.createStatement();
					
				
				Enumeration<AbstractButton> bg = buttonGroup.getElements();
				
				
					JRadioButton credit = (JRadioButton) bg.nextElement();
					if(credit.isSelected())
					{
					
						String sql="insert into payment(tno,cname,fid,amt,mode) values ('"+tno.getText()+"','"+cname.getText()+"','"+fid.getText()+"','"+amt.getText()+"','credit')";
						st.executeUpdate(sql);
						//CreditCardDetails c =new CreditCardDetails();
						//c.credit();
					}
					else
					{
						String sql="insert into payment(tno,cname,fid,amt,mode) values ('"+tno.getText()+"','"+cname.getText()+"','"+fid.getText()+"','"+amt.getText()+"','cash')";
						st.executeUpdate(sql);
						JOptionPane.showMessageDialog(null,"Pay amt on the counter");
						
					}
					
				}
				
				catch(Exception e)
				{
					System.out.println(e);
				}
				
			}
		});
		btnSave.setFont(new Font("Times New Roman", Font.BOLD, 13));
		btnSave.setBounds(336, 338, 89, 23);
		frame.getContentPane().add(btnSave);
		
		tno = new JTextField();
		tno.setBounds(299, 89, 197, 20);
		frame.getContentPane().add(tno);
		tno.setColumns(10);
		
		cname = new JTextField();
		cname.setBounds(299, 126, 197, 20);
		frame.getContentPane().add(cname);
		cname.setColumns(10);
		
		fid = new JTextField();
		fid.setBounds(299, 164, 197, 20);
		frame.getContentPane().add(fid);
		fid.setColumns(10);
		
		amt = new JTextField();
		amt.setBounds(299, 202, 141, 20);
		frame.getContentPane().add(amt);
		amt.setColumns(10);
		
		JRadioButton credit = new JRadioButton("Credit card");
		buttonGroup.add(credit);
		credit.setFont(new Font("Times New Roman", Font.BOLD, 11));
		credit.setBounds(299, 239, 109, 23);
		frame.getContentPane().add(credit);
		
		JRadioButton cash = new JRadioButton("Cash");
		buttonGroup.add(cash);
		cash.setFont(new Font("Times New Roman", Font.BOLD, 11));
		cash.setBounds(299, 265, 109, 23);
		frame.getContentPane().add(cash);
		
		JButton btnShow = new JButton("SHOW");
		// btnShow.addActionListener(this);
		btnShow.setFont(new Font("Times New Roman", Font.BOLD, 13));
		btnShow.setBounds(533, 88, 89, 23);
		frame.getContentPane().add(btnShow);
	}
	


	/*public void actionPerformed(ActionEvent arg0) {
		// TODO Auto-generated method stub
		Function f=new Function();
		ResultSet rs=null;
		String ctno="tno";
		String ccname="cname";
		String cfid="fid";
		String camount="amt";
		String cmode="mode";
		rs=f.Find(tno.getText());
		try{
			if(rs.next()){
				cname.setText(rs.getString("cname"));
				fid.setText(rs.getString("fid"));
				amt.setText(rs.getString("amt"));
				//mode.setText(rs.getString("mode"));
			}else{
				JOptionPane.showMessageDialog(null,"error");
			}
		}catch(Exception e){
			System.out.println(e);
		}
	}*/
	
	/*class Function{
		Connection conn=null;
		ResultSet rs=null;
		PreparedStatement ps=null;
		public ResultSet Find(String S){
			try{
				Class.forName("com.mysql.jdbc.Driver");
				Connection con=DriverManager.getConnection("jdbc:mysql://localhost:3306/airline","root","root");
				ps=(PreparedStatement) conn.prepareStatement("select * from payment where tno=?");
				ps.setString(1,S);
				rs=ps.executeQuery();
			}catch(Exception e){
				JOptionPane.showMessageDialog(null,e.getMessage());
				System.out.println(e);
			}
			return rs;
		}
		*/
	}



