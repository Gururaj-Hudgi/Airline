package airline;

import java.awt.Color;
import java.awt.Font;
import java.awt.LayoutManager;
import java.awt.SystemColor;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.text.SimpleDateFormat;
import java.util.*;
import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JProgressBar;
import javax.swing.SwingConstants;



public class WelcomeScreen extends JFrame {

	/**
	 * 
	 */
	/**
	 * 
	 */

	private JProgressBar pb;
	private JLabel clock;
	private int i=0;
	/**
	 * Launch the application.
	 */
		



	/**
	 * Create the frame.
	 */
	public WelcomeScreen() {
		
		
		setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
		
		JFrame frame = new JFrame();
		frame.setBounds(300, 100, 1350, 870);
		frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		frame.getContentPane().setLayout(null);
		getContentPane().setLayout(null);
		
		pb = new JProgressBar();
		pb.setBackground(Color.LIGHT_GRAY);
		pb.setBounds(0, 353, 782, 50);
		pb.setFont(new Font("Modern No. 20", Font.BOLD, 30));
		pb.setToolTipText("Please don't press F5 or refresh the page\r\n");
		pb.setForeground(SystemColor.textHighlight);
		pb.setValue(0);
		pb.setStringPainted(true);
		LayoutManager mgr = null;
		pb.setLayout(mgr);
		getContentPane().add(pb);
		this.setSize(800, 450);
		
		JLabel lblNewLabel = new JLabel("Loading Please wait...");
		lblNewLabel.setBounds(0, 277, 782, 50);
		lblNewLabel.setFont(new Font("Times New Roman", Font.BOLD, 26));
		lblNewLabel.setHorizontalAlignment(SwingConstants.CENTER);
		getContentPane().add(lblNewLabel);
		
		JPanel panel = new JPanel();
		panel.setForeground(Color.BLACK);
		panel.setBackground(Color.WHITE);
		panel.setBounds(0, 0, 782, 112);
		getContentPane().add(panel);
		panel.setLayout(null);
		
		JButton btnNewButton = new JButton("");
		btnNewButton.setBackground(Color.WHITE);
		btnNewButton.setSelectedIcon(new ImageIcon("C:\\Users\\lenovo\\Downloads\\T9-LOGO (1).jpeg"));
		btnNewButton.setIcon(new ImageIcon("C:\\Users\\lenovo\\Downloads\\T9-LOGO.jpeg"));
		btnNewButton.setBounds(0, 0, 137, 112);
		panel.add(btnNewButton);
		
		JLabel lblNewLabel_1 = new JLabel("T9 Airlines Pvt Ltd");
		lblNewLabel_1.setHorizontalAlignment(SwingConstants.CENTER);
		lblNewLabel_1.setFont(new Font("Times New Roman", Font.BOLD, 40));
		lblNewLabel_1.setBounds(149, 0, 621, 112);
		panel.add(lblNewLabel_1);
		
		JLabel lblNewLabel_2 = new JLabel("Welcome to T9 Airlines");
		lblNewLabel_2.setForeground(Color.RED);
		lblNewLabel_2.setFont(new Font("Algerian", Font.BOLD, 46));
		lblNewLabel_2.setHorizontalAlignment(SwingConstants.CENTER);
		lblNewLabel_2.setBounds(0, 192, 782, 50);
		getContentPane().add(lblNewLabel_2);
		
		
		
	}
	
	public void update()
	{
		for(i=0;i<=100;i++)
		{
			pb.setValue(i);
			if(i==100)
			{
				dispose();
				HomePage.HomePage();
				
				
			}
			try {
				Thread.sleep(10);
			} catch (InterruptedException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			
		}
	}
	
	public static void main(String[] args){
		
		WelcomeScreen pb = new WelcomeScreen();
		pb.setVisible(true);
		pb.update();
//                pb.showDate();
		
	}
}
