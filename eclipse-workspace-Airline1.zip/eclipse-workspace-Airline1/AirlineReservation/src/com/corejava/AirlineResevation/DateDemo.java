
//**********no use**************//

package com.corejava.AirlineResevation;

import java.awt.EventQueue;
import javax.swing.*;
import java.sql.*;

import javax.swing.JFrame;
import com.toedter.calendar.JDateChooser;
import javax.swing.JButton;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;

public class DateDemo extends javax.swing.JFrame{
	
	java.util.Date date;
	java.sql.Date sqldate;
	
	/*String host = "jdbc:mysql://localhost:3306/airline";
	String username = "root";
	String password = "root";*/
	
	
	/*public static void connection()
	{
		try{
		Class.forName("com.mysql.jdbc.Driver");
		}
		catch(Exception e){
			System.out.println(e);
		}
	}*/
	
	/*public void connection1()
	{
		try{
		connection();
		Connection con=DriverManager.getConnection("jdbc:mysql://localhost:3306/airline","root","root");
		 stmt=con.createStatement();
		}
		catch(Exception e){
			System.out.println(e);
		}
	}*/
	
	

	private JFrame frame;

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					DateDemo window = new DateDemo();
					window.frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the application.
	 */
	/*public void insert_date()
	{
		try{
			//connection1();
			Class.forName("com.mysql.jdbc.Driver");
			Connection con=DriverManager.getConnection("jdbc:mysql://localhost:3306/airline","root","root");
			Statement stmt=con.createStatement();
			date =Date.getDate();
			sqldate =new java.sql.Date(date.getTime());
			String sql="insert into cal (date) values('"+sqldate+"')";
			stmt.executeUpdate(sql);
			JOptionPane.showMessageDialog(null, "Date is inserted successfully");
			
		}
		catch(Exception e)
		{
			//System.out.println(e);
			JOptionPane.showMessageDialog(null,e);
		}
	}*/
	public DateDemo() {
		initialize();
	}

	/**
	 * Initialize the contents of the frame.
	 */
	private void initialize() {
		frame = new JFrame();
		frame.setBounds(100, 100, 811, 700);
		frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		frame.getContentPane().setLayout(null);
		
		final JDateChooser Date = new JDateChooser();
		Date.setBounds(334, 210, 100, 22);
		frame.getContentPane().add(Date);
		
		JButton btnSave = new JButton("Save");
		btnSave.addActionListener(new ActionListener() {
			public void actionPerformed(java.awt.event.ActionEvent evt) {
				PreparedStatement pst=null;
				Connection con=null;
				ResultSet rs=null;
				Statement stmt=null;
				try{
					//connection1();
					Class.forName("com.mysql.jdbc.Driver");
					con=DriverManager.getConnection("jdbc:mysql://localhost:3306/airline","root","root");
					
					stmt=con.createStatement();
					date =Date.getDate();
					sqldate =new java.sql.Date(date.getTime());
					
					String sql="insert into cal (date) values('"+sqldate+"')";
					
					pst=con.prepareStatement(sql);
					stmt.executeUpdate(sql);
					JOptionPane.showMessageDialog(null, "Date is inserted successfully");
					
				}
				catch(Exception e)
				{
					//System.out.println(e);
					JOptionPane.showMessageDialog(null,e);
				}
			}
		});
		btnSave.setBounds(245, 318, 97, 25);
		frame.getContentPane().add(btnSave);
	}
}
