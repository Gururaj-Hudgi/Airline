package airline;

import java.awt.Color;
import java.awt.EventQueue;
import java.awt.Font;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.Calendar;
import java.util.GregorianCalendar;

import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.border.BevelBorder;
import javax.swing.SwingConstants;

public class AdminMenu {

	private JFrame frame;
	private JLabel date;
	private JLabel time;
	/**
	 * Launch the application.
	 */
	public static void AdminMenu() {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					AdminMenu window = new AdminMenu();
					window.frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the application.
	 */
	
	private void clock()
	{
		
		Thread clock = new Thread()
				{
					public void run()
					{
						for(;;)
						{	
							Calendar cal=new GregorianCalendar();
							int month=cal.get(Calendar.MONTH);
							int year=cal.get(Calendar.YEAR);
							int day=cal.get(Calendar.DAY_OF_MONTH);
							date.setText("Date: "+day+"/"+month+"/"+year);
							
							int second =cal.get(Calendar.SECOND);
							int minute =cal.get(Calendar.MINUTE);
							int hour =cal.get(Calendar.HOUR);
							time.setText("Time: "+hour+":"+minute+":"+second);
							try {
								sleep(1000);
							} catch (InterruptedException e) {
								// TODO Auto-generated catch block
								e.printStackTrace();
							}
						}
					}
				};
				clock.start();
	}
	
	public AdminMenu() {
		initialize();
		clock();
	}

	/**
	 * Initialize the contents of the frame.
	 */
	private void initialize() {
		frame = new JFrame();
		frame.getContentPane().setBackground(new Color(240, 248, 255));
		frame.setBounds(300, 100, 1350, 870);
		frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		frame.getContentPane().setLayout(null);
		
		JPanel panel = new JPanel();
		panel.setBorder(new BevelBorder(BevelBorder.LOWERED, new Color(135, 206, 250), new Color(135, 206, 250), new Color(135, 206, 250), new Color(135, 206, 250)));
		panel.setBackground(new Color(211, 211, 211));
		panel.setBounds(0, 0, 1332, 85);
		frame.getContentPane().add(panel);
		panel.setLayout(null);
		
		time = new JLabel("");
		time.setHorizontalAlignment(SwingConstants.CENTER);
		time.setFont(new Font("Times New Roman", Font.BOLD, 26));
		time.setBounds(624, 24, 316, 49);
		panel.add(time);
		
		date = new JLabel("");
		date.setHorizontalAlignment(SwingConstants.CENTER);
		date.setFont(new Font("Times New Roman", Font.BOLD, 26));
		date.setBounds(294, 24, 320, 50);
		panel.add(date);
		
		JLabel lblNewLabel = new JLabel("Admin Menu");
		lblNewLabel.setIcon(new ImageIcon(AdminMenu.class.getResource("/airlineimages/admin1.png")));
		lblNewLabel.setBounds(30, 11, 202, 63);
		lblNewLabel.setBackground(new Color(176, 196, 222));
		lblNewLabel.setForeground(new Color(0, 0, 139));
		lblNewLabel.setFont(new Font("Tahoma", Font.BOLD, 24));
		panel.add(lblNewLabel);
		
		JButton btnNewButton = new JButton("Add Flight");
		btnNewButton.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				
				FlightDetails.FlightDetails();
				
			}
		});
		btnNewButton.setIcon(new ImageIcon(AdminMenu.class.getResource("/airlineimages/add1.png")));
		btnNewButton.setFont(new Font("Tahoma", Font.BOLD, 12));
		btnNewButton.setBounds(176, 278, 260, 85);
		frame.getContentPane().add(btnNewButton);
		
		JButton btnDeleteFlight = new JButton("Delete Flight");
		btnDeleteFlight.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				
				FlightDetails.FlightDetails();

			}
		});
		btnDeleteFlight.setIcon(new ImageIcon(AdminMenu.class.getResource("/airlineimages/close-icon.png")));
		btnDeleteFlight.setFont(new Font("Tahoma", Font.BOLD, 12));
		btnDeleteFlight.setBounds(871, 278, 260, 85);
		frame.getContentPane().add(btnDeleteFlight);
		
		JButton btnUpdateFlight = new JButton("Update Flight");
		btnUpdateFlight.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				
				FlightDetails.FlightDetails();

			}
		});
		btnUpdateFlight.setIcon(new ImageIcon(AdminMenu.class.getResource("/airlineimages/update.png")));
		btnUpdateFlight.setFont(new Font("Tahoma", Font.BOLD, 12));
		btnUpdateFlight.setBounds(520, 278, 260, 85);
		frame.getContentPane().add(btnUpdateFlight);
		
		JButton btnBack = new JButton("Sign Out");
		btnBack.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				airline.HomePage.HomePage();
			}
		});
		btnBack.setBackground(new Color(240, 248, 255));
		btnBack.setIcon(new ImageIcon(AdminMenu.class.getResource("/airlineimages/back1.png")));
		btnBack.setForeground(new Color(0, 0, 255));
		btnBack.setFont(new Font("Tahoma", Font.BOLD, 12));
		btnBack.setBounds(1205, 83, 127, 41);
		frame.getContentPane().add(btnBack);
		
		JLabel lblNewLabel_1 = new JLabel("Administration");
		lblNewLabel_1.setFont(new Font("Times New Roman", Font.BOLD, 26));
		lblNewLabel_1.setHorizontalAlignment(SwingConstants.CENTER);
		lblNewLabel_1.setBounds(176, 205, 955, 60);
		frame.getContentPane().add(lblNewLabel_1);
		
		JLabel lblNewLabel_2 = new JLabel("Booking and Cancel");
		lblNewLabel_2.setHorizontalAlignment(SwingConstants.CENTER);
		lblNewLabel_2.setFont(new Font("Times New Roman", Font.BOLD, 26));
		lblNewLabel_2.setBounds(176, 478, 955, 60);
		frame.getContentPane().add(lblNewLabel_2);
		
		JButton btnBooking = new JButton("Booking ");
		btnBooking.setIcon(new ImageIcon(AdminMenu.class.getResource("/airlineimages/ticketbook.png")));
		btnBooking.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				
				Booking.Booking();
			}
		});
		btnBooking.setFont(new Font("Tahoma", Font.BOLD, 12));
		btnBooking.setBounds(347, 551, 260, 85);
		frame.getContentPane().add(btnBooking);
		
		JButton btnCancel = new JButton("Cancel");
		btnCancel.setIcon(new ImageIcon(AdminMenu.class.getResource("/airlineimages/close-icon.png")));
		btnCancel.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				CancelTicket.CancelTicket();
			}
		});
		btnCancel.setFont(new Font("Tahoma", Font.BOLD, 12));
		btnCancel.setBounds(691, 551, 260, 85);
		frame.getContentPane().add(btnCancel);
	}
}
