package airline;

import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.JLabel;
import javax.swing.JOptionPane;

import java.awt.Font;
import java.awt.Color;
import javax.swing.border.BevelBorder;
import javax.swing.JTextField;
import javax.swing.JComboBox;
import javax.swing.DefaultComboBoxModel;

import com.teknikindustries.bulksms.SMS;
import com.toedter.calendar.JDateChooser;
import javax.swing.JButton;
import javax.swing.ImageIcon;
import java.awt.event.ActionListener;
import java.util.Calendar;
import java.util.GregorianCalendar;
import java.awt.event.ActionEvent;
import javax.swing.GroupLayout;
import javax.swing.GroupLayout.Alignment;
import javax.swing.LayoutStyle.ComponentPlacement;
import javax.swing.SwingConstants;

public class CreditCardDetails {

	private JFrame frame;
	private JTextField cardno;
	private JTextField hname;
	private JLabel ddate;
	private JLabel dtime;
	/**
	 * Launch the application.
	 */
	public static void CreditCardDetails() {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					CreditCardDetails window = new CreditCardDetails();
					window.frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the application.
	 */
	
	private void clock()
	{
		
		Thread clock = new Thread()
				{
					public void run()
					{
						for(;;)
						{	
							Calendar cal=new GregorianCalendar();
							int month=cal.get(Calendar.MONTH)+1;
							int year=cal.get(Calendar.YEAR);
							int day=cal.get(Calendar.DAY_OF_MONTH);
							ddate.setText("Date: "+day+"/"+month+"/"+year);
							
							int second =cal.get(Calendar.SECOND);
							int minute =cal.get(Calendar.MINUTE);
							int hour =cal.get(Calendar.HOUR_OF_DAY);
							dtime.setText("Time: "+hour+":"+minute+":"+second);
							try {
								sleep(1000);
							} catch (InterruptedException e) {
								// TODO Auto-generated catch block
								e.printStackTrace();
							}
						}
					}
				};
				clock.start();
	}
	
	
	public CreditCardDetails() {
		initialize();
		clock();
	}

	/**
	 * Initialize the contents of the frame.
	 */
	private void initialize() {
		frame = new JFrame();
		frame.getContentPane().setFont(new Font("Tahoma", Font.BOLD, 12));
		frame.getContentPane().setBackground(new Color(240, 248, 255));
		frame.setBounds(300, 100, 1350, 870);
		frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		
		JPanel panel = new JPanel();
		panel.setBounds(0, 0, 1332, 67);
		panel.setBorder(new BevelBorder(BevelBorder.LOWERED, new Color(135, 206, 250), new Color(135, 206, 250), new Color(135, 206, 250), new Color(135, 206, 250)));
		panel.setBackground(new Color(211,211,211));
		
		dtime = new JLabel("");
		dtime.setBounds(742, 11, 316, 49);
		dtime.setHorizontalAlignment(SwingConstants.CENTER);
		dtime.setFont(new Font("Times New Roman", Font.BOLD, 26));
		
		ddate = new JLabel("");
		ddate.setBounds(412, 11, 320, 50);
		ddate.setHorizontalAlignment(SwingConstants.CENTER);
		ddate.setFont(new Font("Times New Roman", Font.BOLD, 26));
		
		JLabel lblCreditCardDetails = new JLabel("  Credit Card Details");
		lblCreditCardDetails.setBounds(27, 11, 364, 56);
		lblCreditCardDetails.setIcon(new ImageIcon(CreditCardDetails.class.getResource("/airlineimages/credit1.png")));
		lblCreditCardDetails.setFont(new Font("Tahoma", Font.BOLD, 30));
		
		JLabel lblCardNumber = new JLabel("Card Number");
		lblCardNumber.setBounds(255, 176, 174, 37);
		lblCardNumber.setFont(new Font("Times New Roman", Font.BOLD, 24));
		
		cardno = new JTextField();
		cardno.setBounds(553, 182, 265, 31);
		cardno.setColumns(10);
		
		JLabel lblCardType = new JLabel("Card Type");
		lblCardType.setBounds(255, 312, 157, 42);
		lblCardType.setFont(new Font("Times New Roman", Font.BOLD, 24));
		
		JComboBox ctype = new JComboBox();
		ctype.setBounds(553, 306, 265, 22);
		ctype.setModel(new DefaultComboBoxModel(new String[] {"Credit Card", "Rupay/Debit", "Master", "Platinum"}));
		
		JLabel lblHolderName = new JLabel("Holder Name");
		lblHolderName.setBounds(255, 423, 157, 47);
		lblHolderName.setFont(new Font("Times New Roman", Font.BOLD, 24));
		
		hname = new JTextField();
		hname.setBounds(553, 438, 265, 22);
		hname.setColumns(10);
		
		JLabel lblExpiryDate = new JLabel("Expiry Date");
		lblExpiryDate.setBounds(255, 545, 157, 48);
		lblExpiryDate.setFont(new Font("Times New Roman", Font.BOLD, 24));
		
		JDateChooser date = new JDateChooser();
		date.setBounds(553, 556, 265, 22);
		
		JButton btnSubmit = new JButton("Submit");
		btnSubmit.setBounds(461, 633, 128, 51);
		btnSubmit.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				JOptionPane.showMessageDialog(null,"Congratulations!!!\n Your Ticket is reserved successfully\n");
				UserMenu.UserMenu();
				
			}
		});
		btnSubmit.setFont(new Font("Tahoma", Font.BOLD, 12));
		
		JButton button = new JButton("");
		button.setBounds(0, 782, 65, 41);
		button.setIcon(new ImageIcon(CreditCardDetails.class.getResource("/airlineimages/back1.png")));
		frame.getContentPane().setLayout(null);
		frame.getContentPane().add(lblHolderName);
		frame.getContentPane().add(lblCardType);
		frame.getContentPane().add(lblCardNumber);
		frame.getContentPane().add(lblExpiryDate);
		frame.getContentPane().add(hname);
		frame.getContentPane().add(date);
		frame.getContentPane().add(ctype);
		frame.getContentPane().add(cardno);
		frame.getContentPane().add(panel);
		panel.setLayout(null);
		panel.add(lblCreditCardDetails);
		panel.add(ddate);
		panel.add(dtime);
		frame.getContentPane().add(button);
		frame.getContentPane().add(btnSubmit);
	}
}
