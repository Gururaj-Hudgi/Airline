//************no use***************//


package com.corejava.AirlineResevation;




	import java.awt.EventQueue;

	import javax.swing.JFrame;
	import javax.swing.JLabel;
	import java.awt.BorderLayout;
	import java.awt.Font;
	import javax.swing.JTextField;
	import javax.swing.JRadioButton;
	import javax.swing.JComboBox;
	import javax.swing.JButton;
import java.awt.Color;

	public class UpdateCust {

		private JFrame frame;
		private JTextField textField;
		private JTextField textField_1;
		private JTextField textField_2;
		private JTextField textField_3;

		/**
		 * Launch the application.
		 */
		public static void main(String[] args) {
			EventQueue.invokeLater(new Runnable() {
				public void run() {
					try {
						UpdateCust window = new UpdateCust();
						window.frame.setVisible(true);
					} catch (Exception e) {
						e.printStackTrace();
					}
				}
			});
		}

		/**
		 * Create the application.
		 */
		public UpdateCust() {
			initialize();
		}

		/**
		 * Initialize the contents of the frame.
		 */
		private void initialize() {
			frame = new JFrame();
			frame.getContentPane().setBackground(Color.WHITE);
			frame.setBounds(100, 100, 822, 503);
			frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
			frame.getContentPane().setLayout(null);
			
			JLabel lblUpdateCustomer = new JLabel("UPDATE CUSTOMER");
			lblUpdateCustomer.setFont(new Font("Times New Roman", Font.BOLD, 22));
			lblUpdateCustomer.setBounds(228, 11, 250, 47);
			frame.getContentPane().add(lblUpdateCustomer);
			
			JLabel lblCustomerId = new JLabel("CUSTOMER ID");
			lblCustomerId.setFont(new Font("Times New Roman", Font.PLAIN, 15));
			lblCustomerId.setBounds(100, 69, 134, 14);
			frame.getContentPane().add(lblCustomerId);
			
			JLabel lblNewLabel = new JLabel("CUSTOMER NAME");
			lblNewLabel.setFont(new Font("Times New Roman", Font.PLAIN, 15));
			lblNewLabel.setBounds(100, 106, 150, 14);
			frame.getContentPane().add(lblNewLabel);
			
			JLabel lblGender = new JLabel("GENDER");
			lblGender.setFont(new Font("Times New Roman", Font.PLAIN, 15));
			lblGender.setBounds(100, 143, 107, 14);
			frame.getContentPane().add(lblGender);
			
			JLabel lblDob = new JLabel("DOB");
			lblDob.setFont(new Font("Times New Roman", Font.PLAIN, 15));
			lblDob.setBounds(100, 185, 72, 14);
			frame.getContentPane().add(lblDob);
			
			JLabel lblPhoneNo = new JLabel("PHONE NO.");
			lblPhoneNo.setFont(new Font("Times New Roman", Font.PLAIN, 15));
			lblPhoneNo.setBounds(100, 233, 96, 14);
			frame.getContentPane().add(lblPhoneNo);
			
			JLabel lblAddress = new JLabel("ADDRESS");
			lblAddress.setFont(new Font("Times New Roman", Font.PLAIN, 15));
			lblAddress.setBounds(100, 268, 84, 14);
			frame.getContentPane().add(lblAddress);
			
			textField = new JTextField();
			textField.setBounds(292, 69, 196, 20);
			frame.getContentPane().add(textField);
			textField.setColumns(10);
			
			textField_1 = new JTextField();
			textField_1.setBounds(292, 104, 196, 20);
			frame.getContentPane().add(textField_1);
			textField_1.setColumns(10);
			
			JRadioButton rdbtnMale = new JRadioButton("MALE");
			rdbtnMale.setFont(new Font("Times New Roman", Font.PLAIN, 13));
			rdbtnMale.setBounds(292, 140, 72, 23);
			frame.getContentPane().add(rdbtnMale);
			
			JRadioButton rdbtnFemale = new JRadioButton("FEMALE");
			rdbtnFemale.setFont(new Font("Times New Roman", Font.PLAIN, 13));
			rdbtnFemale.setBounds(366, 140, 109, 23);
			frame.getContentPane().add(rdbtnFemale);
			
			JComboBox comboBox = new JComboBox();
			comboBox.setEditable(true);
			comboBox.setBounds(292, 183, 53, 20);
			frame.getContentPane().add(comboBox);
			
			JComboBox comboBox_1 = new JComboBox();
			comboBox_1.setEditable(true);
			comboBox_1.setBounds(355, 183, 53, 20);
			frame.getContentPane().add(comboBox_1);
			
			JComboBox comboBox_2 = new JComboBox();
			comboBox_2.setEditable(true);
			comboBox_2.setBounds(418, 183, 60, 20);
			frame.getContentPane().add(comboBox_2);
			
			textField_2 = new JTextField();
			textField_2.setBounds(292, 230, 186, 20);
			frame.getContentPane().add(textField_2);
			textField_2.setColumns(10);
			
			textField_3 = new JTextField();
			textField_3.setBounds(292, 268, 186, 77);
			frame.getContentPane().add(textField_3);
			textField_3.setColumns(10);
			
			JButton btnSearch = new JButton("SEARCH");
			btnSearch.setFont(new Font("Times New Roman", Font.PLAIN, 15));
			btnSearch.setBounds(549, 66, 107, 23);
			frame.getContentPane().add(btnSearch);
			
			JButton btnUpdate = new JButton("UPDATE");
			btnUpdate.setFont(new Font("Times New Roman", Font.PLAIN, 15));
			btnUpdate.setBounds(221, 387, 96, 36);
			frame.getContentPane().add(btnUpdate);
			
			JButton btnDelete = new JButton("DELETE");
			btnDelete.setFont(new Font("Times New Roman", Font.PLAIN, 15));
			btnDelete.setBounds(366, 387, 96, 36);
			frame.getContentPane().add(btnDelete);
		}

	}



