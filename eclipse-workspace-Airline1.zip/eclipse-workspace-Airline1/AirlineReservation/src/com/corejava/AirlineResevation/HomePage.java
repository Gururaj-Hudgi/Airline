package com.corejava.AirlineResevation;

import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.JLabel;
import com.jgoodies.forms.factories.DefaultComponentFactory;
import java.awt.Font;
import java.awt.Color;
import javax.swing.JTextField;
import javax.swing.JButton;

public class HomePage {

	private JFrame frame;

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					HomePage window = new HomePage();
					window.frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the application.
	 */
	public HomePage() {
		initialize();
	}

	/**
	 * Initialize the contents of the frame.
	 */
	private void initialize() {
		frame = new JFrame();
		frame.getContentPane().setBackground(Color.WHITE);
		frame.setBounds(100, 100, 767, 510);
		frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		frame.getContentPane().setLayout(null);
		
		JPanel panel = new JPanel();
		panel.setBackground(Color.WHITE);
		panel.setBounds(12, 0, 725, 141);
		frame.getContentPane().add(panel);
		panel.setLayout(null);
		
		JLabel lblAirliineReservation = DefaultComponentFactory.getInstance().createTitle("AIRLIINE RESERVATION");
		lblAirliineReservation.setFont(new Font("Times New Roman", Font.BOLD, 22));
		lblAirliineReservation.setBounds(255, 39, 268, 46);
		panel.add(lblAirliineReservation);
		
		JPanel panel_1 = new JPanel();
		panel_1.setBackground(Color.WHITE);
		panel_1.setBounds(12, 143, 725, 309);
		frame.getContentPane().add(panel_1);
		panel_1.setLayout(null);
		
		JButton btnAdminLogin = new JButton("ADMIN LOGIN");
		btnAdminLogin.setBounds(137, 58, 128, 37);
		panel_1.add(btnAdminLogin);
		
		JButton btnUserLogin = new JButton("USER LOGIN");
		btnUserLogin.setBounds(137, 138, 128, 37);
		panel_1.add(btnUserLogin);
		
		JButton btnRegistration = new JButton("REGISTRATION");
		btnRegistration.setBounds(137, 208, 128, 37);
		panel_1.add(btnRegistration);
	}
}
