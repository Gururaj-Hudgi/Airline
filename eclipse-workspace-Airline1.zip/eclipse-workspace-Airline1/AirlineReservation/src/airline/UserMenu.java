package airline;

import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.JLabel;
import java.awt.Font;
import javax.swing.ImageIcon;
import java.awt.Color;
import javax.swing.border.BevelBorder;

import com.corejava.AirlineResevation.BookTicket;

import javax.swing.JButton;
import java.awt.event.ActionListener;
import java.awt.print.Book;
import java.util.Calendar;
import java.util.GregorianCalendar;
import java.awt.event.ActionEvent;
import javax.swing.SwingConstants;

public class UserMenu {

	private JFrame frame;
	private JButton btnBack;
	private JLabel ddate;
	private JLabel dtime;
	/**
	 * Launch the application.
	 */
	public static void UserMenu() {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					UserMenu window = new UserMenu();
					window.frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the application.
	 */
	
	
	private void clock()
	{
		
		Thread clock = new Thread()
				{
					public void run()
					{
						for(;;)
						{	
							Calendar cal=new GregorianCalendar();
							int month=cal.get(Calendar.MONTH)+1;
							int year=cal.get(Calendar.YEAR);
							int day=cal.get(Calendar.DAY_OF_MONTH);
							ddate.setText("Date: "+day+"/"+month+"/"+year);
							
							int second =cal.get(Calendar.SECOND);
							int minute =cal.get(Calendar.MINUTE);
							int hour =cal.get(Calendar.HOUR_OF_DAY);
							dtime.setText("Time: "+hour+":"+minute+":"+second);
							try {
								sleep(1000);
							} catch (InterruptedException e) {
								// TODO Auto-generated catch block
								e.printStackTrace();
							}
						}
					}
				};
				clock.start();
	}
	public UserMenu() {
		initialize();
		clock();
	}

	/**
	 * Initialize the contents of the frame.
	 */
	private void initialize() {
		frame = new JFrame();
		frame.getContentPane().setBackground(new Color(240, 248, 255));
		frame.setBounds(500, 300, 754, 492);
		frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		frame.getContentPane().setLayout(null);
		
		JPanel panel = new JPanel();
		panel.setBorder(new BevelBorder(BevelBorder.LOWERED, new Color(175, 238, 238), new Color(175, 238, 238), new Color(176, 224, 230), new Color(176, 224, 230)));
		panel.setBackground(new Color(211, 211, 211));
		panel.setBounds(0, 0, 744, 76);
		frame.getContentPane().add(panel);
		panel.setLayout(null);
		
		JLabel lblUserMenu = new JLabel("  User Menu");
		lblUserMenu.setHorizontalAlignment(SwingConstants.CENTER);
		lblUserMenu.setIcon(new ImageIcon(UserMenu.class.getResource("/airlineimages/usermenu.png")));
		lblUserMenu.setFont(new Font("Tahoma", Font.BOLD, 29));
		lblUserMenu.setBounds(12, 13, 238, 54);
		panel.add(lblUserMenu);
		
		ddate = new JLabel("");
		ddate.setHorizontalAlignment(SwingConstants.CENTER);
		ddate.setFont(new Font("Times New Roman", Font.BOLD, 26));
		ddate.setBounds(279, 13, 197, 50);
		panel.add(ddate);
		
		dtime = new JLabel("");
		dtime.setHorizontalAlignment(SwingConstants.CENTER);
		dtime.setFont(new Font("Times New Roman", Font.BOLD, 26));
		dtime.setBounds(484, 13, 197, 49);
		panel.add(dtime);
		
		JButton btnBookTicket = new JButton("Book Ticket");
		btnBookTicket.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				
				Booking.Booking();
			}
		});
		btnBookTicket.setBackground(new Color(255, 255, 255));
		btnBookTicket.setFont(new Font("Tahoma", Font.BOLD, 12));
		btnBookTicket.setIcon(new ImageIcon(UserMenu.class.getResource("/airlineimages/ticketbook.png")));
		btnBookTicket.setBounds(289, 213, 178, 57);
		frame.getContentPane().add(btnBookTicket);
		
		JButton btnNewButton = new JButton("Cancel Ticket");
		btnNewButton.setBackground(new Color(255, 255, 255));
		btnNewButton.setFont(new Font("Tahoma", Font.BOLD, 12));
		btnNewButton.setIcon(new ImageIcon(UserMenu.class.getResource("/airlineimages/delete.png")));
		btnNewButton.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
			
				CancelTicket.CancelTicket();
			}
		});
		btnNewButton.setBounds(289, 312, 178, 57);
		frame.getContentPane().add(btnNewButton);
		
		btnBack = new JButton("LogOut");
		btnBack.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				
				UserLogin.UserLogin();
			}
		});
		btnBack.setFont(new Font("Sitka Banner", Font.BOLD, 20));
		btnBack.setIcon(new ImageIcon(UserLogin.class.getResource("/airlineimages/back1.png")));
		btnBack.setBounds(590, 76, 152, 41);
		frame.getContentPane().add(btnBack);
	}
}
