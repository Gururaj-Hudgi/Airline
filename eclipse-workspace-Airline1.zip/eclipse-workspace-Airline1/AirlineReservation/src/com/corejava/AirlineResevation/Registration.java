package com.corejava.AirlineResevation;

import java.awt.Color;
import java.awt.EventQueue;
import java.awt.Font;

import javax.swing.AbstractButton;
import javax.swing.JButton;
import javax.swing.JComboBox;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JRadioButton;
import javax.swing.JTextField;
import javax.swing.border.BevelBorder;

import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.Statement;
import java.util.Enumeration;
import javax.swing.ButtonGroup;
import javax.swing.ImageIcon;
import javax.swing.JPasswordField;
import com.toedter.calendar.JDateChooser;

//import airline.Registration;

public class Registration {
	
	java.util.Date date;
	java.sql.Date sqldate;
	
	
	private JFrame frame;
	private JTextField cname;
	private JTextField phno;
	private JTextField address;
	private final ButtonGroup buttonGroup = new ButtonGroup();
	private JPasswordField upass;

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					Registration window = new Registration();
					window.frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the application.
	 */
	public Registration() {
		initialize();
	}

	/**
	 * Initialize the contents of the frame.
	 */
	private void initialize() {
		frame = new JFrame();
		frame.getContentPane().setBackground(new Color(240, 248, 255));
		frame.setBounds(100, 100, 760, 460);
		frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		frame.getContentPane().setLayout(null);
		
		JPanel panel = new JPanel();
		panel.setBorder(new BevelBorder(BevelBorder.LOWERED, new Color(175, 238, 238), new Color(175, 238, 238), new Color(176, 224, 230), new Color(176, 224, 230)));
		panel.setBackground(new Color(211, 211, 211));
		panel.setBounds(0, 0, 742, 74);
		frame.getContentPane().add(panel);
		panel.setLayout(null);
		
		JLabel lblRegistration = new JLabel("  Registration");
		//lblRegistration.setIcon(new ImageIcon(Registration.class.getResource("/airlineimages/regi.png")));
		lblRegistration.setFont(new Font("Tahoma", Font.BOLD, 30));
		lblRegistration.setBounds(23, 11, 286, 50);
		panel.add(lblRegistration);
		
		JLabel lblCostumerName = new JLabel("Costumer Name");
		lblCostumerName.setFont(new Font("Times New Roman", Font.BOLD, 20));
		lblCostumerName.setBounds(35, 84, 144, 22);
		frame.getContentPane().add(lblCostumerName);
		
		cname = new JTextField();
		cname.setBounds(303, 87, 220, 20);
		frame.getContentPane().add(cname);
		cname.setColumns(10);
		
		JLabel lblGender = new JLabel("Gender");
		lblGender.setFont(new Font("Times New Roman", Font.BOLD, 20));
		lblGender.setBounds(35, 150, 144, 14);
		frame.getContentPane().add(lblGender);
		
		JRadioButton male = new JRadioButton("Male");
		male.setFont(new Font("Tahoma", Font.BOLD, 12));
		male.setBounds(303, 146, 102, 23);
		frame.getContentPane().add(male);
		
		JRadioButton female = new JRadioButton("Female");
		female.setFont(new Font("Tahoma", Font.BOLD, 12));
		female.setBounds(421, 146, 102, 23);
		frame.getContentPane().add(female);
		
		JLabel lblDateOfBirth = new JLabel("Date Of Birth");
		lblDateOfBirth.setFont(new Font("Times New Roman", Font.BOLD, 20));
		lblDateOfBirth.setBounds(35, 191, 144, 14);
		frame.getContentPane().add(lblDateOfBirth);
		
		final JDateChooser Date = new JDateChooser();
		Date.setBounds(303, 184, 220, 20);
		frame.getContentPane().add(Date);
		
		JLabel lblPhoneNo = new JLabel("Phone No.");
		lblPhoneNo.setFont(new Font("Times New Roman", Font.BOLD, 20));
		lblPhoneNo.setBounds(35, 227, 144, 14);
		frame.getContentPane().add(lblPhoneNo);
		
		phno = new JTextField();
		phno.setBounds(303, 223, 220, 20);
		frame.getContentPane().add(phno);
		phno.setColumns(10);
		
		JLabel lblAddress = new JLabel("Address");
		lblAddress.setFont(new Font("Times New Roman", Font.BOLD, 20));
		lblAddress.setBounds(35, 266, 144, 14);
		frame.getContentPane().add(lblAddress);
		
		address = new JTextField();
		address.setBounds(303, 262, 220, 69);
		frame.getContentPane().add(address);
		address.setColumns(10);
		
		JLabel lblPassword = new JLabel("Password");
		lblPassword.setFont(new Font("Times New Roman", Font.BOLD, 20));
		lblPassword.setBounds(35, 123, 144, 14);
		frame.getContentPane().add(lblPassword);
		
		upass = new JPasswordField();
		upass.setBounds(303, 120, 220, 20);
		frame.getContentPane().add(upass);
		
		JButton btnSubmit = new JButton("SUBMIT");
		btnSubmit.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				
				PreparedStatement pst=null;
				Connection con=null;
				ResultSet rs=null;
				Statement stmt=null;
				
try {
					
					Class.forName("com.mysql.jdbc.Driver");
					con=DriverManager.getConnection("jdbc:mysql://localhost:3306/airline","root","root");
					stmt=con.createStatement();
					date =Date.getDate();
					sqldate =new java.sql.Date(date.getTime());
					
				
				Enumeration<AbstractButton> bg = buttonGroup.getElements();
				
				
					JRadioButton rdbtnMale = (JRadioButton) bg.nextElement();
					if(rdbtnMale.isSelected())
					{
					
						String sql="insert into NewRegistration(cname,upass,gender,Date,phno,address) values ('"+cname.getText()+"','"+upass.getText()+"','male','"+sqldate+"','"+phno.getText()+"','"+address.getText()+"')";
						stmt.executeUpdate(sql);
					}
					else
					{
						String sql="insert into NewRegistration(cname,upass,gender,Date,phno,address) values ('"+cname.getText()+"','"+upass.getText()+"','female','"+sqldate+"','"+phno.getText()+"','"+address.getText()+"')";
						stmt.executeUpdate(sql);
					}
					
					JOptionPane.showMessageDialog(null,"Registered sucessfully");
					
				}
				
				catch(Exception e)
				{
					System.out.println(e);
				}
				
			}
		});
		btnSubmit.setFont(new Font("Times New Roman", Font.PLAIN, 15));
		btnSubmit.setBounds(224, 388, 96, 36);
		frame.getContentPane().add(btnSubmit);
		
//		upass = new JPasswordField();
//		upass.setBounds(292, 102, 196, 22);
//		frame.getContentPane().add(upass);
		
		
	}
}
