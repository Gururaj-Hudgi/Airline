////////////*no use **//////////////**************



package com.corejava.AirlineResevation;

import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.JLabel;
import java.awt.Font;

import javax.swing.JOptionPane;
import javax.swing.JTextField;
import javax.swing.JList;
import javax.swing.JComboBox;
import javax.swing.JSpinner;
import javax.swing.JButton;
import java.awt.Color;
import javax.swing.DefaultComboBoxModel;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.Statement;
import com.toedter.calendar.JCalendar;
import com.toedter.calendar.demo.BirthdayEvaluator;
import com.toedter.calendar.demo.JCalendarDemo;
import com.toedter.calendar.JDateChooser;

public class Credit extends javax.swing.JFrame{
	
	java.util.Date date;
	java.sql.Date sqldate;
	
	private JFrame frame;
	private JTextField tno;
	private JTextField cardno;
	private JTextField hname;
	private JTextField bname;
	//private JDateChooser Date;
	
	

	/**
	 * Launch the application.
	 */
	public static void main(String args[]) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					Credit window = new Credit();
					window.frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the application.
	 */
	public Credit() {
		initialize();
	}

	/**
	 * Initialize the contents of the frame.
	 */
	private void initialize() {
		frame = new JFrame();
		frame.setBounds(100, 100, 1196, 720);
		frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		frame.getContentPane().setLayout(null);
		
		JPanel panel = new JPanel();
		panel.setBackground(Color.WHITE);
		panel.setBounds(0, 0, 1178, 131);
		frame.getContentPane().add(panel);
		panel.setLayout(null);
		
		JLabel lblCreditCardDetails = new JLabel("Credit Card Details");
		lblCreditCardDetails.setFont(new Font("Times New Roman", Font.BOLD, 22));
		lblCreditCardDetails.setBounds(421, 39, 271, 42);
		panel.add(lblCreditCardDetails);
		
		JPanel panel_1 = new JPanel();
		panel_1.setBackground(Color.WHITE);
		panel_1.setBounds(0, 129, 1178, 546);
		frame.getContentPane().add(panel_1);
		panel_1.setLayout(null);
		
		JLabel lblTicketNo = new JLabel("Ticket No.");
		lblTicketNo.setFont(new Font("Times New Roman", Font.PLAIN, 15));
		lblTicketNo.setBounds(227, 30, 76, 16);
		panel_1.add(lblTicketNo);
		
		JLabel lblCardNo = new JLabel("Card No.");
		lblCardNo.setFont(new Font("Times New Roman", Font.PLAIN, 15));
		lblCardNo.setBounds(227, 73, 76, 16);
		panel_1.add(lblCardNo);
		
		JLabel lblCardType = new JLabel("Card Type");
		lblCardType.setFont(new Font("Times New Roman", Font.PLAIN, 15));
		lblCardType.setBounds(227, 117, 76, 16);
		panel_1.add(lblCardType);
		
		JLabel lblHolderName = new JLabel("Holder Name");
		lblHolderName.setFont(new Font("Times New Roman", Font.PLAIN, 15));
		lblHolderName.setBounds(227, 156, 89, 16);
		panel_1.add(lblHolderName);
		
		JLabel lblExpiryDate = new JLabel("Expiry Date");
		lblExpiryDate.setFont(new Font("Times New Roman", Font.PLAIN, 15));
		lblExpiryDate.setBounds(227, 189, 76, 16);
		panel_1.add(lblExpiryDate);
		
		JLabel lblBankName = new JLabel("Bank Name");
		lblBankName.setFont(new Font("Times New Roman", Font.PLAIN, 15));
		lblBankName.setBounds(227, 230, 76, 16);
		panel_1.add(lblBankName);
		
		tno = new JTextField();
		tno.setBounds(483, 27, 116, 22);
		panel_1.add(tno);
		tno.setColumns(10);
		
		cardno = new JTextField();
		cardno.setBounds(483, 70, 116, 22);
		panel_1.add(cardno);
		cardno.setColumns(10);
		
		final JComboBox ctype = new JComboBox();
		ctype.setModel(new DefaultComboBoxModel(new String[] {"Master Card", "Rupay ", "Visa", "Platinum"}));
		ctype.setBounds(483, 114, 116, 22);
		panel_1.add(ctype);
		
		hname = new JTextField();
		hname.setBounds(483, 156, 116, 22);
		panel_1.add(hname);
		hname.setColumns(10);
		
		final JDateChooser Date = new JDateChooser();
		Date.setBounds(483, 192, 116, 22);
		panel_1.add(Date);
		
		bname = new JTextField();
		bname.setBounds(483, 227, 116, 22);
		panel_1.add(bname);
		bname.setColumns(10);
		
		JButton btnSubmit = new JButton("SUBMIT");
		btnSubmit.addActionListener(new ActionListener() {
			public void actionPerformed(java.awt.event.ActionEvent evt) {
				
				PreparedStatement pst=null;
				Connection con=null;
				ResultSet rs=null;
				Statement stmt=null;
				
				try{
					Class.forName("com.mysql.jdbc.Driver");
					con=DriverManager.getConnection("jdbc:mysql://localhost:3306/airline","root","root");
					
					stmt=con.createStatement();
					date =Date.getDate();
					sqldate =new java.sql.Date(date.getTime());
					
					String sql="insert into creditcard(tno,cardno,ctype,hname,Date,bname)values('"+tno.getText()+"','"+cardno.getText()+"','"+ctype.getSelectedItem().toString()+"','"+hname.getText()+"','"+sqldate+"','"+bname.getText()+"')";
			
					pst=con.prepareStatement(sql);
					stmt.executeUpdate(sql);
					JOptionPane.showMessageDialog(null,"Payment successfull");
	
					
					
					
					
					/*if(rs.next())
						JOptionPane.showMessageDialog(null,"Registered Sucessfully...");
						else
							JOptionPane.showMessageDialog(null,"Fill proper data");*/
					//con.close();
					
				}
				catch(Exception e){
					System.out.println(e);
					//JOptionPane.showMessageDialog(null,e);
					
				}
			}
		});
		btnSubmit.setBounds(376, 332, 114, 41);
		panel_1.add(btnSubmit);
		
		
	}
}
