package airline;

import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.print.attribute.standard.Destination;
import javax.swing.ImageIcon;
import java.awt.Font;
import java.awt.Color;
import javax.swing.border.BevelBorder;
import javax.swing.JButton;
import javax.swing.JTextField;
import java.awt.event.ActionListener;
import java.sql.*;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.Calendar;
import java.util.GregorianCalendar;
import java.awt.event.ActionEvent;
import javax.swing.SwingConstants;

public class FlightDetails {

	private JFrame frame;
	private JTextField fid;
	private JTextField fname;
	private JTextField source;
	private JTextField departure;
	private JTextField nobc;
	private JTextField dest;
	private JTextField prbc;
	private JTextField at;
	private ResultSet rs ;
    private PreparedStatement ps;
    private JTextField nofc;
    private JTextField prfc;
    private JTextField noec;
    private JTextField prec;
    java.util.Date date;
	java.sql.Date sqldate;
	java.sql.Time sqltime;
	private int ts;
	private JLabel ddate;
	private JLabel time;
	/**
	 * Launch the application.
	 * @throws SQLException 
	 */
	

	
	private void getValues() 
    {
		try {
			fname.setText(rs.getString("fname"));
			source.setText(rs.getString("source"));
	        departure.setText(rs.getString("dt"));            
	        dest.setText(rs.getString("dest"));
	        at.setText(rs.getString("at"));
	        nobc.setText(rs.getString("nobc"));
	        prbc.setText(rs.getString("prbc"));
	        nofc.setText(rs.getString("nofc"));
	        prfc.setText(rs.getString("prfc"));
	        noec.setText(rs.getString("noec"));
	        prec.setText(rs.getString("prec"));
	        
		} 
		catch(Exception e)
		{
			System.out.println(e);
			}	
    }
	
	
	public static void FlightDetails() {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					FlightDetails window = new FlightDetails();
					window.frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the application.
	 */
	
	private void clock()
	{
		
		Thread clock = new Thread()
				{
					public void run()
					{
						for(;;)
						{	
							Calendar cal=new GregorianCalendar();
							int month=cal.get(Calendar.MONTH)+1;
							int year=cal.get(Calendar.YEAR);
							int day=cal.get(Calendar.DAY_OF_MONTH);
							ddate.setText("Date: "+day+"/"+month+"/"+year);
							
							int second =cal.get(Calendar.SECOND);
							int minute =cal.get(Calendar.MINUTE);
							int hour =cal.get(Calendar.HOUR_OF_DAY);
							time.setText("Time: "+hour+":"+minute+":"+second);
							try {
								sleep(1000);
							} catch (InterruptedException e) {
								// TODO Auto-generated catch block
								e.printStackTrace();
							}
						}
					}
				};
				clock.start();
	}
	public FlightDetails() {
		initialize();
		clock();
	}

	/**
	 * Initialize the contents of the frame.
	 */
	private void initialize() {
		frame = new JFrame();
		frame.getContentPane().setBackground(new Color(240, 248, 255));
		frame.setBounds(300, 100, 1350, 870);
		frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		frame.getContentPane().setLayout(null);
		
		JPanel panel = new JPanel();
		panel.setBorder(new BevelBorder(BevelBorder.LOWERED, new Color(135, 206, 250), new Color(135, 206, 250), new Color(135, 206, 250), new Color(135, 206, 250)));
		panel.setBackground(new Color(211, 211, 211));
		panel.setBounds(0, 0, 1332, 80);
		frame.getContentPane().add(panel);
		panel.setLayout(null);
		
		JLabel lblFlightDetails = new JLabel("Flight Details");
		lblFlightDetails.setFont(new Font("Tahoma", Font.BOLD, 30));
		lblFlightDetails.setIcon(new ImageIcon(FlightDetails.class.getResource("/airlineimages/flight.png")));
		lblFlightDetails.setBounds(10, 11, 286, 58);
		panel.add(lblFlightDetails);
		
		ddate = new JLabel("");
		ddate.setHorizontalAlignment(SwingConstants.CENTER);
		ddate.setFont(new Font("Times New Roman", Font.BOLD, 26));
		ddate.setBounds(308, 11, 320, 50);
		panel.add(ddate);
		
		time = new JLabel("");
		time.setHorizontalAlignment(SwingConstants.CENTER);
		time.setFont(new Font("Times New Roman", Font.BOLD, 26));
		time.setBounds(638, 11, 316, 49);
		panel.add(time);
		
		JLabel lblFlightId = new JLabel("Flight ID");
		lblFlightId.setHorizontalAlignment(SwingConstants.CENTER);
		lblFlightId.setFont(new Font("Times New Roman", Font.BOLD, 18));
		lblFlightId.setBounds(271, 244, 119, 40);
		frame.getContentPane().add(lblFlightId);
		
		JLabel lblNewLabel = new JLabel("Flight Name");
		lblNewLabel.setHorizontalAlignment(SwingConstants.CENTER);
		lblNewLabel.setFont(new Font("Times New Roman", Font.BOLD, 18));
		lblNewLabel.setBounds(271, 280, 119, 32);
		frame.getContentPane().add(lblNewLabel);
		
		JLabel lblDestination = new JLabel("Source");
		lblDestination.setHorizontalAlignment(SwingConstants.CENTER);
		lblDestination.setFont(new Font("Times New Roman", Font.BOLD, 18));
		lblDestination.setBounds(271, 325, 119, 33);
		frame.getContentPane().add(lblDestination);
		
		JLabel lblNewLabel_1 = new JLabel("Departure");
		lblNewLabel_1.setHorizontalAlignment(SwingConstants.CENTER);
		lblNewLabel_1.setFont(new Font("Times New Roman", Font.BOLD, 18));
		lblNewLabel_1.setBounds(680, 325, 100, 29);
		frame.getContentPane().add(lblNewLabel_1);
		
		JLabel lblNewLabel_2 = new JLabel("No.of Seats");
		lblNewLabel_2.setHorizontalAlignment(SwingConstants.CENTER);
		lblNewLabel_2.setFont(new Font("Times New Roman", Font.BOLD, 18));
		lblNewLabel_2.setBounds(271, 527, 119, 40);
		frame.getContentPane().add(lblNewLabel_2);
		
		JLabel lblSeats = new JLabel("Price per seat");
		lblSeats.setHorizontalAlignment(SwingConstants.CENTER);
		lblSeats.setFont(new Font("Times New Roman", Font.BOLD, 18));
		lblSeats.setBounds(271, 580, 115, 28);
		frame.getContentPane().add(lblSeats);
		
		JButton add = new JButton("Add Flight");
		add.setIcon(new ImageIcon(FlightDetails.class.getResource("/airlineimages/add.png")));
		add.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				
				try{
					int bc=Integer.parseInt(nobc.getText());
					int fc=Integer.parseInt(nofc.getText());
					int ec=Integer.parseInt(noec.getText());
					ts=bc+fc+ec;
					Class.forName("com.mysql.jdbc.Driver");
					Connection con=DriverManager.getConnection("jdbc:mysql://localhost:3306/airline","root","root");
					Statement st=con.createStatement();
					String sql="insert into flightdetails (fid,fname,source,dt,dest,at,nobc,prbc,nofc,prfc,noec,prec,ts) values('"+fid.getText()+"','"+fname.getText()+"','"+source.getText()+"','"+departure.getText()+"','"+dest.getText()+"','"+at.getText()+"','"+nobc.getText()+"','"+prbc.getText()+"','"+nofc.getText()+"','"+prfc.getText()+"','"+noec.getText()+"','"+prec.getText()+"','"+ts+"')";
					String sql1="insert into search (fid,fname,source,dt,dest,at)values('"+fid.getText()+"','"+fname.getText()+"','"+source.getText()+"','"+departure.getText()+"','"+dest.getText()+"','"+at.getText()+"')";
					st.executeUpdate(sql);
					st.executeUpdate(sql1);
					JOptionPane.showMessageDialog(null,"Flight added sucessfully...");
					con.close();
				}
				catch(Exception e)
				{
					System.out.println(e);
					}	
			}
		});
		add.setFont(new Font("Times New Roman", Font.BOLD, 18));
		add.setBounds(281, 700, 214, 57);
		frame.getContentPane().add(add);
		
		JButton delete = new JButton("Delete Flight");
		delete.setIcon(new ImageIcon(FlightDetails.class.getResource("/airlineimages/delete.png")));
		delete.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				
				try{
					Class.forName("com.mysql.jdbc.Driver");
					Connection con=DriverManager.getConnection("jdbc:mysql://localhost:3306/airline","root","root");
					Statement st=con.createStatement();
					String sql="DELETE FROM flightdetails WHERE fid='"+fid.getText()+"'";
					String sql1="DELETE FROM search WHERE fid='"+fid.getText()+"'";
				    st.executeUpdate(sql);
				    st.executeUpdate(sql1);
					JOptionPane.showMessageDialog(null,"Flight deleted sucessfully...");
					con.close();
				}
				catch(Exception e1)
				{
					System.out.println(e1);
					}
			}
		});
		delete.setFont(new Font("Times New Roman", Font.BOLD, 18));
		delete.setBounds(507, 700, 214, 57);
		frame.getContentPane().add(delete);
		
		JButton update = new JButton("Update Flight");
		update.setIcon(new ImageIcon(FlightDetails.class.getResource("/airlineimages/update.png")));
		update.setFont(new Font("Times New Roman", Font.BOLD, 18));
		update.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				
				try{
					int bc=Integer.parseInt(nobc.getText());
					int fc=Integer.parseInt(nofc.getText());
					int ec=Integer.parseInt(noec.getText());
					ts=bc+fc+ec;
					Class.forName("com.mysql.jdbc.Driver");
					Connection con=DriverManager.getConnection("jdbc:mysql://localhost:3306/airline","root","root");
					Statement st=con.createStatement();
					String sql="update flightdetails set fname='"+fname.getText()+"',source='"+source.getText()+"',dt='"+departure.getText()+"',dest='"+dest.getText()+"',at='"+at.getText()+"',nobc='"+nobc.getText()+"',prbc='"+prbc.getText()+"',nofc='"+nofc.getText()+"',prfc='"+prfc.getText()+"',noec='"+noec.getText()+"',prec='"+prec.getText()+"',ts='"+ts+"'  WHERE `fid`='"+fid.getText()+"' ";
					String sql1="update search set fname='"+fname.getText()+"',source='"+source.getText()+"',dt='"+departure.getText()+"',dest='"+dest.getText()+"',at='"+at.getText()+"')";
					st.executeUpdate(sql);
					st.executeUpdate(sql1);
					
					JOptionPane.showMessageDialog(null,"Flight updated sucessfully...");
					con.close();
				}
				catch(Exception e1)
				{
					System.out.println(e1);
					}
			}
		});
		update.setBounds(733, 700, 244, 57);
		frame.getContentPane().add(update);
		
		fid = new JTextField();
		fid.setBounds(424, 244, 244, 27);
		frame.getContentPane().add(fid);
		fid.setColumns(10);
		
		fname = new JTextField();
		fname.setBounds(424, 282, 244, 29);
		frame.getContentPane().add(fname);
		fname.setColumns(10);
		
		source = new JTextField();
		source.setBounds(424, 327, 244, 29);
		frame.getContentPane().add(source);
		source.setColumns(10);
		
		departure = new JTextField();
		departure.setBounds(792, 327, 244, 25);
		frame.getContentPane().add(departure);
		departure.setColumns(10);
		
		nobc = new JTextField();
		nobc.setBounds(483, 535, 129, 25);
		frame.getContentPane().add(nobc);
		nobc.setColumns(10);
		
		JButton btnBack = new JButton("Back");
		btnBack.setFont(new Font("Times New Roman", Font.BOLD, 18));
		btnBack.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				AdminMenu.AdminMenu();
				
			}
		});
		btnBack.setIcon(new ImageIcon(FlightDetails.class.getResource("/airlineimages/back1.png")));
		btnBack.setBounds(0, 782, 129, 41);
		frame.getContentPane().add(btnBack);
		
		JLabel lblNewLabel_3 = new JLabel("Destination");
		lblNewLabel_3.setHorizontalAlignment(SwingConstants.CENTER);
		lblNewLabel_3.setFont(new Font("Times New Roman", Font.BOLD, 18));
		lblNewLabel_3.setBounds(281, 371, 89, 23);
		frame.getContentPane().add(lblNewLabel_3);
		
		dest = new JTextField();
		dest.setBounds(424, 369, 244, 26);
		frame.getContentPane().add(dest);
		dest.setColumns(10);
		
		prbc = new JTextField();
		prbc.setBounds(483, 580, 129, 29);
		frame.getContentPane().add(prbc);
		prbc.setColumns(10);
		
		JLabel lblArrivalTime = new JLabel("Arrival");
		lblArrivalTime.setHorizontalAlignment(SwingConstants.CENTER);
		lblArrivalTime.setFont(new Font("Times New Roman", Font.BOLD, 18));
		lblArrivalTime.setBounds(680, 367, 100, 21);
		frame.getContentPane().add(lblArrivalTime);
		
		at = new JTextField();
		at.setBounds(792, 371, 244, 24);
		frame.getContentPane().add(at);
		at.setColumns(10);
		
		JButton btnSearch = new JButton("Search");
		btnSearch.addActionListener(new ActionListener() {
                        @Override
			public void actionPerformed(ActionEvent arg0) {
				
				 
			     
			        
			       try{
			    	   Class.forName("com.mysql.jdbc.Driver");
			    	   Connection con=DriverManager.getConnection("jdbc:mysql://localhost:3306/airline","root","root");
			    	   String sql=("Select * from flightdetails where fid = ?");
			           ps= con.prepareStatement(sql);
			           ps.setString(1,fid.getText());  
			                  
			           rs=ps.executeQuery();
			           if(rs.next())
			           {
			        	   getValues();
			           }
			           else
			           {
			        	   JOptionPane.showMessageDialog(null,"NO data Found");
			           }
			           }
			           catch(Exception e1)
						{
							System.out.println(e1);
							}
				
				
			}
		});
		btnSearch.setFont(new Font("Times New Roman", Font.BOLD, 18));
		btnSearch.setBounds(680, 244, 100, 25);
		frame.getContentPane().add(btnSearch);
		
		JLabel lblNewLabel_4 = new JLabel("Business");
		lblNewLabel_4.setHorizontalAlignment(SwingConstants.CENTER);
		lblNewLabel_4.setFont(new Font("Times New Roman", Font.BOLD, 18));
		lblNewLabel_4.setBounds(483, 498, 153, 16);
		frame.getContentPane().add(lblNewLabel_4);
		
		JLabel lblClass = new JLabel("Class");
		lblClass.setHorizontalAlignment(SwingConstants.CENTER);
		lblClass.setFont(new Font("Times New Roman", Font.BOLD, 18));
		lblClass.setBounds(271, 498, 153, 16);
		frame.getContentPane().add(lblClass);
		
		JLabel lblFirst = new JLabel("First");
		lblFirst.setHorizontalAlignment(SwingConstants.CENTER);
		lblFirst.setFont(new Font("Times New Roman", Font.BOLD, 18));
		lblFirst.setBounds(640, 498, 153, 16);
		frame.getContentPane().add(lblFirst);
		
		nofc = new JTextField();
		nofc.setColumns(10);
		nofc.setBounds(640, 535, 129, 25);
		frame.getContentPane().add(nofc);
		
		prfc = new JTextField();
		prfc.setColumns(10);
		prfc.setBounds(640, 580, 129, 29);
		frame.getContentPane().add(prfc);
		
		JLabel lblEconomy = new JLabel("Economy");
		lblEconomy.setHorizontalAlignment(SwingConstants.CENTER);
		lblEconomy.setFont(new Font("Times New Roman", Font.BOLD, 18));
		lblEconomy.setBounds(792, 498, 153, 16);
		frame.getContentPane().add(lblEconomy);
		
		noec = new JTextField();
		noec.setColumns(10);
		noec.setBounds(792, 535, 129, 25);
		frame.getContentPane().add(noec);
		
		prec = new JTextField();
		prec.setColumns(10);
		prec.setBounds(792, 580, 129, 29);
		frame.getContentPane().add(prec);
		
		JLabel lblNewLabel_5 = new JLabel("Maximum Number of seats per class is 56");
		lblNewLabel_5.setFont(new Font("Times New Roman", Font.BOLD, 18));
		lblNewLabel_5.setForeground(Color.RED);
		lblNewLabel_5.setBounds(933, 530, 387, 32);
		frame.getContentPane().add(lblNewLabel_5);
		
		JLabel lblNewLabel_6 = new JLabel("2.Pricing details");
		lblNewLabel_6.setHorizontalAlignment(SwingConstants.CENTER);
		lblNewLabel_6.setFont(new Font("Times New Roman", Font.BOLD, 24));
		lblNewLabel_6.setBounds(262, 407, 350, 80);
		frame.getContentPane().add(lblNewLabel_6);
		
		JLabel lblbasicFlightDetails = new JLabel("1.Basic Flight Details ");
		lblbasicFlightDetails.setHorizontalAlignment(SwingConstants.CENTER);
		lblbasicFlightDetails.setFont(new Font("Times New Roman", Font.BOLD, 24));
		lblbasicFlightDetails.setBounds(262, 151, 350, 80);
		frame.getContentPane().add(lblbasicFlightDetails);
	}
}
