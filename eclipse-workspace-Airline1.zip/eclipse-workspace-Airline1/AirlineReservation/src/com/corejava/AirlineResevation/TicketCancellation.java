package com.corejava.AirlineResevation;

import java.awt.EventQueue;

import javax.swing.JFrame;
import java.awt.Color;
import javax.swing.JLabel;
import java.awt.Font;

import javax.swing.JOptionPane;
import javax.swing.JTextField;
import javax.swing.JButton;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.Statement;

public class TicketCancellation {

	private JFrame frame;
	private JTextField tno;

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					TicketCancellation window = new TicketCancellation();
					window.frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the application.
	 */
	public TicketCancellation() {
		initialize();
	}

	/**
	 * Initialize the contents of the frame.
	 */
	private void initialize() {
		frame = new JFrame();
		frame.getContentPane().setBackground(Color.WHITE);
		frame.setBounds(100, 100, 806, 513);
		frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		frame.getContentPane().setLayout(null);
		
		JLabel lblTicketCancellation = new JLabel("TICKET CANCELLATION");
		lblTicketCancellation.setFont(new Font("Times New Roman", Font.BOLD, 22));
		lblTicketCancellation.setBounds(255, 66, 289, 43);
		frame.getContentPane().add(lblTicketCancellation);
		
		JLabel lblTicketNo = new JLabel("TICKET NO.");
		lblTicketNo.setFont(new Font("Times New Roman", Font.PLAIN, 15));
		lblTicketNo.setBounds(173, 185, 92, 25);
		frame.getContentPane().add(lblTicketNo);
		
		tno = new JTextField();
		tno.setBounds(407, 186, 116, 22);
		frame.getContentPane().add(tno);
		tno.setColumns(10);
		
		JButton btnDelete = new JButton("DELETE");
		btnDelete.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				
				try{
					Class.forName("com.mysql.jdbc.Driver");
					Connection con=DriverManager.getConnection("jdbc:mysql://localhost:3306/airline","root","root");
					Statement st=con.createStatement();
					String sql="DELETE FROM payment WHERE tno='"+tno.getText()+"'";
				    
					st.executeUpdate(sql);
					JOptionPane.showMessageDialog(null,"Ticket  deleted sucessfully...");
					
					/*if(rs.next())
						JOptionPane.showMessageDialog(null,"Registered Sucessfully...");
						else
							JOptionPane.showMessageDialog(null,"Fill proper data");*/
					con.close();
				}
				catch(Exception e)
				{
					System.out.println(e);
					}
			}
		});
		btnDelete.setBounds(295, 321, 97, 36);
		frame.getContentPane().add(btnDelete);
	}

}
