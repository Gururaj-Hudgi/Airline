package airline;

import java.awt.Color;
import java.awt.EventQueue;
import java.awt.Font;
import java.awt.Label;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.FocusAdapter;
import java.awt.event.FocusEvent;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.Calendar;
import java.util.GregorianCalendar;
import java.util.Random;

import javax.swing.DefaultComboBoxModel;
import javax.swing.JButton;
import javax.swing.JComboBox;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JTable;
import javax.swing.JTextField;
import javax.swing.JToggleButton;
import javax.swing.SwingConstants;
import javax.swing.border.BevelBorder;
import javax.swing.border.EtchedBorder;
import javax.swing.border.LineBorder;
import javax.swing.table.DefaultTableModel;

import com.teknikindustries.bulksms.SMS;

import net.proteanit.sql.DbUtils;
import java.awt.event.KeyAdapter;
import java.awt.event.KeyEvent;
import javax.swing.ImageIcon;
import java.awt.event.WindowAdapter;
import java.awt.event.WindowEvent;

public class Booking {

    private JFrame frame;
    private ResultSet rs;
    private JTextField TicketID;
    private JTextField fid;
    private final String tid = null;
	private int c;
	private JTextField board;
	private JTextField dt;
	private JTextField destination;
	private JTextField at;
	private JTextField doj;
	private JTextField name1;
	private JTextField name2;
	private JTextField name3;
	private JTextField name4;
	private JTextField age1;
	private JTextField age2;
	private JTextField age3;
	private JTextField age4;
	JTextField mob1;
	private JTextField mob2;
	private JTextField mob3;
	private JTextField mob4;
	private JTextField seat1;
	private JTextField seat2;
	private JTextField seat3;
	private JTextField seat4;
	private JTextField class1;
	private JTextField class2;
	private JTextField class3;
	private JTextField class4;
	private JTextField sc;
	private JTextField source;
	private JTextField dest;
	private JTable search;
	private JTextField total;
	private JTextField fname;
	private JTextField dateofjourney;
	private JTextField ta;
	private JLabel time;
	private JLabel date;
    
    
    /**
     * Launch the application.
     */
	
	private void clock()
	{
		
		Thread clock = new Thread()
				{
					public void run()
					{
						for(;;)
						{	
							Calendar cal=new GregorianCalendar();
							int month=cal.get(Calendar.MONTH)+1;
							int year=cal.get(Calendar.YEAR);
							int day=cal.get(Calendar.DAY_OF_MONTH);
							date.setText("Date: "+day+"/"+month+"/"+year);
							
							int second =cal.get(Calendar.SECOND);
							int minute =cal.get(Calendar.MINUTE);
							int hour =cal.get(Calendar.HOUR_OF_DAY);
							time.setText("Time: "+hour+":"+minute+":"+second);
							try {
								sleep(1000);
							} catch (InterruptedException e) {
								// TODO Auto-generated catch block
								e.printStackTrace();
							}
						}
					}
				};
				clock.start();
	}
    public static  void Booking() {
        EventQueue.invokeLater(new Runnable() {
            public void run() {
                try {
                    Booking window = new Booking();
                    window.frame.setVisible(true);
                } catch (Exception e) {
                    e.printStackTrace();
                }
            }
        });
    }

    /**
     * Create the application.
     */
    
    public void random()
	{
		Random ran =new Random();
		int n = ran.nextInt(1000000000)+1;
		String val=String.valueOf(n);
		TicketID.setText(val);
		
	}
    
    private void update()
    {
    	try {
			Class.forName("com.mysql.jdbc.Driver");
			Connection con = DriverManager.getConnection("jdbc:mysql://localhost:3306/airline", "root", "root");
			Statement stmt = con.createStatement();
			String sql1 = "select * from search where source='"+source.getText()+"' AND dest='"+dest.getText()+"'";
			rs = stmt.executeQuery(sql1);
			search.setModel(DbUtils.resultSetToTableModel(rs));
		} catch (ClassNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
        
    	
    }
    public Booking() {
        initialize();
        random();
        update();
        clock();
    }
 
    

	/**
     * Initialize the contents of the frame.
     */
    private void initialize() {
        frame = new JFrame();
        frame.setBounds(300, 100, 1350, 870);
        frame.getContentPane().setBackground(new Color(240, 248, 255));
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        frame.getContentPane().setLayout(null);

        JPanel seatpanel = new JPanel();
        seatpanel.setBounds(22, 483, 587, 314);
        seatpanel.setBorder(new BevelBorder(BevelBorder.LOWERED, null, null, null, null));
        frame.getContentPane().add(seatpanel);
        seatpanel.setLayout(null);
        seatpanel.setVisible(false);

        JToggleButton S12 = new JToggleButton("12");
        S12.setFont(new Font("Times New Roman", Font.BOLD, 11));
        S12.setBounds(231, 54, 47, 25);
        seatpanel.add(S12);
        S12.setVisible(false);

        JToggleButton S11 = new JToggleButton("11");
        S11.setFont(new Font("Times New Roman", Font.BOLD, 11));
        S11.setBounds(272, 54, 47, 25);
        seatpanel.add(S11);
        S11.setVisible(false);
        
        JToggleButton S10 = new JToggleButton("10");
        S10.setFont(new Font("Times New Roman", Font.BOLD, 11));
        S10.setBounds(312, 54, 47, 25);
        seatpanel.add(S10);
        S10.setVisible(false);
        
        JToggleButton S17 = new JToggleButton("17");
        S17.setFont(new Font("Times New Roman", Font.BOLD, 11));
        S17.setBounds(231, 92, 47, 25);
        seatpanel.add(S17);
        S17.setVisible(false);

        JToggleButton S18 = new JToggleButton("18");
        S18.setFont(new Font("Times New Roman", Font.BOLD, 11));
        S18.setBounds(272, 92, 47, 25);
        seatpanel.add(S18);
        S18.setVisible(false);

        JToggleButton S19 = new JToggleButton("19");
        S19.setFont(new Font("Times New Roman", Font.BOLD, 11));
        S19.setBounds(312, 92, 47, 25);
        seatpanel.add(S19);
        S19.setVisible(false);

        JToggleButton S26 = new JToggleButton("26");
        S26.setFont(new Font("Times New Roman", Font.BOLD, 11));
        S26.setBounds(231, 130, 47, 25);
        seatpanel.add(S26);
        S26.setVisible(false);

        JToggleButton S25 = new JToggleButton("25");
        S25.setFont(new Font("Times New Roman", Font.BOLD, 11));
        S25.setBounds(272, 130, 47, 25);
        seatpanel.add(S25);
        S25.setVisible(false);

        JToggleButton S24 = new JToggleButton("24");
        S24.setFont(new Font("Times New Roman", Font.BOLD, 11));
        S24.setBounds(312, 130, 47, 25);
        seatpanel.add(S24);
        S24.setVisible(false);

        JToggleButton S31 = new JToggleButton("31");
        S31.setFont(new Font("Times New Roman", Font.BOLD, 11));
        S31.setBounds(231, 168, 47, 25);
        seatpanel.add(S31);
        S31.setVisible(false);

        JToggleButton S32 = new JToggleButton("32");
        S32.setFont(new Font("Times New Roman", Font.BOLD, 11));
        S32.setBounds(272, 168, 47, 25);
        seatpanel.add(S32);
        S32.setVisible(false);

        JToggleButton S33 = new JToggleButton("33");
        S33.setFont(new Font("Times New Roman", Font.BOLD, 11));
        S33.setBounds(312, 168, 47, 25);
        seatpanel.add(S33);
        S33.setVisible(false);

        JToggleButton S40 = new JToggleButton("40");
        S40.setFont(new Font("Times New Roman", Font.BOLD, 11));
        S40.setBounds(231, 206, 47, 25);
        seatpanel.add(S40);
        S40.setVisible(false);

        JToggleButton S39 = new JToggleButton("39");
        S39.setFont(new Font("Times New Roman", Font.BOLD, 11));
        S39.setBounds(272, 206, 47, 25);
        seatpanel.add(S39);
        S39.setVisible(false);
        
        JToggleButton S38 = new JToggleButton("38");
        S38.setFont(new Font("Times New Roman", Font.BOLD, 11));
        S38.setBounds(312, 206, 47, 25);
        seatpanel.add(S38);
        S38.setVisible(false);
        
        JToggleButton S45 = new JToggleButton("45");
        S45.setFont(new Font("Times New Roman", Font.BOLD, 11));
        S45.setBounds(231, 244, 47, 25);
        seatpanel.add(S45);
        S45.setVisible(false);
        
        JToggleButton S46 = new JToggleButton("46");
        S46.setFont(new Font("Times New Roman", Font.BOLD, 11));
        S46.setBounds(272, 244, 47, 25);
        seatpanel.add(S46);
        S46.setVisible(false);
        
        JToggleButton S47 = new JToggleButton("47");
        S47.setFont(new Font("Times New Roman", Font.BOLD, 11));
        S47.setBounds(312, 244, 47, 25);
        seatpanel.add(S47);
        S47.setVisible(false);
        
        JToggleButton S54 = new JToggleButton("54");
        S54.setFont(new Font("Times New Roman", Font.BOLD, 11));
        S54.setBounds(231, 282, 47, 25);
        seatpanel.add(S54);
        S54.setVisible(false);

        JToggleButton S53 = new JToggleButton("53");
        S53.setFont(new Font("Times New Roman", Font.BOLD, 11));
        S53.setBounds(272, 282, 47, 25);
        seatpanel.add(S53);
        S53.setVisible(false);

        JToggleButton S52 = new JToggleButton("52");
        S52.setFont(new Font("Times New Roman", Font.BOLD, 11));
        S52.setBounds(312, 282, 47, 25);
        seatpanel.add(S52);
        S52.setVisible(false);

        JToggleButton S1 = new JToggleButton("1");
        S1.setFont(new Font("Times New Roman", Font.BOLD, 11));
        S1.setBounds(53, 13, 50, 25);
        seatpanel.add(S1);
        S1.setVisible(false);

        JToggleButton S2 = new JToggleButton("2");
        S2.setFont(new Font("Times New Roman", Font.BOLD, 11));
        S2.setBounds(94, 13, 50, 25);
        seatpanel.add(S2);
        S2.setVisible(false);

        JToggleButton S14 = new JToggleButton("14");
        S14.setFont(new Font("Times New Roman", Font.BOLD, 11));
        S14.setBounds(53, 51, 50, 25);
        seatpanel.add(S14);
        S14.setVisible(false);

        JToggleButton S13 = new JToggleButton("13");
        S13.setFont(new Font("Times New Roman", Font.BOLD, 11));
        S13.setBounds(94, 51, 50, 25);
        seatpanel.add(S13);
        S13.setVisible(false);

        JToggleButton S15 = new JToggleButton("15");
        S15.setFont(new Font("Times New Roman", Font.BOLD, 11));
        S15.setBounds(53, 89, 50, 25);
        seatpanel.add(S15);
        S15.setVisible(false);

        JToggleButton S16 = new JToggleButton("16");
        S16.setFont(new Font("Times New Roman", Font.BOLD, 11));
        S16.setBounds(94, 89, 50, 25);
        seatpanel.add(S16);
        S16.setVisible(false);

        JToggleButton S28 = new JToggleButton("28");
        S28.setFont(new Font("Times New Roman", Font.BOLD, 11));
        S28.setBounds(53, 127, 50, 25);
        seatpanel.add(S28);
        S28.setVisible(false);

        JToggleButton S27 = new JToggleButton("27");
        S27.setFont(new Font("Times New Roman", Font.BOLD, 11));
        S27.setBounds(94, 127, 50, 25);
        seatpanel.add(S27);
        S27.setVisible(false);

        JToggleButton S29 = new JToggleButton("29");
        S29.setFont(new Font("Times New Roman", Font.BOLD, 11));
        S29.setBounds(53, 165, 50, 25);
        seatpanel.add(S29);
        S29.setVisible(false);

        JToggleButton S30 = new JToggleButton("30");
        S30.setFont(new Font("Times New Roman", Font.BOLD, 11));
        S30.setBounds(94, 165, 50, 25);
        seatpanel.add(S30);
        S30.setVisible(false);

        JToggleButton S42 = new JToggleButton("42");
        S42.setFont(new Font("Times New Roman", Font.BOLD, 11));
        S42.setBounds(53, 203, 50, 25);
        seatpanel.add(S42);
        S42.setVisible(false);

        JToggleButton S41 = new JToggleButton("41");
        S41.setFont(new Font("Times New Roman", Font.BOLD, 11));
        S41.setBounds(94, 203, 50, 25);
        seatpanel.add(S41);
        S41.setVisible(false);

        JToggleButton S43 = new JToggleButton("43");
        S43.setFont(new Font("Times New Roman", Font.BOLD, 11));
        S43.setBounds(53, 241, 50, 25);
        seatpanel.add(S43);
        S43.setVisible(false);

        JToggleButton S44 = new JToggleButton("44");
        S44.setFont(new Font("Times New Roman", Font.BOLD, 11));
        S44.setBounds(94, 241, 50, 25);
        seatpanel.add(S44);
        S44.setVisible(false);

        JToggleButton S56 = new JToggleButton("56");
        S56.setFont(new Font("Times New Roman", Font.BOLD, 11));
        S56.setBounds(53, 279, 50, 25);
        seatpanel.add(S56);
        S56.setVisible(false);

        JToggleButton S55 = new JToggleButton("55");
        S55.setFont(new Font("Times New Roman", Font.BOLD, 11));
        S55.setBounds(94, 279, 50, 25);
        seatpanel.add(S55);
        S55.setVisible(false);

        JToggleButton S6 = new JToggleButton("6");
        S6.setFont(new Font("Times New Roman", Font.BOLD, 11));
        S6.setBounds(438, 13, 50, 25);
        seatpanel.add(S6);
        S6.setVisible(false);

        JToggleButton S7 = new JToggleButton("7");
        S7.setFont(new Font("Times New Roman", Font.BOLD, 11));
        S7.setBounds(479, 13, 50, 25);
        seatpanel.add(S7);
        S7.setVisible(false);;

        JToggleButton S9 = new JToggleButton("9");
        S9.setFont(new Font("Times New Roman", Font.BOLD, 11));
        S9.setBounds(438, 51, 50, 25);
        seatpanel.add(S9);
        S9.setVisible(false);

        JToggleButton S8 = new JToggleButton("8");
        S8.setFont(new Font("Times New Roman", Font.BOLD, 11));
        S8.setBounds(479, 51, 50, 25);
        seatpanel.add(S8);
        S8.setVisible(false);

        JToggleButton S20 = new JToggleButton("20");
        S20.setFont(new Font("Times New Roman", Font.BOLD, 11));
        S20.setBounds(438, 89, 50, 25);
        seatpanel.add(S20);
        S20.setVisible(false);

        JToggleButton S21 = new JToggleButton("21");
        S21.setFont(new Font("Times New Roman", Font.BOLD, 11));
        S21.setBounds(479, 89, 50, 25);
        seatpanel.add(S21);
        S21.setVisible(false);

        JToggleButton S23 = new JToggleButton("23");
        S23.setFont(new Font("Times New Roman", Font.BOLD, 11));
        S23.setBounds(438, 127, 50, 25);
        seatpanel.add(S23);
        S23.setVisible(false);

        JToggleButton S22 = new JToggleButton("22");
        S22.setFont(new Font("Times New Roman", Font.BOLD, 11));
        S22.setBounds(479, 127, 50, 25);
        seatpanel.add(S22);
        S22.setVisible(false);

        JToggleButton S34 = new JToggleButton("34");
        S34.setFont(new Font("Times New Roman", Font.BOLD, 11));
        S34.setBounds(438, 165, 50, 25);
        seatpanel.add(S34);
        S34.setVisible(false);

        JToggleButton S35 = new JToggleButton("35");
        S35.setFont(new Font("Times New Roman", Font.BOLD, 11));
        S35.setBounds(479, 165, 50, 25);
        seatpanel.add(S35);
        S35.setVisible(false);

        JToggleButton S37 = new JToggleButton("37");
        S37.setFont(new Font("Times New Roman", Font.BOLD, 11));
        S37.setBounds(438, 203, 50, 25);
        seatpanel.add(S37);
        S37.setVisible(false);

        JToggleButton S36 = new JToggleButton("36");
        S36.setFont(new Font("Times New Roman", Font.BOLD, 11));
        S36.setBounds(479, 203, 50, 25);
        seatpanel.add(S36);
        S36.setVisible(false);

        JToggleButton S48 = new JToggleButton("48");
        S48.setFont(new Font("Times New Roman", Font.BOLD, 11));
        S48.setBounds(438, 241, 50, 25);
        seatpanel.add(S48);
        S48.setVisible(false);

        JToggleButton S49 = new JToggleButton("49");
        S49.setFont(new Font("Times New Roman", Font.BOLD, 11));
        S49.setBounds(479, 241, 50, 25);
        seatpanel.add(S49);
        S49.setVisible(false);

        JToggleButton S51 = new JToggleButton("51");
        S51.setFont(new Font("Times New Roman", Font.BOLD, 11));
        S51.setBounds(438, 279, 50, 25);
        seatpanel.add(S51);
        S51.setVisible(false);

        JToggleButton S50 = new JToggleButton("50");
        S50.setFont(new Font("Times New Roman", Font.BOLD, 11));
        S50.setBounds(479, 279, 50, 25);
        seatpanel.add(S50);
        S50.setVisible(false);

        JToggleButton S5 = new JToggleButton("5");
        S5.setFont(new Font("Times New Roman", Font.BOLD, 11));
        S5.setBounds(315, 13, 47, 25);
        seatpanel.add(S5);
        S5.setVisible(false);

        JToggleButton S4 = new JToggleButton("4");
        S4.setFont(new Font("Times New Roman", Font.BOLD, 11));
        S4.setBounds(272, 13, 50, 25);
        seatpanel.add(S4);
        S4.setVisible(false);

        JToggleButton S3 = new JToggleButton("3");
        S3.setFont(new Font("Times New Roman", Font.BOLD, 11));
        S3.setBounds(231, 13, 50, 25);
        seatpanel.add(S3);
        S3.setVisible(false);
        
        JPanel panel_2 = new JPanel();
        panel_2.setBounds(623, 65, 709, 758);
        panel_2.setBorder(new EtchedBorder(EtchedBorder.LOWERED, null, null));
        frame.getContentPane().add(panel_2);
        panel_2.setLayout(null);
        
        TicketID = new JTextField();
        TicketID.setBackground(Color.WHITE);
        TicketID.setForeground(Color.BLACK);
        TicketID.setHorizontalAlignment(SwingConstants.CENTER);
        TicketID.setFont(new Font("Times New Roman", Font.BOLD, 18));
        TicketID.setEditable(false);
        TicketID.setBounds(121, 81, 116, 22);
        panel_2.add(TicketID);
        TicketID.setColumns(10);
        
        fid = new JTextField();
        fid.setForeground(Color.BLACK);
        fid.setBackground(Color.WHITE);
        fid.setEditable(false);
        fid.setHorizontalAlignment(SwingConstants.CENTER);
        fid.setFont(new Font("Times New Roman", Font.BOLD, 18));
        fid.setBounds(122, 119, 116, 22);
        panel_2.add(fid);
        fid.setColumns(10);
        
        JLabel lblNewLabel = new JLabel("Ticket ID");
        lblNewLabel.setHorizontalAlignment(SwingConstants.CENTER);
        lblNewLabel.setFont(new Font("Times New Roman", Font.BOLD, 16));
        lblNewLabel.setBounds(12, 84, 97, 16);
        panel_2.add(lblNewLabel);
        
        JLabel Source = new JLabel("Source");
        Source.setHorizontalAlignment(SwingConstants.CENTER);
        Source.setFont(new Font("Times New Roman", Font.BOLD, 16));
        Source.setBounds(12, 157, 97, 16);
        panel_2.add(Source);
        
        JLabel DepartureTime = new JLabel("Departure");
        DepartureTime.setHorizontalAlignment(SwingConstants.CENTER);
        DepartureTime.setFont(new Font("Times New Roman", Font.BOLD, 16));
        DepartureTime.setBounds(249, 157, 117, 16);
        panel_2.add(DepartureTime);
        
        JLabel Destination = new JLabel("Destination");
        Destination.setHorizontalAlignment(SwingConstants.CENTER);
        Destination.setFont(new Font("Times New Roman", Font.BOLD, 16));
        Destination.setBounds(12, 186, 97, 16);
        panel_2.add(Destination);
        
        board = new JTextField();
        board.setForeground(Color.BLACK);
        board.setBackground(Color.WHITE);
        board.setEditable(false);
        board.setHorizontalAlignment(SwingConstants.CENTER);
        board.setFont(new Font("Times New Roman", Font.BOLD, 18));
        board.setColumns(10);
        board.setBounds(121, 154, 116, 22);
        panel_2.add(board);
        
        dt = new JTextField();
        dt.setEditable(false);
        dt.setBackground(Color.WHITE);
        dt.setForeground(Color.BLACK);
        dt.setHorizontalAlignment(SwingConstants.CENTER);
        dt.setFont(new Font("Times New Roman", Font.BOLD, 18));
        dt.setColumns(10);
        dt.setBounds(378, 153, 116, 22);
        panel_2.add(dt);
        
        destination = new JTextField();
        destination.setForeground(Color.BLACK);
        destination.setBackground(Color.WHITE);
        destination.setEditable(false);
        destination.setHorizontalAlignment(SwingConstants.CENTER);
        destination.setFont(new Font("Times New Roman", Font.BOLD, 18));
        destination.setColumns(10);
        destination.setBounds(121, 183, 116, 22);
        panel_2.add(destination);
        
        JLabel ArrivalTime = new JLabel("Arrival");
        ArrivalTime.setHorizontalAlignment(SwingConstants.CENTER);
        ArrivalTime.setFont(new Font("Times New Roman", Font.BOLD, 16));
        ArrivalTime.setBounds(249, 186, 116, 16);
        panel_2.add(ArrivalTime);
        
        JLabel Date = new JLabel("DOJ");
        Date.setHorizontalAlignment(SwingConstants.CENTER);
        Date.setFont(new Font("Times New Roman", Font.BOLD, 16));
        Date.setBounds(500, 122, 69, 16);
        panel_2.add(Date);
        
        at = new JTextField();
        at.setEditable(false);
        at.setBackground(Color.WHITE);
        at.setForeground(Color.BLACK);
        at.setHorizontalAlignment(SwingConstants.CENTER);
        at.setFont(new Font("Times New Roman", Font.BOLD, 18));
        at.setColumns(10);
        at.setBounds(377, 183, 116, 22);
        panel_2.add(at);
        
        doj = new JTextField();
        doj.setEditable(false);
        doj.setBackground(Color.WHITE);
        doj.setForeground(Color.BLACK);
        doj.setHorizontalAlignment(SwingConstants.CENTER);
        doj.setFont(new Font("Times New Roman", Font.BOLD, 18));
        doj.setColumns(10);
        doj.setBounds(581, 119, 116, 22);
        panel_2.add(doj);
        
        total = new JTextField();
        total.setVisible(false);
        total.setBackground(Color.WHITE);
        total.setEditable(false);
        total.setForeground(Color.BLACK);
        total.setHorizontalAlignment(SwingConstants.CENTER);
        total.setFont(new Font("Times New Roman", Font.BOLD, 18));
        total.setColumns(10);
        total.setBounds(460, 527, 237, 83);
        panel_2.add(total);
        
        JLabel lblGrandTotal = new JLabel("Grand Total");
        lblGrandTotal.setForeground(Color.BLACK);
        lblGrandTotal.setFont(new Font("Times New Roman", Font.BOLD, 26));
        lblGrandTotal.setHorizontalAlignment(SwingConstants.CENTER);
        lblGrandTotal.setBounds(12, 527, 244, 83);
        panel_2.add(lblGrandTotal);
        lblGrandTotal.setVisible(false);
        
        JLabel lblFlightName = new JLabel("Flight Name");
        lblFlightName.setHorizontalAlignment(SwingConstants.CENTER);
        lblFlightName.setFont(new Font("Times New Roman", Font.BOLD, 16));
        lblFlightName.setBounds(250, 116, 116, 22);
        panel_2.add(lblFlightName);
        
        fname = new JTextField();
        fname.setEditable(false);
        fname.setBackground(Color.WHITE);
        fname.setForeground(Color.BLACK);
        fname.setHorizontalAlignment(SwingConstants.CENTER);
        fname.setFont(new Font("Times New Roman", Font.BOLD, 18));
        fname.setColumns(10);
        fname.setBounds(378, 119, 116, 22);
        panel_2.add(fname);
        
        JLabel lblNewLabel_3 = new JLabel("1.Basic Details:");
        lblNewLabel_3.setFont(new Font("Times New Roman", Font.BOLD, 25));
        lblNewLabel_3.setHorizontalAlignment(SwingConstants.CENTER);
        lblNewLabel_3.setBounds(12, 13, 244, 55);
        panel_2.add(lblNewLabel_3);
        
        JLabel lblpassengerDetails = new JLabel("2.Passenger Details:");
        lblpassengerDetails.setHorizontalAlignment(SwingConstants.CENTER);
        lblpassengerDetails.setFont(new Font("Times New Roman", Font.BOLD, 25));
        lblpassengerDetails.setBounds(12, 236, 272, 55);
        panel_2.add(lblpassengerDetails);
        lblpassengerDetails.setVisible(false);
        
        JPanel passengerpanel = new JPanel();
        passengerpanel.setBounds(12, 300, 685, 214);
        panel_2.add(passengerpanel);
        passengerpanel.setLayout(null);
        passengerpanel.setVisible(false);
        
        JLabel FlightID = new JLabel("Flight ID");
        FlightID.setHorizontalAlignment(SwingConstants.CENTER);
        FlightID.setFont(new Font("Times New Roman", Font.BOLD, 16));
        FlightID.setBounds(12, 122, 97, 16);
        panel_2.add(FlightID);
        
        JLabel name = new JLabel("Name");
        name.setBounds(12, 13, 172, 29);
        passengerpanel.add(name);
        name.setFont(new Font("Times New Roman", Font.BOLD, 16));
        name.setHorizontalAlignment(SwingConstants.CENTER);
        
        name1 = new JTextField();
        name1.setForeground(Color.BLACK);
        name1.setBounds(12, 55, 172, 22);
        passengerpanel.add(name1);
        name1.setHorizontalAlignment(SwingConstants.CENTER);
        name1.setFont(new Font("Times New Roman", Font.BOLD, 18));
        name1.setColumns(10);
        name1.setVisible(false);
        
        name2 = new JTextField();
        name2.setForeground(Color.BLACK);
        name2.setBounds(12, 82, 172, 22);
        passengerpanel.add(name2);
        name2.setHorizontalAlignment(SwingConstants.CENTER);
        name2.setFont(new Font("Times New Roman", Font.BOLD, 18));
        name2.setColumns(10);
        name2.setVisible(false);
        
        name3 = new JTextField();
        name3.setForeground(Color.BLACK);
        name3.setBounds(12, 109, 172, 22);
        passengerpanel.add(name3);
        name3.setHorizontalAlignment(SwingConstants.CENTER);
        name3.setFont(new Font("Times New Roman", Font.BOLD, 18));
        name3.setColumns(10);
        name3.setVisible(false);
        
        name4 = new JTextField();
        name4.setForeground(Color.BLACK);
        name4.setBounds(12, 137, 172, 22);
        passengerpanel.add(name4);
        name4.setHorizontalAlignment(SwingConstants.CENTER);
        name4.setFont(new Font("Times New Roman", Font.BOLD, 18));
        name4.setColumns(10);
        name4.setVisible(false);
        
        age4 = new JTextField();
        age4.setForeground(Color.BLACK);
        age4.setBounds(196, 137, 60, 22);
        passengerpanel.add(age4);
        age4.setHorizontalAlignment(SwingConstants.CENTER);
        age4.setFont(new Font("Times New Roman", Font.BOLD, 18));
        age4.setColumns(10);
        age4.setVisible(false);
        
        age3 = new JTextField();
        age3.setForeground(Color.BLACK);
        age3.setBounds(196, 109, 60, 22);
        passengerpanel.add(age3);
        age3.setHorizontalAlignment(SwingConstants.CENTER);
        age3.setFont(new Font("Times New Roman", Font.BOLD, 18));
        age3.setColumns(10);
        age3.setVisible(false);
        
        age2 = new JTextField();
        age2.setForeground(Color.BLACK);
        age2.setBounds(196, 82, 60, 22);
        passengerpanel.add(age2);
        age2.setHorizontalAlignment(SwingConstants.CENTER);
        age2.setFont(new Font("Times New Roman", Font.BOLD, 18));
        age2.setColumns(10);
        age2.setVisible(false);
        
        age1 = new JTextField();
        age1.setForeground(Color.BLACK);
        age1.setBounds(196, 55, 60, 22);
        passengerpanel.add(age1);
        age1.setHorizontalAlignment(SwingConstants.CENTER);
        age1.setFont(new Font("Times New Roman", Font.BOLD, 18));
        age1.setColumns(10);
        age1.setVisible(false);
        
        JLabel lblage = new JLabel("Age");
        lblage.setBounds(196, 13, 60, 29);
        passengerpanel.add(lblage);
        lblage.setFont(new Font("Times New Roman", Font.BOLD, 16));
        lblage.setHorizontalAlignment(SwingConstants.CENTER);
        
        JLabel gender = new JLabel("Gender");
        gender.setBounds(268, 13, 69, 29);
        passengerpanel.add(gender);
        gender.setFont(new Font("Times New Roman", Font.BOLD, 16));
        gender.setHorizontalAlignment(SwingConstants.CENTER);
        
        JComboBox gender1 = new JComboBox();
        gender1.setBounds(268, 55, 69, 22);
        passengerpanel.add(gender1);
        gender1.setModel(new DefaultComboBoxModel(new String[] {"Male", "Female"}));
        gender1.setVisible(false);
        
        
        JComboBox gender2 = new JComboBox();
        gender2.setBounds(268, 82, 69, 22);
        passengerpanel.add(gender2);
        gender2.setModel(new DefaultComboBoxModel(new String[] {"Male", "Female"}));
        gender2.setVisible(false);
        
        JComboBox gender3 = new JComboBox();
        gender3.setBounds(268, 109, 69, 22);
        passengerpanel.add(gender3);
        gender3.setModel(new DefaultComboBoxModel(new String[] {"Male", "Female"}));
        gender3.setVisible(false);
        
        JComboBox gender4 = new JComboBox();
        gender4.setBounds(268, 137, 69, 22);
        passengerpanel.add(gender4);
        gender4.setModel(new DefaultComboBoxModel(new String[] {"Male", "Female"}));
        gender4.setVisible(false);
        
        mob4 = new JTextField();
        mob4.setForeground(Color.BLACK);
        mob4.setBounds(349, 137, 116, 22);
        passengerpanel.add(mob4);
        mob4.setHorizontalAlignment(SwingConstants.CENTER);
        mob4.setFont(new Font("Times New Roman", Font.BOLD, 18));
        mob4.setColumns(10);
        mob4.setVisible(false);
        
        mob3 = new JTextField();
        mob3.setForeground(Color.BLACK);
        mob3.setBounds(349, 109, 116, 22);
        passengerpanel.add(mob3);
        mob3.setHorizontalAlignment(SwingConstants.CENTER);
        mob3.setFont(new Font("Times New Roman", Font.BOLD, 18));
        mob3.setColumns(10);
        mob3.setVisible(false);
        
        mob2 = new JTextField();
        mob2.setForeground(Color.BLACK);
        mob2.setBounds(349, 82, 116, 22);
        passengerpanel.add(mob2);
        mob2.setHorizontalAlignment(SwingConstants.CENTER);
        mob2.setFont(new Font("Times New Roman", Font.BOLD, 18));
        mob2.setColumns(10);
        mob2.setVisible(false);
        
        mob1 = new JTextField();
        mob1.setForeground(Color.BLACK);
        mob1.setBounds(349, 55, 116, 22);
        passengerpanel.add(mob1);
        mob1.setHorizontalAlignment(SwingConstants.CENTER);
        mob1.setFont(new Font("Times New Roman", Font.BOLD, 18));
        mob1.setColumns(10);
        mob1.setVisible(false);
        
        JLabel lblmob = new JLabel("Mob.no");
        lblmob.setBounds(349, 13, 116, 29);
        passengerpanel.add(lblmob);
        lblmob.setFont(new Font("Times New Roman", Font.BOLD, 16));
        lblmob.setHorizontalAlignment(SwingConstants.CENTER);
        
        JLabel lblSelectedSeat = new JLabel("\r\nSeat");
        lblSelectedSeat.setBounds(477, 13, 60, 29);
        passengerpanel.add(lblSelectedSeat);
        lblSelectedSeat.setFont(new Font("Times New Roman", Font.BOLD, 16));
        lblSelectedSeat.setHorizontalAlignment(SwingConstants.CENTER);
        
        seat1 = new JTextField();
        seat1.setBounds(477, 55, 60, 22);
        passengerpanel.add(seat1);
        seat1.setEditable(false);
        seat1.setBackground(Color.WHITE);
        seat1.setForeground(Color.BLACK);
        seat1.setHorizontalAlignment(SwingConstants.CENTER);
        seat1.setFont(new Font("Times New Roman", Font.BOLD, 18));
        seat1.setColumns(10);
        seat1.setVisible(false);
        
        seat2 = new JTextField();
        seat2.setBounds(477, 82, 60, 22);
        passengerpanel.add(seat2);
        seat2.setEditable(false);
        seat2.setBackground(Color.WHITE);
        seat2.setForeground(Color.BLACK);
        seat2.setHorizontalAlignment(SwingConstants.CENTER);
        seat2.setFont(new Font("Times New Roman", Font.BOLD, 18));
        seat2.setColumns(10);
        seat2.setVisible(false);
        
        seat3 = new JTextField();
        seat3.setBounds(477, 109, 60, 22);
        passengerpanel.add(seat3);
        seat3.setEditable(false);
        seat3.setBackground(Color.WHITE);
        seat3.setForeground(Color.BLACK);
        seat3.setHorizontalAlignment(SwingConstants.CENTER);
        seat3.setFont(new Font("Times New Roman", Font.BOLD, 18));
        seat3.setColumns(10);
        seat3.setVisible(false);
        
        seat4 = new JTextField();
        seat4.setBounds(477, 137, 60, 22);
        passengerpanel.add(seat4);
        seat4.setEditable(false);
        seat4.setBackground(Color.WHITE);
        seat4.setForeground(Color.BLACK);
        seat4.setHorizontalAlignment(SwingConstants.CENTER);
        seat4.setFont(new Font("Times New Roman", Font.BOLD, 18));
        seat4.setColumns(10);
        seat4.setVisible(false);
        
        class4 = new JTextField();
        class4.setBounds(549, 137, 116, 22);
        passengerpanel.add(class4);
        class4.setEditable(false);
        class4.setBackground(Color.WHITE);
        class4.setForeground(Color.BLACK);
        class4.setHorizontalAlignment(SwingConstants.CENTER);
        class4.setFont(new Font("Times New Roman", Font.BOLD, 18));
        class4.setColumns(10);
        class4.setVisible(false);
        
        class3 = new JTextField();
        class3.setBounds(549, 109, 116, 22);
        passengerpanel.add(class3);
        class3.setEditable(false);
        class3.setBackground(Color.WHITE);
        class3.setForeground(Color.BLACK);
        class3.setHorizontalAlignment(SwingConstants.CENTER);
        class3.setFont(new Font("Times New Roman", Font.BOLD, 18));
        class3.setColumns(10);
        class3.setVisible(false);
        
        class2 = new JTextField();
        class2.setBounds(549, 82, 116, 22);
        passengerpanel.add(class2);
        class2.setEditable(false);
        class2.setBackground(Color.WHITE);
        class2.setForeground(Color.BLACK);
        class2.setHorizontalAlignment(SwingConstants.CENTER);
        class2.setFont(new Font("Times New Roman", Font.BOLD, 18));
        class2.setColumns(10);
        class2.setVisible(false);
        
        class1 = new JTextField();
        class1.setBounds(549, 55, 116, 22);
        passengerpanel.add(class1);
        class1.setEditable(false);
        class1.setBackground(Color.WHITE);
        class1.setForeground(Color.BLACK);
        class1.setHorizontalAlignment(SwingConstants.CENTER);
        class1.setFont(new Font("Times New Roman", Font.BOLD, 18));
        class1.setColumns(10);
        class1.setVisible(false);
        
        JLabel lblclass = new JLabel("Class");
        lblclass.setBounds(549, 13, 116, 29);
        passengerpanel.add(lblclass);
        lblclass.setFont(new Font("Times New Roman", Font.BOLD, 16));
        lblclass.setHorizontalAlignment(SwingConstants.CENTER);
        
        JLabel lblNewLabel_4 = new JLabel("Confirmation message will be sent to the first mobile number provided.");
        lblNewLabel_4.setHorizontalAlignment(SwingConstants.CENTER);
        lblNewLabel_4.setFont(new Font("Times New Roman", Font.BOLD, 18));
        lblNewLabel_4.setForeground(Color.RED);
        lblNewLabel_4.setBounds(12, 172, 653, 29);
        passengerpanel.add(lblNewLabel_4);
        
        source = new JTextField();
        source.setHorizontalAlignment(SwingConstants.CENTER);
        source.setFont(new Font("Times New Roman", Font.BOLD, 16));
        source.setBounds(22, 76, 141, 22);
        frame.getContentPane().add(source);
        source.setColumns(10);
        
        dest = new JTextField();
        dest.setHorizontalAlignment(SwingConstants.CENTER);
        dest.setFont(new Font("Times New Roman", Font.BOLD, 16));
        dest.setBounds(175, 76, 133, 22);
        frame.getContentPane().add(dest);
        dest.setColumns(10);
        
        JButton btnSearch = new JButton("Search");
        btnSearch.setBounds(483, 75, 126, 25);
        btnSearch.setForeground(Color.DARK_GRAY);
        btnSearch.setFont(new Font("Times New Roman", Font.BOLD, 16));
        btnSearch.addActionListener(new ActionListener() {
        	public void actionPerformed(ActionEvent arg0) {
        		update();
        	}
        });
        frame.getContentPane().add(btnSearch);
        
        Label Flightid = new Label("Flight ID");
        Flightid.setFont(new Font("Times New Roman", Font.BOLD, 16));
        Flightid.setBounds(25, 106, 97, 24);
        Flightid.setAlignment(Label.CENTER);
        frame.getContentPane().add(Flightid);
        
        Label label_1 = new Label("Flight Name");
        label_1.setFont(new Font("Times New Roman", Font.BOLD, 16));
        label_1.setBounds(128, 106, 92, 24);
        label_1.setAlignment(Label.CENTER);
        frame.getContentPane().add(label_1);
        
        Label label_2 = new Label("Source");
        label_2.setFont(new Font("Times New Roman", Font.BOLD, 16));
        label_2.setBounds(226, 106, 82, 24);
        label_2.setAlignment(Label.CENTER);
        frame.getContentPane().add(label_2);
        
        Label label_3 = new Label("Departure");
        label_3.setFont(new Font("Times New Roman", Font.BOLD, 16));
        label_3.setBounds(323, 106, 82, 24);
        label_3.setAlignment(Label.CENTER);
        frame.getContentPane().add(label_3);
        
        Label label_4 = new Label("Destination");
        label_4.setFont(new Font("Times New Roman", Font.BOLD, 16));
        label_4.setBounds(414, 106, 98, 24);
        label_4.setAlignment(Label.CENTER);
        frame.getContentPane().add(label_4);
        
        Label label_5 = new Label("Arrival");
        label_5.setFont(new Font("Times New Roman", Font.BOLD, 16));
        label_5.setBounds(504, 106, 105, 24);
        label_5.setAlignment(Label.CENTER);
        frame.getContentPane().add(label_5);
        
        dateofjourney = new JTextField();
        dateofjourney.setEditable(false);
        dateofjourney.setHorizontalAlignment(SwingConstants.CENTER);
        dateofjourney.addFocusListener(new FocusAdapter() {
        	@Override
        	public void focusGained(FocusEvent arg0) {
        		dateofjourney.setEditable(true);
        		dateofjourney.setText("");
        		
        	}
        });
        dateofjourney.setForeground(Color.BLACK);
        dateofjourney.setText("DD/MM/YYYY");
        dateofjourney.setFont(new Font("Times New Roman", Font.BOLD, 16));
        dateofjourney.setBounds(324, 76, 147, 22);
        frame.getContentPane().add(dateofjourney);
        dateofjourney.setColumns(10);
        
        JLabel lblNewLabel_2 = new JLabel("Source");
        lblNewLabel_2.setHorizontalAlignment(SwingConstants.CENTER);
        lblNewLabel_2.setBounds(35, 54, 116, 22);
        lblNewLabel_2.setFont(new Font("Times New Roman", Font.BOLD, 16));
        frame.getContentPane().add(lblNewLabel_2);
        
        JLabel lblDestination = new JLabel("Destination");
        lblDestination.setHorizontalAlignment(SwingConstants.CENTER);
        lblDestination.setBounds(182, 54, 116, 22);
        lblDestination.setFont(new Font("Times New Roman", Font.BOLD, 16));
        frame.getContentPane().add(lblDestination);
        
        JLabel lblDateOfJourney = new JLabel("Date Of Journey");
        lblDateOfJourney.setHorizontalAlignment(SwingConstants.CENTER);
        lblDateOfJourney.setBounds(342, 54, 116, 22);
        lblDateOfJourney.setFont(new Font("Times New Roman", Font.BOLD, 16));
        frame.getContentPane().add(lblDateOfJourney);
        

        JButton confirm = new JButton("Proceed to Payments");
        confirm.setIcon(new ImageIcon(Booking.class.getResource("/airlineimages/credit.png")));
        confirm.setVisible(false);
        confirm.setForeground(Color.DARK_GRAY);
        confirm.setFont(new Font("Times New Roman", Font.BOLD, 26));
        confirm.addActionListener(new ActionListener() {
        	public void actionPerformed(ActionEvent arg0) {
        		
        		try {
					Class.forName("com.mysql.jdbc.Driver");
					Connection con=DriverManager.getConnection("jdbc:mysql://localhost:3306/airline","root","root");
					Statement stmt=con.createStatement();
					
					if(c==1)
					{	
						String gender11=gender1.getSelectedItem().toString();
						String sql="insert into reserve (seatid,TicketID,name,age,gender,mob,class,fid,doj) values ('"+seat1.getText()+"','"+TicketID.getText()+"','"+name1.getText()+"','"+age1.getText()+"','"+gender11+"','"+mob1.getText()+"','"+class1.getText()+"','"+fid.getText()+"','"+doj.getText()+"')";
						stmt.executeUpdate(sql);
						
					}
					if(c==2)
					{	
						String gender11=gender1.getSelectedItem().toString();
						String gender12=gender2.getSelectedItem().toString();
						String sql="insert into reserve (seatid,TicketID,name,age,gender,mob,class,fid,doj) values ('"+seat1.getText()+"','"+TicketID.getText()+"','"+name1.getText()+"','"+age1.getText()+"','"+gender11+"','"+mob1.getText()+"','"+class1.getText()+"','"+fid.getText()+"','"+doj.getText()+"')";
						String sql1="insert into reserve (seatid,TicketID,name,age,gender,mob,class,fid,doj) values ('"+seat2.getText()+"','"+TicketID.getText()+"','"+name2.getText()+"','"+age2.getText()+"','"+gender12+"','"+mob2.getText()+"','"+class2.getText()+"','"+fid.getText()+"','"+doj.getText()+"')";
						stmt.executeUpdate(sql);
						stmt.executeUpdate(sql1);
						
					}
					if(c==3)
					{
						
						String gender11=gender1.getSelectedItem().toString();
						String gender12=gender2.getSelectedItem().toString();
						String gender13=gender3.getSelectedItem().toString();
						String sql1="insert into reserve (seatid,TicketID,name,age,gender,mob,class,fid,doj) values ('"+seat1.getText()+"','"+TicketID.getText()+"','"+name1.getText()+"','"+age1.getText()+"','"+gender11+"','"+mob1.getText()+"','"+class1.getText()+"','"+fid.getText()+"','"+doj.getText()+"')";
						String sql2="insert into reserve (seatid,TicketID,name,age,gender,mob,class,fid,doj) values ('"+seat2.getText()+"','"+TicketID.getText()+"','"+name2.getText()+"','"+age2.getText()+"','"+gender12+"','"+mob2.getText()+"','"+class2.getText()+"','"+fid.getText()+"','"+doj.getText()+"')";
						String sql3="insert into reserve (seatid,TicketID,name,age,gender,mob,class,fid,doj) values ('"+seat3.getText()+"','"+TicketID.getText()+"','"+name3.getText()+"','"+age3.getText()+"','"+gender13+"','"+mob3.getText()+"','"+class3.getText()+"','"+fid.getText()+"','"+doj.getText()+"')";
						stmt.executeUpdate(sql1);
						stmt.executeUpdate(sql2);
						stmt.executeUpdate(sql3);
						
						
					}
					if(c==4)
					{
						
						String gender11=gender1.getSelectedItem().toString();
						String gender12=gender2.getSelectedItem().toString();
						String gender13=gender3.getSelectedItem().toString();
						String gender14=gender4.getSelectedItem().toString();
						String sql1="insert into reserve (seatid,TicketID,name,age,gender,mob,class,fid,doj) values ('"+seat1.getText()+"','"+TicketID.getText()+"','"+name1.getText()+"','"+age1.getText()+"','"+gender11+"','"+mob1.getText()+"','"+class1.getText()+"','"+fid.getText()+"','"+doj.getText()+"')";
						String sql2="insert into reserve (seatid,TicketID,name,age,gender,mob,class,fid,doj) values ('"+seat2.getText()+"','"+TicketID.getText()+"','"+name2.getText()+"','"+age2.getText()+"','"+gender12+"','"+mob2.getText()+"','"+class2.getText()+"','"+fid.getText()+"','"+doj.getText()+"')";
						String sql3="insert into reserve (seatid,TicketID,name,age,gender,mob,class,fid,doj) values ('"+seat3.getText()+"','"+TicketID.getText()+"','"+name3.getText()+"','"+age3.getText()+"','"+gender13+"','"+mob3.getText()+"','"+class3.getText()+"','"+fid.getText()+"','"+doj.getText()+"')";
						String sql4="insert into reserve (seatid,TicketID,name,age,gender,mob,class,fid,doj) values ('"+seat4.getText()+"','"+TicketID.getText()+"','"+name4.getText()+"','"+age4.getText()+"','"+gender14+"','"+mob4.getText()+"','"+class4.getText()+"','"+fid.getText()+"','"+doj.getText()+"')";
						
						stmt.executeUpdate(sql1);
						stmt.executeUpdate(sql2);
						stmt.executeUpdate(sql3);
						stmt.executeUpdate(sql4);
					}
					CreditCardDetails.CreditCardDetails();
					SMS sms = new SMS();
	            	sms.SendSMS("guru16529", "Gmh@1999", "Your ticket is reserved and your Ticket ID is:"+TicketID.getText()+"Thank You", "91"+mob1.getText(), "https://bulksms.vsms.net/eapi/submission/send_sms/2/2.0\r\n");
						
				} catch (ClassNotFoundException | SQLException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
				
			}
        	
        });
        confirm.setBounds(183, 654, 321, 55);
        panel_2.add(confirm);

        JButton submit = new JButton("Submit");
        submit.setVisible(false);
        submit.setBounds(230, 798, 98, 25);
        submit.setForeground(Color.DARK_GRAY);
        submit.setFont(new Font("Times New Roman", Font.BOLD, 16));
        submit.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent arg0) {
            	int bp=0 ,abc=0;
            	lblpassengerDetails.setVisible(true);
            	passengerpanel.setVisible(true);
            	lblGrandTotal.setVisible(true);
            	total.setVisible(true);
            	confirm.setVisible(true);
            	if(sc.getText().equals("Business"))
            	{
            	try {

                    Class.forName("com.mysql.jdbc.Driver");
                    Connection con = DriverManager.getConnection("jdbc:mysql://localhost:3306/airline", "root", "root");
                    Statement stmt = con.createStatement();
                    String sql1="select * from flightdetails where fid='"+fid.getText()+"'";
					rs=stmt.executeQuery(sql1);
					while(rs.next())
					{
						bp=Integer.parseInt(rs.getString("prbc"));
					}
					if(c>4)
                	{
                		JOptionPane.showMessageDialog(null,"only 4 booking allowed at a time");
                		
                	}
                    if (S1.isSelected()) {
                    	if(c>4)
                    	{
                    		JOptionPane.showMessageDialog(null,"only 4 booking allowed at a time");
                    	}
                    	if(seat1.getText().equals("") && class1.getText().equals(""))
    					{
    						class1.setText("Business");
    						seat1.setText("1");
    					}
    					else if(seat2.getText().equals("") && class2.getText().equals(""))
    					{
    						class2.setText("Business");
    						seat2.setText("1");
    					}
    					else if(seat3.getText().equals("") && class3.getText().equals(""))
    					{
    						class3.setText("Business");
    						seat3.setText("1");
    					}
    					else
    					{
    						class4.setText("Business");;
    						seat4.setText("1");
    					}	
    					c++;
    					
                    }

                    if (S2.isSelected()) {
                    	if(seat1.getText().equals("") && class1.getText().equals(""))
    					{
    						class1.setText("Business");
    						seat1.setText("2");
    					}
    					else if(seat2.getText().equals("") && class2.getText().equals(""))
    					{
    						class2.setText("Business");
    						seat2.setText("2");
    					}
    					else if(seat3.getText().equals("") && class3.getText().equals(""))
    					{
    						class3.setText("Business");
    						seat3.setText("2");
    					}
    					else
    					{
    						class4.setText("Business");;
    						seat4.setText("2");
    					}	
    					c++;
                    }

                    if (S3.isSelected()) {
                    	if(seat1.getText().equals("") && class1.getText().equals(""))
    					{
    						class1.setText("Business");
    						seat1.setText("3");
    					}
    					else if(seat2.getText().equals("") && class2.getText().equals(""))
    					{
    						class2.setText("Business");
    						seat2.setText("3");
    					}
    					else if(seat3.getText().equals("") && class3.getText().equals(""))
    					{
    						class3.setText("Business");
    						seat3.setText("3");
    					}
    					else
    					{
    						class4.setText("Business");;
    						seat4.setText("3");
    					}	
    					c++;
                    }

                    if (S4.isSelected()) {
                    	if(seat1.getText().equals("") && class1.getText().equals(""))
    					{
    						class1.setText("Business");
    						seat1.setText("4");
    					}
    					else if(seat2.getText().equals("") && class2.getText().equals(""))
    					{
    						class2.setText("Business");
    						seat2.setText("4");
    					}
    					else if(seat3.getText().equals("") && class3.getText().equals(""))
    					{
    						class3.setText("Business");
    						seat3.setText("4");
    					}
    					else
    					{
    						class4.setText("Business");;
    						seat4.setText("4");
    					}	
    					c++;
                    }

                    if (S5.isSelected()) {
                    	if(seat1.getText().equals("") && class1.getText().equals(""))
    					{
    						class1.setText("Business");
    						seat1.setText("5");
    					}
    					else if(seat2.getText().equals("") && class2.getText().equals(""))
    					{
    						class2.setText("Business");
    						seat2.setText("5");
    					}
    					else if(seat3.getText().equals("") && class3.getText().equals(""))
    					{
    						class3.setText("Business");
    						seat3.setText("5");
    					}
    					else
    					{
    						class4.setText("Business");;
    						seat4.setText("5");
    					}	
    					c++;
                    }

                    if (S6.isSelected()) {
                    	if(seat1.getText().equals("") && class1.getText().equals(""))
    					{
    						class1.setText("Business");
    						seat1.setText("6");
    					}
    					else if(seat2.getText().equals("") && class2.getText().equals(""))
    					{
    						class2.setText("Business");
    						seat2.setText("6");
    					}
    					else if(seat3.getText().equals("") && class3.getText().equals(""))
    					{
    						class3.setText("Business");
    						seat3.setText("6");
    					}
    					else
    					{
    						class4.setText("Business");;
    						seat4.setText("6");
    					}	
    					c++;
                    }

                    if (S7.isSelected()) {
                    	if(seat1.getText().equals("") && class1.getText().equals(""))
    					{
    						class1.setText("Business");
    						seat1.setText("7");
    					}
    					else if(seat2.getText().equals("") && class2.getText().equals(""))
    					{
    						class2.setText("Business");
    						seat2.setText("7");
    					}
    					else if(seat3.getText().equals("") && class3.getText().equals(""))
    					{
    						class3.setText("Business");
    						seat3.setText("7");
    					}
    					else
    					{
    						class4.setText("Business");;
    						seat4.setText("7");
    					}	
    					c++;
                    }

                    if (S8.isSelected()) {
                    	if(seat1.getText().equals("") && class1.getText().equals(""))
    					{
    						class1.setText("Business");
    						seat1.setText("8");
    					}
    					else if(seat2.getText().equals("") && class2.getText().equals(""))
    					{
    						class2.setText("Business");
    						seat2.setText("8");
    					}
    					else if(seat3.getText().equals("") && class3.getText().equals(""))
    					{
    						class3.setText("Business");
    						seat3.setText("8");
    					}
    					else
    					{
    						class4.setText("Business");;
    						seat4.setText("8");
    					}	
    					c++;
                    }

                    if (S9.isSelected()) {
                    	if(seat1.getText().equals("") && class1.getText().equals(""))
    					{
    						class1.setText("Business");
    						seat1.setText("9");
    					}
    					else if(seat2.getText().equals("") && class2.getText().equals(""))
    					{
    						class2.setText("Business");
    						seat2.setText("9");
    					}
    					else if(seat3.getText().equals("") && class3.getText().equals(""))
    					{
    						class3.setText("Business");
    						seat3.setText("9");
    					}
    					else
    					{
    						class4.setText("Business");;
    						seat4.setText("9");
    					}	
    					c++;
                    }

                    if (S10.isSelected()) {
                    	if(seat1.getText().equals("") && class1.getText().equals(""))
    					{
    						class1.setText("Business");
    						seat1.setText("10");
    					}
    					else if(seat2.getText().equals("") && class2.getText().equals(""))
    					{
    						class2.setText("Business");
    						seat2.setText("10");
    					}
    					else if(seat3.getText().equals("") && class3.getText().equals(""))
    					{
    						class3.setText("Business");
    						seat3.setText("10");
    					}
    					else
    					{
    						class4.setText("Business");;
    						seat4.setText("10");
    					}	
    					c++;
                    }

                    if (S11.isSelected()) {
                    	if(seat1.getText().equals("") && class1.getText().equals(""))
    					{
    						class1.setText("Business");
    						seat1.setText("11");
    					}
    					else if(seat2.getText().equals("") && class2.getText().equals(""))
    					{
    						class2.setText("Business");
    						seat2.setText("11");
    					}
    					else if(seat3.getText().equals("") && class3.getText().equals(""))
    					{
    						class3.setText("Business");
    						seat3.setText("11");
    					}
    					else
    					{
    						class4.setText("Business");;
    						seat4.setText("11");
    					}	
    					c++;
                    }

                    if (S12.isSelected()) {
                    	if(seat1.getText().equals("") && class1.getText().equals(""))
    					{
    						class1.setText("Business");
    						seat1.setText("12");
    					}
    					else if(seat2.getText().equals("") && class2.getText().equals(""))
    					{
    						class2.setText("Business");
    						seat2.setText("12");
    					}
    					else if(seat3.getText().equals("") && class3.getText().equals(""))
    					{
    						class3.setText("Business");
    						seat3.setText("12");
    					}
    					else
    					{
    						class4.setText("Business");;
    						seat4.setText("12");
    					}	
    					c++;
                    }

                    if (S13.isSelected()) {
                    	if(seat1.getText().equals("") && class1.getText().equals(""))
    					{
    						class1.setText("Business");
    						seat1.setText("13");
    					}
    					else if(seat2.getText().equals("") && class2.getText().equals(""))
    					{
    						class2.setText("Business");
    						seat2.setText("13");
    					}
    					else if(seat3.getText().equals("") && class3.getText().equals(""))
    					{
    						class3.setText("Business");
    						seat3.setText("13");
    					}
    					else
    					{
    						class4.setText("Business");;
    						seat4.setText("13");
    					}	
    					c++;
                    }

                    if (S14.isSelected()) {
                    	if(seat1.getText().equals("") && class1.getText().equals(""))
    					{
    						class1.setText("Business");
    						seat1.setText("14");
    					}
    					else if(seat2.getText().equals("") && class2.getText().equals(""))
    					{
    						class2.setText("Business");
    						seat2.setText("14");
    					}
    					else if(seat3.getText().equals("") && class3.getText().equals(""))
    					{
    						class3.setText("Business");
    						seat3.setText("14");
    					}
    					else
    					{
    						class4.setText("Business");;
    						seat4.setText("14");
    					}	
    					c++;
                    }

                    if (S15.isSelected()) {
                    	if(seat1.getText().equals("") && class1.getText().equals(""))
    					{
    						class1.setText("Business");
    						seat1.setText("15");
    					}
    					else if(seat2.getText().equals("") && class2.getText().equals(""))
    					{
    						class2.setText("Business");
    						seat2.setText("15");
    					}
    					else if(seat3.getText().equals("") && class3.getText().equals(""))
    					{
    						class3.setText("Business");
    						seat3.setText("15");
    					}
    					else
    					{
    						class4.setText("Business");;
    						seat4.setText("15");
    					}	
    					c++;
                    }

                    if (S16.isSelected()) {
                    	if(seat1.getText().equals("") && class1.getText().equals(""))
    					{
    						class1.setText("Business");
    						seat1.setText("16");
    					}
    					else if(seat2.getText().equals("") && class2.getText().equals(""))
    					{
    						class2.setText("Business");
    						seat2.setText("16");
    					}
    					else if(seat3.getText().equals("") && class3.getText().equals(""))
    					{
    						class3.setText("Business");
    						seat3.setText("16");
    					}
    					else
    					{
    						class4.setText("Business");;
    						seat4.setText("16");
    					}	
    					c++;
                    }

                    if (S17.isSelected()) {
                    	if(seat1.getText().equals("") && class1.getText().equals(""))
    					{
    						class1.setText("Business");
    						seat1.setText("17");
    					}
    					else if(seat2.getText().equals("") && class2.getText().equals(""))
    					{
    						class2.setText("Business");
    						seat2.setText("17");
    					}
    					else if(seat3.getText().equals("") && class3.getText().equals(""))
    					{
    						class3.setText("Business");
    						seat3.setText("17");
    					}
    					else
    					{
    						class4.setText("Business");;
    						seat4.setText("17");
    					}	
    					c++;
                    }

                    if (S18.isSelected()) {
                    	if(seat1.getText().equals("") && class1.getText().equals(""))
    					{
    						class1.setText("Business");
    						seat1.setText("18");
    					}
    					else if(seat2.getText().equals("") && class2.getText().equals(""))
    					{
    						class2.setText("Business");
    						seat2.setText("18");
    					}
    					else if(seat3.getText().equals("") && class3.getText().equals(""))
    					{
    						class3.setText("Business");
    						seat3.setText("18");
    					}
    					else
    					{
    						class4.setText("Business");;
    						seat4.setText("18");
    					}	
    					c++;
                    }

                    if (S19.isSelected()) {
                    	if(seat1.getText().equals("") && class1.getText().equals(""))
    					{
    						class1.setText("Business");
    						seat1.setText("19");
    					}
    					else if(seat2.getText().equals("") && class2.getText().equals(""))
    					{
    						class2.setText("Business");
    						seat2.setText("19");
    					}
    					else if(seat3.getText().equals("") && class3.getText().equals(""))
    					{
    						class3.setText("Business");
    						seat3.setText("19");
    					}
    					else
    					{
    						class4.setText("Business");;
    						seat4.setText("19");
    					}	
    					c++;
                    }

                    if (S20.isSelected()) {
                    	if(seat1.getText().equals("") && class1.getText().equals(""))
    					{
    						class1.setText("Business");
    						seat1.setText("20");
    					}
    					else if(seat2.getText().equals("") && class2.getText().equals(""))
    					{
    						class2.setText("Business");
    						seat2.setText("20");
    					}
    					else if(seat3.getText().equals("") && class3.getText().equals(""))
    					{
    						class3.setText("Business");
    						seat3.setText("20");
    					}
    					else
    					{
    						class4.setText("Business");;
    						seat4.setText("20");
    					}	
    					c++;
                    }

                    if (S21.isSelected()) {
                    	if(seat1.getText().equals("") && class1.getText().equals(""))
    					{
    						class1.setText("Business");
    						seat1.setText("21");
    					}
    					else if(seat2.getText().equals("") && class2.getText().equals(""))
    					{
    						class2.setText("Business");
    						seat2.setText("21");
    					}
    					else if(seat3.getText().equals("") && class3.getText().equals(""))
    					{
    						class3.setText("Business");
    						seat3.setText("21");
    					}
    					else
    					{
    						class4.setText("Business");;
    						seat4.setText("21");
    					}	
    					c++;
                    }

                    if (S22.isSelected()) {
                    	if(seat1.getText().equals("") && class1.getText().equals(""))
    					{
    						class1.setText("Business");
    						seat1.setText("22");
    					}
    					else if(seat2.getText().equals("") && class2.getText().equals(""))
    					{
    						class2.setText("Business");
    						seat2.setText("22");
    					}
    					else if(seat3.getText().equals("") && class3.getText().equals(""))
    					{
    						class3.setText("Business");
    						seat3.setText("22");
    					}
    					else
    					{
    						class4.setText("Business");;
    						seat4.setText("22");
    					}	
    					c++;
                    }

                    if (S23.isSelected()) {
                    	if(seat1.getText().equals("") && class1.getText().equals(""))
    					{
    						class1.setText("Business");
    						seat1.setText("23");
    					}
    					else if(seat2.getText().equals("") && class2.getText().equals(""))
    					{
    						class2.setText("Business");
    						seat2.setText("23");
    					}
    					else if(seat3.getText().equals("") && class3.getText().equals(""))
    					{
    						class3.setText("Business");
    						seat3.setText("23");
    					}
    					else
    					{
    						class4.setText("Business");;
    						seat4.setText("23");
    					}	
    					c++;
                    }

                    if (S24.isSelected()) {
                    	if(seat1.getText().equals("") && class1.getText().equals(""))
    					{
    						class1.setText("Business");
    						seat1.setText("24");
    					}
    					else if(seat2.getText().equals("") && class2.getText().equals(""))
    					{
    						class2.setText("Business");
    						seat2.setText("24");
    					}
    					else if(seat3.getText().equals("") && class3.getText().equals(""))
    					{
    						class3.setText("Business");
    						seat3.setText("24");
    					}
    					else
    					{
    						class4.setText("Business");;
    						seat4.setText("24");
    					}	
    					c++;
                    }

                    if (S25.isSelected()) {
                    	if(seat1.getText().equals("") && class1.getText().equals(""))
    					{
    						class1.setText("Business");
    						seat1.setText("25");
    					}
    					else if(seat2.getText().equals("") && class2.getText().equals(""))
    					{
    						class2.setText("Business");
    						seat2.setText("25");
    					}
    					else if(seat3.getText().equals("") && class3.getText().equals(""))
    					{
    						class3.setText("Business");
    						seat3.setText("25");
    					}
    					else
    					{
    						class4.setText("Business");;
    						seat4.setText("25");
    					}	
    					c++;
                    }

                    if (S26.isSelected()) {
                    	if(seat1.getText().equals("") && class1.getText().equals(""))
    					{
    						class1.setText("Business");
    						seat1.setText("26");
    					}
    					else if(seat2.getText().equals("") && class2.getText().equals(""))
    					{
    						class2.setText("Business");
    						seat2.setText("26");
    					}
    					else if(seat3.getText().equals("") && class3.getText().equals(""))
    					{
    						class3.setText("Business");
    						seat3.setText("26");
    					}
    					else
    					{
    						class4.setText("Business");;
    						seat4.setText("26");
    					}	
    					c++;
                    }

                    if (S27.isSelected()) {
                    	if(seat1.getText().equals("") && class1.getText().equals(""))
    					{
    						class1.setText("Business");
    						seat1.setText("27");
    					}
    					else if(seat2.getText().equals("") && class2.getText().equals(""))
    					{
    						class2.setText("Business");
    						seat2.setText("27");
    					}
    					else if(seat3.getText().equals("") && class3.getText().equals(""))
    					{
    						class3.setText("Business");
    						seat3.setText("27");
    					}
    					else
    					{
    						class4.setText("Business");;
    						seat4.setText("27");
    					}	
    					c++;
                    }

                    if (S28.isSelected()) {
                    	if(seat1.getText().equals("") && class1.getText().equals(""))
    					{
    						class1.setText("Business");
    						seat1.setText("28");
    					}
    					else if(seat2.getText().equals("") && class2.getText().equals(""))
    					{
    						class2.setText("Business");
    						seat2.setText("28");
    					}
    					else if(seat3.getText().equals("") && class3.getText().equals(""))
    					{
    						class3.setText("Business");
    						seat3.setText("28");
    					}
    					else
    					{
    						class4.setText("Business");;
    						seat4.setText("28");
    					}	
    					c++;
                    }

                    if (S29.isSelected()) {
                    	if(seat1.getText().equals("") && class1.getText().equals(""))
    					{
    						class1.setText("Business");
    						seat1.setText("29");
    					}
    					else if(seat2.getText().equals("") && class2.getText().equals(""))
    					{
    						class2.setText("Business");
    						seat2.setText("29");
    					}
    					else if(seat3.getText().equals("") && class3.getText().equals(""))
    					{
    						class3.setText("Business");
    						seat3.setText("29");
    					}
    					else
    					{
    						class4.setText("Business");;
    						seat4.setText("29");
    					}	
    					c++;
                    }

                    if (S30.isSelected()) {
                    	if(seat1.getText().equals("") && class1.getText().equals(""))
    					{
    						class1.setText("Business");
    						seat1.setText("30");
    					}
    					else if(seat2.getText().equals("") && class2.getText().equals(""))
    					{
    						class2.setText("Business");
    						seat2.setText("30");
    					}
    					else if(seat3.getText().equals("") && class3.getText().equals(""))
    					{
    						class3.setText("Business");
    						seat3.setText("30");
    					}
    					else
    					{
    						class4.setText("Business");;
    						seat4.setText("30");
    					}	
    					c++;
                    }

                    if (S31.isSelected()) {
                    	if(seat1.getText().equals("") && class1.getText().equals(""))
    					{
    						class1.setText("Business");
    						seat1.setText("31");
    					}
    					else if(seat2.getText().equals("") && class2.getText().equals(""))
    					{
    						class2.setText("Business");
    						seat2.setText("31");
    					}
    					else if(seat3.getText().equals("") && class3.getText().equals(""))
    					{
    						class3.setText("Business");
    						seat3.setText("31");
    					}
    					else
    					{
    						class4.setText("Business");;
    						seat4.setText("31");
    					}	
    					c++;
                    }

                    if (S32.isSelected()) {
                    	if(seat1.getText().equals("") && class1.getText().equals(""))
    					{
    						class1.setText("Business");
    						seat1.setText("32");
    					}
    					else if(seat2.getText().equals("") && class2.getText().equals(""))
    					{
    						class2.setText("Business");
    						seat2.setText("32");
    					}
    					else if(seat3.getText().equals("") && class3.getText().equals(""))
    					{
    						class3.setText("Business");
    						seat3.setText("32");
    					}
    					else
    					{
    						class4.setText("Business");;
    						seat4.setText("32");
    					}	
    					c++;
                    }

                    if (S33.isSelected()) {
                    	if(seat1.getText().equals("") && class1.getText().equals(""))
    					{
    						class1.setText("Business");
    						seat1.setText("33");
    					}
    					else if(seat2.getText().equals("") && class2.getText().equals(""))
    					{
    						class2.setText("Business");
    						seat2.setText("33");
    					}
    					else if(seat3.getText().equals("") && class3.getText().equals(""))
    					{
    						class3.setText("Business");
    						seat3.setText("33");
    					}
    					else
    					{
    						class4.setText("Business");;
    						seat4.setText("33");
    					}	
    					c++;
                    }

                    if (S34.isSelected()) {
                    	if(seat1.getText().equals("") && class1.getText().equals(""))
    					{
    						class1.setText("Business");
    						seat1.setText("34");
    					}
    					else if(seat2.getText().equals("") && class2.getText().equals(""))
    					{
    						class2.setText("Business");
    						seat2.setText("34");
    					}
    					else if(seat3.getText().equals("") && class3.getText().equals(""))
    					{
    						class3.setText("Business");
    						seat3.setText("34");
    					}
    					else
    					{
    						class4.setText("Business");;
    						seat4.setText("34");
    					}	
    					c++;
                    }

                    if (S35.isSelected()) {
                    	if(seat1.getText().equals("") && class1.getText().equals(""))
    					{
    						class1.setText("Business");
    						seat1.setText("35");
    					}
    					else if(seat2.getText().equals("") && class2.getText().equals(""))
    					{
    						class2.setText("Business");
    						seat2.setText("35");
    					}
    					else if(seat3.getText().equals("") && class3.getText().equals(""))
    					{
    						class3.setText("Business");
    						seat3.setText("35");
    					}
    					else
    					{
    						class4.setText("Business");;
    						seat4.setText("35");
    					}	
    					c++;
                    }

                    if (S36.isSelected()) {
                    	if(seat1.getText().equals("") && class1.getText().equals(""))
    					{
    						class1.setText("Business");
    						seat1.setText("36");
    					}
    					else if(seat2.getText().equals("") && class2.getText().equals(""))
    					{
    						class2.setText("Business");
    						seat2.setText("36");
    					}
    					else if(seat3.getText().equals("") && class3.getText().equals(""))
    					{
    						class3.setText("Business");
    						seat3.setText("36");
    					}
    					else
    					{
    						class4.setText("Business");;
    						seat4.setText("36");
    					}	
    					c++;
                    }

                    if (S37.isSelected()) {
                    	if(seat1.getText().equals("") && class1.getText().equals(""))
    					{
    						class1.setText("Business");
    						seat1.setText("37");
    					}
    					else if(seat2.getText().equals("") && class2.getText().equals(""))
    					{
    						class2.setText("Business");
    						seat2.setText("37");
    					}
    					else if(seat3.getText().equals("") && class3.getText().equals(""))
    					{
    						class3.setText("Business");
    						seat3.setText("37");
    					}
    					else
    					{
    						class4.setText("Business");;
    						seat4.setText("37");
    					}	
    					c++;
                    }

                    if (S38.isSelected()) {
                    	if(seat1.getText().equals("") && class1.getText().equals(""))
    					{
    						class1.setText("Business");
    						seat1.setText("38");
    					}
    					else if(seat2.getText().equals("") && class2.getText().equals(""))
    					{
    						class2.setText("Business");
    						seat2.setText("38");
    					}
    					else if(seat3.getText().equals("") && class3.getText().equals(""))
    					{
    						class3.setText("Business");
    						seat3.setText("38");
    					}
    					else
    					{
    						class4.setText("Business");;
    						seat4.setText("38");
    					}	
    					c++;
                    }

                    if (S39.isSelected()) {
                    	if(seat1.getText().equals("") && class1.getText().equals(""))
    					{
    						class1.setText("Business");
    						seat1.setText("39");
    					}
    					else if(seat2.getText().equals("") && class2.getText().equals(""))
    					{
    						class2.setText("Business");
    						seat2.setText("39");
    					}
    					else if(seat3.getText().equals("") && class3.getText().equals(""))
    					{
    						class3.setText("Business");
    						seat3.setText("39");
    					}
    					else
    					{
    						class4.setText("Business");;
    						seat4.setText("39");
    					}	
    					c++;
                    }

                    if (S40.isSelected()) {
                    	if(seat1.getText().equals("") && class1.getText().equals(""))
    					{
    						class1.setText("Business");
    						seat1.setText("40");
    					}
    					else if(seat2.getText().equals("") && class2.getText().equals(""))
    					{
    						class2.setText("Business");
    						seat2.setText("40");
    					}
    					else if(seat3.getText().equals("") && class3.getText().equals(""))
    					{
    						class3.setText("Business");
    						seat3.setText("40");
    					}
    					else
    					{
    						class4.setText("Business");;
    						seat4.setText("40");
    					}	
    					c++;
                    }

                    if (S41.isSelected()) {
                    	if(seat1.getText().equals("") && class1.getText().equals(""))
    					{
    						class1.setText("Business");
    						seat1.setText("41");
    					}
    					else if(seat2.getText().equals("") && class2.getText().equals(""))
    					{
    						class2.setText("Business");
    						seat2.setText("41");
    					}
    					else if(seat3.getText().equals("") && class3.getText().equals(""))
    					{
    						class3.setText("Business");
    						seat3.setText("41");
    					}
    					else
    					{
    						class4.setText("Business");;
    						seat4.setText("41");
    					}	
    					c++;
                    }

                    if (S42.isSelected()) {
                    	if(seat1.getText().equals("") && class1.getText().equals(""))
    					{
    						class1.setText("Business");
    						seat1.setText("42");
    					}
    					else if(seat2.getText().equals("") && class2.getText().equals(""))
    					{
    						class2.setText("Business");
    						seat2.setText("42");
    					}
    					else if(seat3.getText().equals("") && class3.getText().equals(""))
    					{
    						class3.setText("Business");
    						seat3.setText("42");
    					}
    					else
    					{
    						class4.setText("Business");;
    						seat4.setText("42");
    					}	
    					c++;
                    }

                    if (S43.isSelected()) {
                    	if(seat1.getText().equals("") && class1.getText().equals(""))
    					{
    						class1.setText("Business");
    						seat1.setText("43");
    					}
    					else if(seat2.getText().equals("") && class2.getText().equals(""))
    					{
    						class2.setText("Business");
    						seat2.setText("43");
    					}
    					else if(seat3.getText().equals("") && class3.getText().equals(""))
    					{
    						class3.setText("Business");
    						seat3.setText("43");
    					}
    					else
    					{
    						class4.setText("Business");;
    						seat4.setText("43");
    					}	
    					c++;
                    }

                    if (S44.isSelected()) {
                    	if(seat1.getText().equals("") && class1.getText().equals(""))
    					{
    						class1.setText("Business");
    						seat1.setText("44");
    					}
    					else if(seat2.getText().equals("") && class2.getText().equals(""))
    					{
    						class2.setText("Business");
    						seat2.setText("44");
    					}
    					else if(seat3.getText().equals("") && class3.getText().equals(""))
    					{
    						class3.setText("Business");
    						seat3.setText("44");
    					}
    					else
    					{
    						class4.setText("Business");;
    						seat4.setText("44");
    					}	
    					c++;
                    }

                    if (S45.isSelected()) {
                    	if(seat1.getText().equals("") && class1.getText().equals(""))
    					{
    						class1.setText("Business");
    						seat1.setText("45");
    					}
    					else if(seat2.getText().equals("") && class2.getText().equals(""))
    					{
    						class2.setText("Business");
    						seat2.setText("45");
    					}
    					else if(seat3.getText().equals("") && class3.getText().equals(""))
    					{
    						class3.setText("Business");
    						seat3.setText("45");
    					}
    					else
    					{
    						class4.setText("Business");;
    						seat4.setText("45");
    					}	
    					c++;
                    }

                    if (S46.isSelected()) {
                    	if(seat1.getText().equals("") && class1.getText().equals(""))
    					{
    						class1.setText("Business");
    						seat1.setText("46");
    					}
    					else if(seat2.getText().equals("") && class2.getText().equals(""))
    					{
    						class2.setText("Business");
    						seat2.setText("46");
    					}
    					else if(seat3.getText().equals("") && class3.getText().equals(""))
    					{
    						class3.setText("Business");
    						seat3.setText("46");
    					}
    					else
    					{
    						class4.setText("Business");;
    						seat4.setText("46");
    					}	
    					c++;
                    }

                    if (S47.isSelected()) {
                    	if(seat1.getText().equals("") && class1.getText().equals(""))
    					{
    						class1.setText("Business");
    						seat1.setText("47");
    					}
    					else if(seat2.getText().equals("") && class2.getText().equals(""))
    					{
    						class2.setText("Business");
    						seat2.setText("47");
    					}
    					else if(seat3.getText().equals("") && class3.getText().equals(""))
    					{
    						class3.setText("Business");
    						seat3.setText("47");
    					}
    					else
    					{
    						class4.setText("Business");;
    						seat4.setText("47");
    					}	
    					c++;
                    }

                    if (S48.isSelected()) {
                    	if(seat1.getText().equals("") && class1.getText().equals(""))
    					{
    						class1.setText("Business");
    						seat1.setText("48");
    					}
    					else if(seat2.getText().equals("") && class2.getText().equals(""))
    					{
    						class2.setText("Business");
    						seat2.setText("48");
    					}
    					else if(seat3.getText().equals("") && class3.getText().equals(""))
    					{
    						class3.setText("Business");
    						seat3.setText("48");
    					}
    					else
    					{
    						class4.setText("Business");;
    						seat4.setText("48");
    					}	
    					c++;
                    }

                    if (S49.isSelected()) {
                    	if(seat1.getText().equals("") && class1.getText().equals(""))
    					{
    						class1.setText("Business");
    						seat1.setText("49");
    					}
    					else if(seat2.getText().equals("") && class2.getText().equals(""))
    					{
    						class2.setText("Business");
    						seat2.setText("49");
    					}
    					else if(seat3.getText().equals("") && class3.getText().equals(""))
    					{
    						class3.setText("Business");
    						seat3.setText("49");
    					}
    					else
    					{
    						class4.setText("Business");;
    						seat4.setText("49");
    					}	
    					c++;
                    }

                    if (S50.isSelected()) {
                    	if(seat1.getText().equals("") && class1.getText().equals(""))
    					{
    						class1.setText("Business");
    						seat1.setText("50");
    					}
    					else if(seat2.getText().equals("") && class2.getText().equals(""))
    					{
    						class2.setText("Business");
    						seat2.setText("50");
    					}
    					else if(seat3.getText().equals("") && class3.getText().equals(""))
    					{
    						class3.setText("Business");
    						seat3.setText("50");
    					}
    					else
    					{
    						class4.setText("Business");;
    						seat4.setText("50");
    					}	
    					c++;
                    }

                    if (S51.isSelected()) {
                    	if(seat1.getText().equals("") && class1.getText().equals(""))
    					{
    						class1.setText("Business");
    						seat1.setText("51");
    					}
    					else if(seat2.getText().equals("") && class2.getText().equals(""))
    					{
    						class2.setText("Business");
    						seat2.setText("51");
    					}
    					else if(seat3.getText().equals("") && class3.getText().equals(""))
    					{
    						class3.setText("Business");
    						seat3.setText("51");
    					}
    					else
    					{
    						class4.setText("Business");;
    						seat4.setText("51");
    					}	
    					c++;
                    }

                    if (S52.isSelected()) {
                    	if(seat1.getText().equals("") && class1.getText().equals(""))
    					{
    						class1.setText("Business");
    						seat1.setText("52");
    					}
    					else if(seat2.getText().equals("") && class2.getText().equals(""))
    					{
    						class2.setText("Business");
    						seat2.setText("52");
    					}
    					else if(seat3.getText().equals("") && class3.getText().equals(""))
    					{
    						class3.setText("Business");
    						seat3.setText("52");
    					}
    					else
    					{
    						class4.setText("Business");;
    						seat4.setText("52");
    					}	
    					c++;
                    }

                    if (S53.isSelected()) {
                    	if(seat1.getText().equals("") && class1.getText().equals(""))
    					{
    						class1.setText("Business");
    						seat1.setText("53");
    					}
    					else if(seat2.getText().equals("") && class2.getText().equals(""))
    					{
    						class2.setText("Business");
    						seat2.setText("53");
    					}
    					else if(seat3.getText().equals("") && class3.getText().equals(""))
    					{
    						class3.setText("Business");
    						seat3.setText("53");
    					}
    					else
    					{
    						class4.setText("Business");;
    						seat4.setText("53");
    					}	
    					c++;
                    }

                    if (S54.isSelected()) {
                    	if(seat1.getText().equals("") && class1.getText().equals(""))
    					{
    						class1.setText("Business");
    						seat1.setText("54");
    					}
    					else if(seat2.getText().equals("") && class2.getText().equals(""))
    					{
    						class2.setText("Business");
    						seat2.setText("54");
    					}
    					else if(seat3.getText().equals("") && class3.getText().equals(""))
    					{
    						class3.setText("Business");
    						seat3.setText("54");
    					}
    					else
    					{
    						class4.setText("Business");;
    						seat4.setText("45");
    					}	
    					c++;
                    }

                    if (S55.isSelected()) {
                    	if(seat1.getText().equals("") && class1.getText().equals(""))
    					{
    						class1.setText("Business");
    						seat1.setText("55");
    					}
    					else if(seat2.getText().equals("") && class2.getText().equals(""))
    					{
    						class2.setText("Business");
    						seat2.setText("55");
    					}
    					else if(seat3.getText().equals("") && class3.getText().equals(""))
    					{
    						class3.setText("Business");
    						seat3.setText("55");
    					}
    					else
    					{
    						class4.setText("Business");;
    						seat4.setText("55");
    					}	
    					c++;
                    }

                    if (S56.isSelected()) {
                    	if(seat1.getText().equals("") && class1.getText().equals(""))
    					{
    						class1.setText("Business");
    						seat1.setText("56");
    					}
    					else if(seat2.getText().equals("") && class2.getText().equals(""))
    					{
    						class2.setText("Business");
    						seat2.setText("56");
    					}
    					else if(seat3.getText().equals("") && class3.getText().equals(""))
    					{
    						class3.setText("Business");
    						seat3.setText("56");
    					}
    					else
    					{
    						class4.setText("Business");;
    						seat4.setText("56");
    					}	
    					c++;
                    }
                    abc=c*bp;
                    name.setVisible(true);
    				lblage.setVisible(true);
    				gender.setVisible(true);
    				lblmob.setVisible(true);
//    				submitform.setVisible(true);
    				lblSelectedSeat.setVisible(true);
    				lblclass.setVisible(true);
    				switch(c)
    				{
    				case 1:
    				{
    					
    					name1.setVisible(true);
    					age1.setVisible(true);
    					gender1.setVisible(true);
    					mob1.setVisible(true);
    					seat1.setVisible(true);
    					class1.setVisible(true);
    					total.setText(String.valueOf(abc));
    					break;
    				}
    				case 2:
    				{
    					name1.setVisible(true);
    					age1.setVisible(true);
    					gender1.setVisible(true);
    					mob1.setVisible(true);
    					seat1.setVisible(true);
    					class1.setVisible(true);
    					
    					name2.setVisible(true);
    					age2.setVisible(true);
    					gender2.setVisible(true);
    					mob2.setVisible(true);
    					seat2.setVisible(true);
    					class2.setVisible(true);
    					total.setText(String.valueOf(abc));
    					break;
    				}
    				case 3:
    				{
    					name1.setVisible(true);
    					age1.setVisible(true);
    					gender1.setVisible(true);
    					mob1.setVisible(true);
    					seat1.setVisible(true);
    					class1.setVisible(true);
    					
    					name2.setVisible(true);
    					age2.setVisible(true);
    					gender2.setVisible(true);
    					mob2.setVisible(true);
    					seat2.setVisible(true);
    					class2.setVisible(true);
    					
    					name3.setVisible(true);
    					age3.setVisible(true);
    					gender3.setVisible(true);
    					mob3.setVisible(true);
    					seat3.setVisible(true);
    					class3.setVisible(true);
    					total.setText(String.valueOf(abc));
    					break;
    				}
    				case 4:
    				{
    					name1.setVisible(true);
    					age1.setVisible(true);
    					gender1.setVisible(true);
    					mob1.setVisible(true);
    					seat1.setVisible(true);
    					class1.setVisible(true);
    					
    					name2.setVisible(true);
    					age2.setVisible(true);
    					gender2.setVisible(true);
    					mob2.setVisible(true);
    					seat2.setVisible(true);
    					class2.setVisible(true);
    					
    					name3.setVisible(true);
    					age3.setVisible(true);
    					gender3.setVisible(true);
    					mob3.setVisible(true);
    					seat3.setVisible(true);
    					class3.setVisible(true);
    					
    					name4.setVisible(true);
    					age4.setVisible(true);
    					gender4.setVisible(true);
    					mob4.setVisible(true);
    					seat4.setVisible(true);
    					class4.setVisible(true);
    					total.setText(String.valueOf(abc));
    					break;
    				}
    				
    				}
    				
                    JOptionPane.showMessageDialog(null, "done");
                } catch (ClassNotFoundException e1) {
                    // TODO Auto-generated catch block
                    e1.printStackTrace();
                } catch (SQLException e1) {
                    // TODO Auto-generated catch block
                    e1.printStackTrace();
                }
            	}
            	
            	if(sc.getText().equals("First"))
            	{	int fp=0,afc=0;
            	try {

                    Class.forName("com.mysql.jdbc.Driver");
                    Connection con = DriverManager.getConnection("jdbc:mysql://localhost:3306/airline", "root", "root");
                    Statement stmt = con.createStatement();
                    String sql1="select * from flightdetails where fid='"+fid.getText()+"'";
					rs=stmt.executeQuery(sql1);
					while(rs.next())
					{
						fp=Integer.parseInt(rs.getString("prfc"));
					}
                    if (S1.isSelected()) {
                    	if(seat1.getText().equals("") && class1.getText().equals(""))
    					{
    						class1.setText("First");
    						seat1.setText("1");
    					}
    					else if(seat2.getText().equals("") && class2.getText().equals(""))
    					{
    						class2.setText("First");
    						seat2.setText("1");
    					}
    					else if(seat3.getText().equals("") && class3.getText().equals(""))
    					{
    						class3.setText("First");
    						seat3.setText("1");
    					}
    					else
    					{
    						class4.setText("First");;
    						seat4.setText("1");
    					}	
    					c++;
                    }

                    if (S2.isSelected()) {
                    	if(seat1.getText().equals("") && class1.getText().equals(""))
    					{
    						class1.setText("First");
    						seat1.setText("2");
    					}
    					else if(seat2.getText().equals("") && class2.getText().equals(""))
    					{
    						class2.setText("First");
    						seat2.setText("2");
    					}
    					else if(seat3.getText().equals("") && class3.getText().equals(""))
    					{
    						class3.setText("First");
    						seat3.setText("2");
    					}
    					else
    					{
    						class4.setText("First");;
    						seat4.setText("2");
    					}	
    					c++;
                    }

                    if (S3.isSelected()) {
                    	if(seat1.getText().equals("") && class1.getText().equals(""))
    					{
    						class1.setText("First");
    						seat1.setText("3");
    					}
    					else if(seat2.getText().equals("") && class2.getText().equals(""))
    					{
    						class2.setText("First");
    						seat2.setText("3");
    					}
    					else if(seat3.getText().equals("") && class3.getText().equals(""))
    					{
    						class3.setText("First");
    						seat3.setText("3");
    					}
    					else
    					{
    						class4.setText("First");;
    						seat4.setText("3");
    					}	
    					c++;
                    }

                    if (S4.isSelected()) {
                    	if(seat1.getText().equals("") && class1.getText().equals(""))
    					{
    						class1.setText("First");
    						seat1.setText("4");
    					}
    					else if(seat2.getText().equals("") && class2.getText().equals(""))
    					{
    						class2.setText("First");
    						seat2.setText("4");
    					}
    					else if(seat3.getText().equals("") && class3.getText().equals(""))
    					{
    						class3.setText("First");
    						seat3.setText("4");
    					}
    					else
    					{
    						class4.setText("First");;
    						seat4.setText("4");
    					}	
    					c++;
                    }

                    if (S5.isSelected()) {
                    	if(seat1.getText().equals("") && class1.getText().equals(""))
    					{
    						class1.setText("First");
    						seat1.setText("5");
    					}
    					else if(seat2.getText().equals("") && class2.getText().equals(""))
    					{
    						class2.setText("First");
    						seat2.setText("5");
    					}
    					else if(seat3.getText().equals("") && class3.getText().equals(""))
    					{
    						class3.setText("First");
    						seat3.setText("5");
    					}
    					else
    					{
    						class4.setText("First");;
    						seat4.setText("5");
    					}	
    					c++;
                    }

                    if (S6.isSelected()) {
                    	if(seat1.getText().equals("") && class1.getText().equals(""))
    					{
    						class1.setText("First");
    						seat1.setText("6");
    					}
    					else if(seat2.getText().equals("") && class2.getText().equals(""))
    					{
    						class2.setText("First");
    						seat2.setText("6");
    					}
    					else if(seat3.getText().equals("") && class3.getText().equals(""))
    					{
    						class3.setText("First");
    						seat3.setText("6");
    					}
    					else
    					{
    						class4.setText("First");;
    						seat4.setText("6");
    					}	
    					c++;
                    }

                    if (S7.isSelected()) {
                    	if(seat1.getText().equals("") && class1.getText().equals(""))
    					{
    						class1.setText("First");
    						seat1.setText("7");
    					}
    					else if(seat2.getText().equals("") && class2.getText().equals(""))
    					{
    						class2.setText("First");
    						seat2.setText("7");
    					}
    					else if(seat3.getText().equals("") && class3.getText().equals(""))
    					{
    						class3.setText("First");
    						seat3.setText("7");
    					}
    					else
    					{
    						class4.setText("First");;
    						seat4.setText("7");
    					}	
    					c++;
                    }

                    if (S8.isSelected()) {
                    	if(seat1.getText().equals("") && class1.getText().equals(""))
    					{
    						class1.setText("First");
    						seat1.setText("8");
    					}
    					else if(seat2.getText().equals("") && class2.getText().equals(""))
    					{
    						class2.setText("First");
    						seat2.setText("8");
    					}
    					else if(seat3.getText().equals("") && class3.getText().equals(""))
    					{
    						class3.setText("First");
    						seat3.setText("8");
    					}
    					else
    					{
    						class4.setText("First");;
    						seat4.setText("8");
    					}	
    					c++;
                    }

                    if (S9.isSelected()) {
                    	if(seat1.getText().equals("") && class1.getText().equals(""))
    					{
    						class1.setText("First");
    						seat1.setText("9");
    					}
    					else if(seat2.getText().equals("") && class2.getText().equals(""))
    					{
    						class2.setText("First");
    						seat2.setText("9");
    					}
    					else if(seat3.getText().equals("") && class3.getText().equals(""))
    					{
    						class3.setText("First");
    						seat3.setText("9");
    					}
    					else
    					{
    						class4.setText("First");;
    						seat4.setText("9");
    					}	
    					c++;
                    }

                    if (S10.isSelected()) {
                    	if(seat1.getText().equals("") && class1.getText().equals(""))
    					{
    						class1.setText("First");
    						seat1.setText("10");
    					}
    					else if(seat2.getText().equals("") && class2.getText().equals(""))
    					{
    						class2.setText("First");
    						seat2.setText("10");
    					}
    					else if(seat3.getText().equals("") && class3.getText().equals(""))
    					{
    						class3.setText("First");
    						seat3.setText("10");
    					}
    					else
    					{
    						class4.setText("First");;
    						seat4.setText("10");
    					}	
    					c++;
                    }

                    if (S11.isSelected()) {
                    	if(seat1.getText().equals("") && class1.getText().equals(""))
    					{
    						class1.setText("First");
    						seat1.setText("11");
    					}
    					else if(seat2.getText().equals("") && class2.getText().equals(""))
    					{
    						class2.setText("First");
    						seat2.setText("11");
    					}
    					else if(seat3.getText().equals("") && class3.getText().equals(""))
    					{
    						class3.setText("First");
    						seat3.setText("11");
    					}
    					else
    					{
    						class4.setText("First");;
    						seat4.setText("11");
    					}	
    					c++;
                    }

                    if (S12.isSelected()) {
                    	if(seat1.getText().equals("") && class1.getText().equals(""))
    					{
    						class1.setText("First");
    						seat1.setText("12");
    					}
    					else if(seat2.getText().equals("") && class2.getText().equals(""))
    					{
    						class2.setText("First");
    						seat2.setText("12");
    					}
    					else if(seat3.getText().equals("") && class3.getText().equals(""))
    					{
    						class3.setText("First");
    						seat3.setText("12");
    					}
    					else
    					{
    						class4.setText("First");;
    						seat4.setText("12");
    					}	
    					c++;
                    }

                    if (S13.isSelected()) {
                    	if(seat1.getText().equals("") && class1.getText().equals(""))
    					{
    						class1.setText("First");
    						seat1.setText("13");
    					}
    					else if(seat2.getText().equals("") && class2.getText().equals(""))
    					{
    						class2.setText("First");
    						seat2.setText("13");
    					}
    					else if(seat3.getText().equals("") && class3.getText().equals(""))
    					{
    						class3.setText("First");
    						seat3.setText("13");
    					}
    					else
    					{
    						class4.setText("First");;
    						seat4.setText("13");
    					}	
    					c++;
                    }

                    if (S14.isSelected()) {
                    	if(seat1.getText().equals("") && class1.getText().equals(""))
    					{
    						class1.setText("First");
    						seat1.setText("14");
    					}
    					else if(seat2.getText().equals("") && class2.getText().equals(""))
    					{
    						class2.setText("First");
    						seat2.setText("14");
    					}
    					else if(seat3.getText().equals("") && class3.getText().equals(""))
    					{
    						class3.setText("First");
    						seat3.setText("14");
    					}
    					else
    					{
    						class4.setText("First");;
    						seat4.setText("14");
    					}	
    					c++;
                    }

                    if (S15.isSelected()) {
                    	if(seat1.getText().equals("") && class1.getText().equals(""))
    					{
    						class1.setText("First");
    						seat1.setText("15");
    					}
    					else if(seat2.getText().equals("") && class2.getText().equals(""))
    					{
    						class2.setText("First");
    						seat2.setText("15");
    					}
    					else if(seat3.getText().equals("") && class3.getText().equals(""))
    					{
    						class3.setText("First");
    						seat3.setText("15");
    					}
    					else
    					{
    						class4.setText("First");;
    						seat4.setText("15");
    					}	
    					c++;
                    }

                    if (S16.isSelected()) {
                    	if(seat1.getText().equals("") && class1.getText().equals(""))
    					{
    						class1.setText("First");
    						seat1.setText("16");
    					}
    					else if(seat2.getText().equals("") && class2.getText().equals(""))
    					{
    						class2.setText("First");
    						seat2.setText("16");
    					}
    					else if(seat3.getText().equals("") && class3.getText().equals(""))
    					{
    						class3.setText("First");
    						seat3.setText("16");
    					}
    					else
    					{
    						class4.setText("First");;
    						seat4.setText("16");
    					}	
    					c++;
                    }

                    if (S17.isSelected()) {
                    	if(seat1.getText().equals("") && class1.getText().equals(""))
    					{
    						class1.setText("First");
    						seat1.setText("17");
    					}
    					else if(seat2.getText().equals("") && class2.getText().equals(""))
    					{
    						class2.setText("First");
    						seat2.setText("17");
    					}
    					else if(seat3.getText().equals("") && class3.getText().equals(""))
    					{
    						class3.setText("First");
    						seat3.setText("17");
    					}
    					else
    					{
    						class4.setText("First");;
    						seat4.setText("17");
    					}	
    					c++;
                    }

                    if (S18.isSelected()) {
                    	if(seat1.getText().equals("") && class1.getText().equals(""))
    					{
    						class1.setText("First");
    						seat1.setText("18");
    					}
    					else if(seat2.getText().equals("") && class2.getText().equals(""))
    					{
    						class2.setText("First");
    						seat2.setText("18");
    					}
    					else if(seat3.getText().equals("") && class3.getText().equals(""))
    					{
    						class3.setText("First");
    						seat3.setText("18");
    					}
    					else
    					{
    						class4.setText("First");;
    						seat4.setText("18");
    					}	
    					c++;
                    }

                    if (S19.isSelected()) {
                    	if(seat1.getText().equals("") && class1.getText().equals(""))
    					{
    						class1.setText("First");
    						seat1.setText("19");
    					}
    					else if(seat2.getText().equals("") && class2.getText().equals(""))
    					{
    						class2.setText("First");
    						seat2.setText("19");
    					}
    					else if(seat3.getText().equals("") && class3.getText().equals(""))
    					{
    						class3.setText("First");
    						seat3.setText("19");
    					}
    					else
    					{
    						class4.setText("First");;
    						seat4.setText("19");
    					}	
    					c++;
                    }

                    if (S20.isSelected()) {
                    	if(seat1.getText().equals("") && class1.getText().equals(""))
    					{
    						class1.setText("First");
    						seat1.setText("20");
    					}
    					else if(seat2.getText().equals("") && class2.getText().equals(""))
    					{
    						class2.setText("First");
    						seat2.setText("20");
    					}
    					else if(seat3.getText().equals("") && class3.getText().equals(""))
    					{
    						class3.setText("First");
    						seat3.setText("20");
    					}
    					else
    					{
    						class4.setText("First");;
    						seat4.setText("20");
    					}	
    					c++;
                    }

                    if (S21.isSelected()) {
                    	if(seat1.getText().equals("") && class1.getText().equals(""))
    					{
    						class1.setText("First");
    						seat1.setText("21");
    					}
    					else if(seat2.getText().equals("") && class2.getText().equals(""))
    					{
    						class2.setText("First");
    						seat2.setText("21");
    					}
    					else if(seat3.getText().equals("") && class3.getText().equals(""))
    					{
    						class3.setText("First");
    						seat3.setText("21");
    					}
    					else
    					{
    						class4.setText("First");;
    						seat4.setText("21");
    					}	
    					c++;
                    }

                    if (S22.isSelected()) {
                    	if(seat1.getText().equals("") && class1.getText().equals(""))
    					{
    						class1.setText("First");
    						seat1.setText("22");
    					}
    					else if(seat2.getText().equals("") && class2.getText().equals(""))
    					{
    						class2.setText("First");
    						seat2.setText("22");
    					}
    					else if(seat3.getText().equals("") && class3.getText().equals(""))
    					{
    						class3.setText("First");
    						seat3.setText("22");
    					}
    					else
    					{
    						class4.setText("First");;
    						seat4.setText("22");
    					}	
    					c++;
                    }

                    if (S23.isSelected()) {
                    	if(seat1.getText().equals("") && class1.getText().equals(""))
    					{
    						class1.setText("First");
    						seat1.setText("23");
    					}
    					else if(seat2.getText().equals("") && class2.getText().equals(""))
    					{
    						class2.setText("First");
    						seat2.setText("23");
    					}
    					else if(seat3.getText().equals("") && class3.getText().equals(""))
    					{
    						class3.setText("First");
    						seat3.setText("23");
    					}
    					else
    					{
    						class4.setText("First");;
    						seat4.setText("23");
    					}	
    					c++;
                    }

                    if (S24.isSelected()) {
                    	if(seat1.getText().equals("") && class1.getText().equals(""))
    					{
    						class1.setText("First");
    						seat1.setText("24");
    					}
    					else if(seat2.getText().equals("") && class2.getText().equals(""))
    					{
    						class2.setText("First");
    						seat2.setText("24");
    					}
    					else if(seat3.getText().equals("") && class3.getText().equals(""))
    					{
    						class3.setText("First");
    						seat3.setText("24");
    					}
    					else
    					{
    						class4.setText("First");;
    						seat4.setText("24");
    					}	
    					c++;
                    }

                    if (S25.isSelected()) {
                    	if(seat1.getText().equals("") && class1.getText().equals(""))
    					{
    						class1.setText("First");
    						seat1.setText("25");
    					}
    					else if(seat2.getText().equals("") && class2.getText().equals(""))
    					{
    						class2.setText("First");
    						seat2.setText("25");
    					}
    					else if(seat3.getText().equals("") && class3.getText().equals(""))
    					{
    						class3.setText("First");
    						seat3.setText("25");
    					}
    					else
    					{
    						class4.setText("First");;
    						seat4.setText("25");
    					}	
    					c++;
                    }

                    if (S26.isSelected()) {
                    	if(seat1.getText().equals("") && class1.getText().equals(""))
    					{
    						class1.setText("First");
    						seat1.setText("26");
    					}
    					else if(seat2.getText().equals("") && class2.getText().equals(""))
    					{
    						class2.setText("First");
    						seat2.setText("26");
    					}
    					else if(seat3.getText().equals("") && class3.getText().equals(""))
    					{
    						class3.setText("First");
    						seat3.setText("26");
    					}
    					else
    					{
    						class4.setText("First");;
    						seat4.setText("26");
    					}	
    					c++;
                    }

                    if (S27.isSelected()) {
                    	if(seat1.getText().equals("") && class1.getText().equals(""))
    					{
    						class1.setText("First");
    						seat1.setText("27");
    					}
    					else if(seat2.getText().equals("") && class2.getText().equals(""))
    					{
    						class2.setText("First");
    						seat2.setText("27");
    					}
    					else if(seat3.getText().equals("") && class3.getText().equals(""))
    					{
    						class3.setText("First");
    						seat3.setText("27");
    					}
    					else
    					{
    						class4.setText("First");;
    						seat4.setText("27");
    					}	
    					c++;
                    }

                    if (S28.isSelected()) {
                    	if(seat1.getText().equals("") && class1.getText().equals(""))
    					{
    						class1.setText("First");
    						seat1.setText("28");
    					}
    					else if(seat2.getText().equals("") && class2.getText().equals(""))
    					{
    						class2.setText("First");
    						seat2.setText("28");
    					}
    					else if(seat3.getText().equals("") && class3.getText().equals(""))
    					{
    						class3.setText("First");
    						seat3.setText("28");
    					}
    					else
    					{
    						class4.setText("First");;
    						seat4.setText("28");
    					}	
    					c++;
                    }

                    if (S29.isSelected()) {
                    	if(seat1.getText().equals("") && class1.getText().equals(""))
    					{
    						class1.setText("First");
    						seat1.setText("29");
    					}
    					else if(seat2.getText().equals("") && class2.getText().equals(""))
    					{
    						class2.setText("First");
    						seat2.setText("29");
    					}
    					else if(seat3.getText().equals("") && class3.getText().equals(""))
    					{
    						class3.setText("First");
    						seat3.setText("29");
    					}
    					else
    					{
    						class4.setText("First");;
    						seat4.setText("29");
    					}	
    					c++;
                    }

                    if (S30.isSelected()) {
                    	if(seat1.getText().equals("") && class1.getText().equals(""))
    					{
    						class1.setText("First");
    						seat1.setText("30");
    					}
    					else if(seat2.getText().equals("") && class2.getText().equals(""))
    					{
    						class2.setText("First");
    						seat2.setText("30");
    					}
    					else if(seat3.getText().equals("") && class3.getText().equals(""))
    					{
    						class3.setText("First");
    						seat3.setText("30");
    					}
    					else
    					{
    						class4.setText("First");;
    						seat4.setText("30");
    					}	
    					c++;
                    }

                    if (S31.isSelected()) {
                    	if(seat1.getText().equals("") && class1.getText().equals(""))
    					{
    						class1.setText("First");
    						seat1.setText("31");
    					}
    					else if(seat2.getText().equals("") && class2.getText().equals(""))
    					{
    						class2.setText("First");
    						seat2.setText("31");
    					}
    					else if(seat3.getText().equals("") && class3.getText().equals(""))
    					{
    						class3.setText("First");
    						seat3.setText("31");
    					}
    					else
    					{
    						class4.setText("First");;
    						seat4.setText("31");
    					}	
    					c++;
                    }

                    if (S32.isSelected()) {
                    	if(seat1.getText().equals("") && class1.getText().equals(""))
    					{
    						class1.setText("First");
    						seat1.setText("32");
    					}
    					else if(seat2.getText().equals("") && class2.getText().equals(""))
    					{
    						class2.setText("First");
    						seat2.setText("32");
    					}
    					else if(seat3.getText().equals("") && class3.getText().equals(""))
    					{
    						class3.setText("First");
    						seat3.setText("32");
    					}
    					else
    					{
    						class4.setText("First");;
    						seat4.setText("32");
    					}	
    					c++;
                    }

                    if (S33.isSelected()) {
                    	if(seat1.getText().equals("") && class1.getText().equals(""))
    					{
    						class1.setText("First");
    						seat1.setText("33");
    					}
    					else if(seat2.getText().equals("") && class2.getText().equals(""))
    					{
    						class2.setText("First");
    						seat2.setText("33");
    					}
    					else if(seat3.getText().equals("") && class3.getText().equals(""))
    					{
    						class3.setText("First");
    						seat3.setText("33");
    					}
    					else
    					{
    						class4.setText("First");;
    						seat4.setText("33");
    					}	
    					c++;
                    }

                    if (S34.isSelected()) {
                    	if(seat1.getText().equals("") && class1.getText().equals(""))
    					{
    						class1.setText("First");
    						seat1.setText("34");
    					}
    					else if(seat2.getText().equals("") && class2.getText().equals(""))
    					{
    						class2.setText("First");
    						seat2.setText("34");
    					}
    					else if(seat3.getText().equals("") && class3.getText().equals(""))
    					{
    						class3.setText("First");
    						seat3.setText("34");
    					}
    					else
    					{
    						class4.setText("First");;
    						seat4.setText("34");
    					}	
    					c++;
                    }

                    if (S35.isSelected()) {
                    	if(seat1.getText().equals("") && class1.getText().equals(""))
    					{
    						class1.setText("First");
    						seat1.setText("35");
    					}
    					else if(seat2.getText().equals("") && class2.getText().equals(""))
    					{
    						class2.setText("First");
    						seat2.setText("35");
    					}
    					else if(seat3.getText().equals("") && class3.getText().equals(""))
    					{
    						class3.setText("First");
    						seat3.setText("35");
    					}
    					else
    					{
    						class4.setText("First");;
    						seat4.setText("35");
    					}	
    					c++;
                    }

                    if (S36.isSelected()) {
                    	if(seat1.getText().equals("") && class1.getText().equals(""))
    					{
    						class1.setText("First");
    						seat1.setText("36");
    					}
    					else if(seat2.getText().equals("") && class2.getText().equals(""))
    					{
    						class2.setText("First");
    						seat2.setText("36");
    					}
    					else if(seat3.getText().equals("") && class3.getText().equals(""))
    					{
    						class3.setText("First");
    						seat3.setText("36");
    					}
    					else
    					{
    						class4.setText("First");;
    						seat4.setText("36");
    					}	
    					c++;
                    }

                    if (S37.isSelected()) {
                    	if(seat1.getText().equals("") && class1.getText().equals(""))
    					{
    						class1.setText("First");
    						seat1.setText("37");
    					}
    					else if(seat2.getText().equals("") && class2.getText().equals(""))
    					{
    						class2.setText("First");
    						seat2.setText("37");
    					}
    					else if(seat3.getText().equals("") && class3.getText().equals(""))
    					{
    						class3.setText("First");
    						seat3.setText("37");
    					}
    					else
    					{
    						class4.setText("First");;
    						seat4.setText("37");
    					}	
    					c++;
                    }

                    if (S38.isSelected()) {
                    	if(seat1.getText().equals("") && class1.getText().equals(""))
    					{
    						class1.setText("First");
    						seat1.setText("38");
    					}
    					else if(seat2.getText().equals("") && class2.getText().equals(""))
    					{
    						class2.setText("First");
    						seat2.setText("38");
    					}
    					else if(seat3.getText().equals("") && class3.getText().equals(""))
    					{
    						class3.setText("First");
    						seat3.setText("38");
    					}
    					else
    					{
    						class4.setText("First");;
    						seat4.setText("38");
    					}	
    					c++;
                    }

                    if (S39.isSelected()) {
                    	if(seat1.getText().equals("") && class1.getText().equals(""))
    					{
    						class1.setText("First");
    						seat1.setText("39");
    					}
    					else if(seat2.getText().equals("") && class2.getText().equals(""))
    					{
    						class2.setText("First");
    						seat2.setText("39");
    					}
    					else if(seat3.getText().equals("") && class3.getText().equals(""))
    					{
    						class3.setText("First");
    						seat3.setText("39");
    					}
    					else
    					{
    						class4.setText("First");;
    						seat4.setText("39");
    					}	
    					c++;
                    }

                    if (S40.isSelected()) {
                    	if(seat1.getText().equals("") && class1.getText().equals(""))
    					{
    						class1.setText("First");
    						seat1.setText("40");
    					}
    					else if(seat2.getText().equals("") && class2.getText().equals(""))
    					{
    						class2.setText("First");
    						seat2.setText("40");
    					}
    					else if(seat3.getText().equals("") && class3.getText().equals(""))
    					{
    						class3.setText("First");
    						seat3.setText("40");
    					}
    					else
    					{
    						class4.setText("First");;
    						seat4.setText("40");
    					}	
    					c++;
                    }

                    if (S41.isSelected()) {
                    	if(seat1.getText().equals("") && class1.getText().equals(""))
    					{
    						class1.setText("First");
    						seat1.setText("41");
    					}
    					else if(seat2.getText().equals("") && class2.getText().equals(""))
    					{
    						class2.setText("First");
    						seat2.setText("41");
    					}
    					else if(seat3.getText().equals("") && class3.getText().equals(""))
    					{
    						class3.setText("First");
    						seat3.setText("41");
    					}
    					else
    					{
    						class4.setText("First");;
    						seat4.setText("41");
    					}	
    					c++;
                    }

                    if (S42.isSelected()) {
                    	if(seat1.getText().equals("") && class1.getText().equals(""))
    					{
    						class1.setText("First");
    						seat1.setText("42");
    					}
    					else if(seat2.getText().equals("") && class2.getText().equals(""))
    					{
    						class2.setText("First");
    						seat2.setText("42");
    					}
    					else if(seat3.getText().equals("") && class3.getText().equals(""))
    					{
    						class3.setText("First");
    						seat3.setText("42");
    					}
    					else
    					{
    						class4.setText("First");;
    						seat4.setText("42");
    					}	
    					c++;
                    }

                    if (S43.isSelected()) {
                    	if(seat1.getText().equals("") && class1.getText().equals(""))
    					{
    						class1.setText("First");
    						seat1.setText("43");
    					}
    					else if(seat2.getText().equals("") && class2.getText().equals(""))
    					{
    						class2.setText("First");
    						seat2.setText("43");
    					}
    					else if(seat3.getText().equals("") && class3.getText().equals(""))
    					{
    						class3.setText("First");
    						seat3.setText("43");
    					}
    					else
    					{
    						class4.setText("First");;
    						seat4.setText("43");
    					}	
    					c++;
                    }

                    if (S44.isSelected()) {
                    	if(seat1.getText().equals("") && class1.getText().equals(""))
    					{
    						class1.setText("First");
    						seat1.setText("44");
    					}
    					else if(seat2.getText().equals("") && class2.getText().equals(""))
    					{
    						class2.setText("First");
    						seat2.setText("44");
    					}
    					else if(seat3.getText().equals("") && class3.getText().equals(""))
    					{
    						class3.setText("First");
    						seat3.setText("44");
    					}
    					else
    					{
    						class4.setText("First");;
    						seat4.setText("44");
    					}	
    					c++;
                    }

                    if (S45.isSelected()) {
                    	if(seat1.getText().equals("") && class1.getText().equals(""))
    					{
    						class1.setText("First");
    						seat1.setText("45");
    					}
    					else if(seat2.getText().equals("") && class2.getText().equals(""))
    					{
    						class2.setText("First");
    						seat2.setText("45");
    					}
    					else if(seat3.getText().equals("") && class3.getText().equals(""))
    					{
    						class3.setText("First");
    						seat3.setText("45");
    					}
    					else
    					{
    						class4.setText("First");;
    						seat4.setText("45");
    					}	
    					c++;
                    }

                    if (S46.isSelected()) {
                    	if(seat1.getText().equals("") && class1.getText().equals(""))
    					{
    						class1.setText("First");
    						seat1.setText("46");
    					}
    					else if(seat2.getText().equals("") && class2.getText().equals(""))
    					{
    						class2.setText("First");
    						seat2.setText("46");
    					}
    					else if(seat3.getText().equals("") && class3.getText().equals(""))
    					{
    						class3.setText("First");
    						seat3.setText("46");
    					}
    					else
    					{
    						class4.setText("First");;
    						seat4.setText("46");
    					}	
    					c++;
                    }

                    if (S47.isSelected()) {
                    	if(seat1.getText().equals("") && class1.getText().equals(""))
    					{
    						class1.setText("First");
    						seat1.setText("47");
    					}
    					else if(seat2.getText().equals("") && class2.getText().equals(""))
    					{
    						class2.setText("First");
    						seat2.setText("47");
    					}
    					else if(seat3.getText().equals("") && class3.getText().equals(""))
    					{
    						class3.setText("First");
    						seat3.setText("47");
    					}
    					else
    					{
    						class4.setText("First");;
    						seat4.setText("47");
    					}	
    					c++;
                    }

                    if (S48.isSelected()) {
                    	if(seat1.getText().equals("") && class1.getText().equals(""))
    					{
    						class1.setText("First");
    						seat1.setText("48");
    					}
    					else if(seat2.getText().equals("") && class2.getText().equals(""))
    					{
    						class2.setText("First");
    						seat2.setText("48");
    					}
    					else if(seat3.getText().equals("") && class3.getText().equals(""))
    					{
    						class3.setText("First");
    						seat3.setText("48");
    					}
    					else
    					{
    						class4.setText("First");;
    						seat4.setText("48");
    					}	
    					c++;
                    }

                    if (S49.isSelected()) {
                    	if(seat1.getText().equals("") && class1.getText().equals(""))
    					{
    						class1.setText("First");
    						seat1.setText("49");
    					}
    					else if(seat2.getText().equals("") && class2.getText().equals(""))
    					{
    						class2.setText("First");
    						seat2.setText("49");
    					}
    					else if(seat3.getText().equals("") && class3.getText().equals(""))
    					{
    						class3.setText("First");
    						seat3.setText("49");
    					}
    					else
    					{
    						class4.setText("First");;
    						seat4.setText("49");
    					}	
    					c++;
                    }

                    if (S50.isSelected()) {
                    	if(seat1.getText().equals("") && class1.getText().equals(""))
    					{
    						class1.setText("First");
    						seat1.setText("50");
    					}
    					else if(seat2.getText().equals("") && class2.getText().equals(""))
    					{
    						class2.setText("First");
    						seat2.setText("50");
    					}
    					else if(seat3.getText().equals("") && class3.getText().equals(""))
    					{
    						class3.setText("First");
    						seat3.setText("50");
    					}
    					else
    					{
    						class4.setText("First");;
    						seat4.setText("50");
    					}	
    					c++;
                    }

                    if (S51.isSelected()) {
                    	if(seat1.getText().equals("") && class1.getText().equals(""))
    					{
    						class1.setText("First");
    						seat1.setText("51");
    					}
    					else if(seat2.getText().equals("") && class2.getText().equals(""))
    					{
    						class2.setText("First");
    						seat2.setText("51");
    					}
    					else if(seat3.getText().equals("") && class3.getText().equals(""))
    					{
    						class3.setText("First");
    						seat3.setText("51");
    					}
    					else
    					{
    						class4.setText("First");;
    						seat4.setText("51");
    					}	
    					c++;
                    }

                    if (S52.isSelected()) {
                    	if(seat1.getText().equals("") && class1.getText().equals(""))
    					{
    						class1.setText("First");
    						seat1.setText("52");
    					}
    					else if(seat2.getText().equals("") && class2.getText().equals(""))
    					{
    						class2.setText("First");
    						seat2.setText("52");
    					}
    					else if(seat3.getText().equals("") && class3.getText().equals(""))
    					{
    						class3.setText("First");
    						seat3.setText("52");
    					}
    					else
    					{
    						class4.setText("First");;
    						seat4.setText("52");
    					}	
    					c++;
                    }

                    if (S53.isSelected()) {
                    	if(seat1.getText().equals("") && class1.getText().equals(""))
    					{
    						class1.setText("First");
    						seat1.setText("53");
    					}
    					else if(seat2.getText().equals("") && class2.getText().equals(""))
    					{
    						class2.setText("First");
    						seat2.setText("53");
    					}
    					else if(seat3.getText().equals("") && class3.getText().equals(""))
    					{
    						class3.setText("First");
    						seat3.setText("53");
    					}
    					else
    					{
    						class4.setText("First");;
    						seat4.setText("53");
    					}	
    					c++;
                    }

                    if (S54.isSelected()) {
                    	if(seat1.getText().equals("") && class1.getText().equals(""))
    					{
    						class1.setText("First");
    						seat1.setText("54");
    					}
    					else if(seat2.getText().equals("") && class2.getText().equals(""))
    					{
    						class2.setText("First");
    						seat2.setText("54");
    					}
    					else if(seat3.getText().equals("") && class3.getText().equals(""))
    					{
    						class3.setText("First");
    						seat3.setText("54");
    					}
    					else
    					{
    						class4.setText("First");;
    						seat4.setText("45");
    					}	
    					c++;
                    }

                    if (S55.isSelected()) {
                    	if(seat1.getText().equals("") && class1.getText().equals(""))
    					{
    						class1.setText("First");
    						seat1.setText("55");
    					}
    					else if(seat2.getText().equals("") && class2.getText().equals(""))
    					{
    						class2.setText("First");
    						seat2.setText("55");
    					}
    					else if(seat3.getText().equals("") && class3.getText().equals(""))
    					{
    						class3.setText("First");
    						seat3.setText("55");
    					}
    					else
    					{
    						class4.setText("First");;
    						seat4.setText("55");
    					}	
    					c++;
                    }

                    if (S56.isSelected()) {
                    	if(seat1.getText().equals("") && class1.getText().equals(""))
    					{
    						class1.setText("First");
    						seat1.setText("56");
    					}
    					else if(seat2.getText().equals("") && class2.getText().equals(""))
    					{
    						class2.setText("First");
    						seat2.setText("56");
    					}
    					else if(seat3.getText().equals("") && class3.getText().equals(""))
    					{
    						class3.setText("First");
    						seat3.setText("56");
    					}
    					else
    					{
    						class4.setText("First");;
    						seat4.setText("56");
    					}	
    					c++;
                    }
                    afc=c*fp;
                    name.setVisible(true);
    				lblage.setVisible(true);
    				gender.setVisible(true);
    				lblmob.setVisible(true);
//    				submitform.setVisible(true);
    				lblSelectedSeat.setVisible(true);
    				lblclass.setVisible(true);
    				switch(c)
    				{
    				case 1:
    				{
    					
    					name1.setVisible(true);
    					age1.setVisible(true);
    					gender1.setVisible(true);
    					mob1.setVisible(true);
    					seat1.setVisible(true);
    					class1.setVisible(true);
    					total.setText(String.valueOf(afc));
    					break;
    				}
    				case 2:
    				{
    					name1.setVisible(true);
    					age1.setVisible(true);
    					gender1.setVisible(true);
    					mob1.setVisible(true);
    					seat1.setVisible(true);
    					class1.setVisible(true);
    					
    					name2.setVisible(true);
    					age2.setVisible(true);
    					gender2.setVisible(true);
    					mob2.setVisible(true);
    					seat2.setVisible(true);
    					class2.setVisible(true);
    					total.setText(String.valueOf(afc));
    					break;
    				}
    				case 3:
    				{
    					name1.setVisible(true);
    					age1.setVisible(true);
    					gender1.setVisible(true);
    					mob1.setVisible(true);
    					seat1.setVisible(true);
    					class1.setVisible(true);
    					
    					name2.setVisible(true);
    					age2.setVisible(true);
    					gender2.setVisible(true);
    					mob2.setVisible(true);
    					seat2.setVisible(true);
    					class2.setVisible(true);
    					
    					name3.setVisible(true);
    					age3.setVisible(true);
    					gender3.setVisible(true);
    					mob4.setVisible(true);
    					seat3.setVisible(true);
    					class3.setVisible(true);
    					total.setText(String.valueOf(afc));
    					break;
    				}
    				case 4:
    				{
    					name1.setVisible(true);
    					age1.setVisible(true);
    					gender1.setVisible(true);
    					mob1.setVisible(true);
    					seat1.setVisible(true);
    					class1.setVisible(true);
    					
    					name2.setVisible(true);
    					age2.setVisible(true);
    					gender2.setVisible(true);
    					mob2.setVisible(true);
    					seat2.setVisible(true);
    					class2.setVisible(true);
    					
    					name3.setVisible(true);
    					age3.setVisible(true);
    					gender3.setVisible(true);
    					mob3.setVisible(true);
    					seat3.setVisible(true);
    					class3.setVisible(true);
    					
    					name4.setVisible(true);
    					age4.setVisible(true);
    					gender4.setVisible(true);
    					mob4.setVisible(true);
    					seat4.setVisible(true);
    					class4.setVisible(true);
    					total.setText(String.valueOf(afc));
    					break;
    				}
    				}

                    JOptionPane.showMessageDialog(null, "done");
                } catch (ClassNotFoundException e1) {
                    // TODO Auto-generated catch block
                    e1.printStackTrace();
                } catch (SQLException e1) {
                    // TODO Auto-generated catch block
                    e1.printStackTrace();
                }
            	}
            	
            	if(sc.getText().equals("Economy"))
            	{	int ep=0,aec=0;
            	try {

                    Class.forName("com.mysql.jdbc.Driver");
                    Connection con = DriverManager.getConnection("jdbc:mysql://localhost:3306/airline", "root", "root");
                    Statement stmt = con.createStatement();
                    String sql1="select * from flightdetails where fid='"+fid.getText()+"'";
					rs=stmt.executeQuery(sql1);
					while(rs.next())
						
					{
						ep=Integer.parseInt(rs.getString("prec"));
					}
                    if (S1.isSelected()) {
                    	if(seat1.getText().equals("") && class1.getText().equals(""))
    					{
    						class1.setText("Economy");
    						seat1.setText("1");
    					}
    					else if(seat2.getText().equals("") && class2.getText().equals(""))
    					{
    						class2.setText("Economy");
    						seat2.setText("1");
    					}
    					else if(seat3.getText().equals("") && class3.getText().equals(""))
    					{
    						class3.setText("Economy");
    						seat3.setText("1");
    					}
    					else
    					{
    						class4.setText("Economy");;
    						seat4.setText("1");
    					}	
    					c++;
                    }

                    if (S2.isSelected()) {
                    	if(seat1.getText().equals("") && class1.getText().equals(""))
    					{
    						class1.setText("Economy");
    						seat1.setText("2");
    					}
    					else if(seat2.getText().equals("") && class2.getText().equals(""))
    					{
    						class2.setText("Economy");
    						seat2.setText("2");
    					}
    					else if(seat3.getText().equals("") && class3.getText().equals(""))
    					{
    						class3.setText("Economy");
    						seat3.setText("2");
    					}
    					else
    					{
    						class4.setText("Economy");;
    						seat4.setText("2");
    					}	
    					c++;
                    }

                    if (S3.isSelected()) {
                    	if(seat1.getText().equals("") && class1.getText().equals(""))
    					{
    						class1.setText("Economy");
    						seat1.setText("3");
    					}
    					else if(seat2.getText().equals("") && class2.getText().equals(""))
    					{
    						class2.setText("Economy");
    						seat2.setText("3");
    					}
    					else if(seat3.getText().equals("") && class3.getText().equals(""))
    					{
    						class3.setText("Economy");
    						seat3.setText("3");
    					}
    					else
    					{
    						class4.setText("Economy");;
    						seat4.setText("3");
    					}	
    					c++;
                    }

                    if (S4.isSelected()) {
                    	if(seat1.getText().equals("") && class1.getText().equals(""))
    					{
    						class1.setText("Economy");
    						seat1.setText("4");
    					}
    					else if(seat2.getText().equals("") && class2.getText().equals(""))
    					{
    						class2.setText("Economy");
    						seat2.setText("4");
    					}
    					else if(seat3.getText().equals("") && class3.getText().equals(""))
    					{
    						class3.setText("Economy");
    						seat3.setText("4");
    					}
    					else
    					{
    						class4.setText("Economy");;
    						seat4.setText("4");
    					}	
    					c++;
                    }

                    if (S5.isSelected()) {
                    	if(seat1.getText().equals("") && class1.getText().equals(""))
    					{
    						class1.setText("Economy");
    						seat1.setText("5");
    					}
    					else if(seat2.getText().equals("") && class2.getText().equals(""))
    					{
    						class2.setText("Economy");
    						seat2.setText("5");
    					}
    					else if(seat3.getText().equals("") && class3.getText().equals(""))
    					{
    						class3.setText("Economy");
    						seat3.setText("5");
    					}
    					else
    					{
    						class4.setText("Economy");;
    						seat4.setText("5");
    					}	
    					c++;
                    }

                    if (S6.isSelected()) {
                    	if(seat1.getText().equals("") && class1.getText().equals(""))
    					{
    						class1.setText("Economy");
    						seat1.setText("6");
    					}
    					else if(seat2.getText().equals("") && class2.getText().equals(""))
    					{
    						class2.setText("Economy");
    						seat2.setText("6");
    					}
    					else if(seat3.getText().equals("") && class3.getText().equals(""))
    					{
    						class3.setText("Economy");
    						seat3.setText("6");
    					}
    					else
    					{
    						class4.setText("Economy");;
    						seat4.setText("6");
    					}	
    					c++;
                    }

                    if (S7.isSelected()) {
                    	if(seat1.getText().equals("") && class1.getText().equals(""))
    					{
    						class1.setText("Economy");
    						seat1.setText("7");
    					}
    					else if(seat2.getText().equals("") && class2.getText().equals(""))
    					{
    						class2.setText("Economy");
    						seat2.setText("7");
    					}
    					else if(seat3.getText().equals("") && class3.getText().equals(""))
    					{
    						class3.setText("Economy");
    						seat3.setText("7");
    					}
    					else
    					{
    						class4.setText("Economy");;
    						seat4.setText("7");
    					}	
    					c++;
                    }

                    if (S8.isSelected()) {
                    	if(seat1.getText().equals("") && class1.getText().equals(""))
    					{
    						class1.setText("Economy");
    						seat1.setText("8");
    					}
    					else if(seat2.getText().equals("") && class2.getText().equals(""))
    					{
    						class2.setText("Economy");
    						seat2.setText("8");
    					}
    					else if(seat3.getText().equals("") && class3.getText().equals(""))
    					{
    						class3.setText("Economy");
    						seat3.setText("8");
    					}
    					else
    					{
    						class4.setText("Economy");;
    						seat4.setText("8");
    					}	
    					c++;
                    }

                    if (S9.isSelected()) {
                    	if(seat1.getText().equals("") && class1.getText().equals(""))
    					{
    						class1.setText("Economy");
    						seat1.setText("9");
    					}
    					else if(seat2.getText().equals("") && class2.getText().equals(""))
    					{
    						class2.setText("Economy");
    						seat2.setText("9");
    					}
    					else if(seat3.getText().equals("") && class3.getText().equals(""))
    					{
    						class3.setText("Economy");
    						seat3.setText("9");
    					}
    					else
    					{
    						class4.setText("Economy");;
    						seat4.setText("9");
    					}	
    					c++;
                    }

                    if (S10.isSelected()) {
                    	if(seat1.getText().equals("") && class1.getText().equals(""))
    					{
    						class1.setText("Economy");
    						seat1.setText("10");
    					}
    					else if(seat2.getText().equals("") && class2.getText().equals(""))
    					{
    						class2.setText("Economy");
    						seat2.setText("10");
    					}
    					else if(seat3.getText().equals("") && class3.getText().equals(""))
    					{
    						class3.setText("Economy");
    						seat3.setText("10");
    					}
    					else
    					{
    						class4.setText("Economy");;
    						seat4.setText("10");
    					}	
    					c++;
                    }

                    if (S11.isSelected()) {
                    	if(seat1.getText().equals("") && class1.getText().equals(""))
    					{
    						class1.setText("Economy");
    						seat1.setText("11");
    					}
    					else if(seat2.getText().equals("") && class2.getText().equals(""))
    					{
    						class2.setText("Economy");
    						seat2.setText("11");
    					}
    					else if(seat3.getText().equals("") && class3.getText().equals(""))
    					{
    						class3.setText("Economy");
    						seat3.setText("11");
    					}
    					else
    					{
    						class4.setText("Economy");;
    						seat4.setText("11");
    					}	
    					c++;
                    }

                    if (S12.isSelected()) {
                    	if(seat1.getText().equals("") && class1.getText().equals(""))
    					{
    						class1.setText("Economy");
    						seat1.setText("12");
    					}
    					else if(seat2.getText().equals("") && class2.getText().equals(""))
    					{
    						class2.setText("Economy");
    						seat2.setText("12");
    					}
    					else if(seat3.getText().equals("") && class3.getText().equals(""))
    					{
    						class3.setText("Economy");
    						seat3.setText("12");
    					}
    					else
    					{
    						class4.setText("Economy");;
    						seat4.setText("12");
    					}	
    					c++;
                    }

                    if (S13.isSelected()) {
                    	if(seat1.getText().equals("") && class1.getText().equals(""))
    					{
    						class1.setText("Economy");
    						seat1.setText("13");
    					}
    					else if(seat2.getText().equals("") && class2.getText().equals(""))
    					{
    						class2.setText("Economy");
    						seat2.setText("13");
    					}
    					else if(seat3.getText().equals("") && class3.getText().equals(""))
    					{
    						class3.setText("Economy");
    						seat3.setText("13");
    					}
    					else
    					{
    						class4.setText("Economy");;
    						seat4.setText("13");
    					}	
    					c++;
                    }

                    if (S14.isSelected()) {
                    	if(seat1.getText().equals("") && class1.getText().equals(""))
    					{
    						class1.setText("Economy");
    						seat1.setText("14");
    					}
    					else if(seat2.getText().equals("") && class2.getText().equals(""))
    					{
    						class2.setText("Economy");
    						seat2.setText("14");
    					}
    					else if(seat3.getText().equals("") && class3.getText().equals(""))
    					{
    						class3.setText("Economy");
    						seat3.setText("14");
    					}
    					else
    					{
    						class4.setText("Economy");;
    						seat4.setText("14");
    					}	
    					c++;
                    }

                    if (S15.isSelected()) {
                    	if(seat1.getText().equals("") && class1.getText().equals(""))
    					{
    						class1.setText("Economy");
    						seat1.setText("15");
    					}
    					else if(seat2.getText().equals("") && class2.getText().equals(""))
    					{
    						class2.setText("Economy");
    						seat2.setText("15");
    					}
    					else if(seat3.getText().equals("") && class3.getText().equals(""))
    					{
    						class3.setText("Economy");
    						seat3.setText("15");
    					}
    					else
    					{
    						class4.setText("Economy");;
    						seat4.setText("15");
    					}	
    					c++;
                    }

                    if (S16.isSelected()) {
                    	if(seat1.getText().equals("") && class1.getText().equals(""))
    					{
    						class1.setText("Economy");
    						seat1.setText("16");
    					}
    					else if(seat2.getText().equals("") && class2.getText().equals(""))
    					{
    						class2.setText("Economy");
    						seat2.setText("16");
    					}
    					else if(seat3.getText().equals("") && class3.getText().equals(""))
    					{
    						class3.setText("Economy");
    						seat3.setText("16");
    					}
    					else
    					{
    						class4.setText("Economy");;
    						seat4.setText("16");
    					}	
    					c++;
                    }

                    if (S17.isSelected()) {
                    	if(seat1.getText().equals("") && class1.getText().equals(""))
    					{
    						class1.setText("Economy");
    						seat1.setText("17");
    					}
    					else if(seat2.getText().equals("") && class2.getText().equals(""))
    					{
    						class2.setText("Economy");
    						seat2.setText("17");
    					}
    					else if(seat3.getText().equals("") && class3.getText().equals(""))
    					{
    						class3.setText("Economy");
    						seat3.setText("17");
    					}
    					else
    					{
    						class4.setText("Economy");;
    						seat4.setText("17");
    					}	
    					c++;
                    }

                    if (S18.isSelected()) {
                    	if(seat1.getText().equals("") && class1.getText().equals(""))
    					{
    						class1.setText("Economy");
    						seat1.setText("18");
    					}
    					else if(seat2.getText().equals("") && class2.getText().equals(""))
    					{
    						class2.setText("Economy");
    						seat2.setText("18");
    					}
    					else if(seat3.getText().equals("") && class3.getText().equals(""))
    					{
    						class3.setText("Economy");
    						seat3.setText("18");
    					}
    					else
    					{
    						class4.setText("Economy");;
    						seat4.setText("18");
    					}	
    					c++;
                    }

                    if (S19.isSelected()) {
                    	if(seat1.getText().equals("") && class1.getText().equals(""))
    					{
    						class1.setText("Economy");
    						seat1.setText("19");
    					}
    					else if(seat2.getText().equals("") && class2.getText().equals(""))
    					{
    						class2.setText("Economy");
    						seat2.setText("19");
    					}
    					else if(seat3.getText().equals("") && class3.getText().equals(""))
    					{
    						class3.setText("Economy");
    						seat3.setText("19");
    					}
    					else
    					{
    						class4.setText("Economy");;
    						seat4.setText("19");
    					}	
    					c++;
                    }

                    if (S20.isSelected()) {
                    	if(seat1.getText().equals("") && class1.getText().equals(""))
    					{
    						class1.setText("Economy");
    						seat1.setText("20");
    					}
    					else if(seat2.getText().equals("") && class2.getText().equals(""))
    					{
    						class2.setText("Economy");
    						seat2.setText("20");
    					}
    					else if(seat3.getText().equals("") && class3.getText().equals(""))
    					{
    						class3.setText("Economy");
    						seat3.setText("20");
    					}
    					else
    					{
    						class4.setText("Economy");;
    						seat4.setText("20");
    					}	
    					c++;
                    }

                    if (S21.isSelected()) {
                    	if(seat1.getText().equals("") && class1.getText().equals(""))
    					{
    						class1.setText("Economy");
    						seat1.setText("21");
    					}
    					else if(seat2.getText().equals("") && class2.getText().equals(""))
    					{
    						class2.setText("Economy");
    						seat2.setText("21");
    					}
    					else if(seat3.getText().equals("") && class3.getText().equals(""))
    					{
    						class3.setText("Economy");
    						seat3.setText("21");
    					}
    					else
    					{
    						class4.setText("Economy");;
    						seat4.setText("21");
    					}	
    					c++;
                    }

                    if (S22.isSelected()) {
                    	if(seat1.getText().equals("") && class1.getText().equals(""))
    					{
    						class1.setText("Economy");
    						seat1.setText("22");
    					}
    					else if(seat2.getText().equals("") && class2.getText().equals(""))
    					{
    						class2.setText("Economy");
    						seat2.setText("22");
    					}
    					else if(seat3.getText().equals("") && class3.getText().equals(""))
    					{
    						class3.setText("Economy");
    						seat3.setText("22");
    					}
    					else
    					{
    						class4.setText("Economy");;
    						seat4.setText("22");
    					}	
    					c++;
                    }

                    if (S23.isSelected()) {
                    	if(seat1.getText().equals("") && class1.getText().equals(""))
    					{
    						class1.setText("Economy");
    						seat1.setText("23");
    					}
    					else if(seat2.getText().equals("") && class2.getText().equals(""))
    					{
    						class2.setText("Economy");
    						seat2.setText("23");
    					}
    					else if(seat3.getText().equals("") && class3.getText().equals(""))
    					{
    						class3.setText("Economy");
    						seat3.setText("23");
    					}
    					else
    					{
    						class4.setText("Economy");;
    						seat4.setText("23");
    					}	
    					c++;
                    }

                    if (S24.isSelected()) {
                    	if(seat1.getText().equals("") && class1.getText().equals(""))
    					{
    						class1.setText("Economy");
    						seat1.setText("24");
    					}
    					else if(seat2.getText().equals("") && class2.getText().equals(""))
    					{
    						class2.setText("Economy");
    						seat2.setText("24");
    					}
    					else if(seat3.getText().equals("") && class3.getText().equals(""))
    					{
    						class3.setText("Economy");
    						seat3.setText("24");
    					}
    					else
    					{
    						class4.setText("Economy");;
    						seat4.setText("24");
    					}	
    					c++;
                    }

                    if (S25.isSelected()) {
                    	if(seat1.getText().equals("") && class1.getText().equals(""))
    					{
    						class1.setText("Economy");
    						seat1.setText("25");
    					}
    					else if(seat2.getText().equals("") && class2.getText().equals(""))
    					{
    						class2.setText("Economy");
    						seat2.setText("25");
    					}
    					else if(seat3.getText().equals("") && class3.getText().equals(""))
    					{
    						class3.setText("Economy");
    						seat3.setText("25");
    					}
    					else
    					{
    						class4.setText("Economy");;
    						seat4.setText("25");
    					}	
    					c++;
                    }

                    if (S26.isSelected()) {
                    	if(seat1.getText().equals("") && class1.getText().equals(""))
    					{
    						class1.setText("Economy");
    						seat1.setText("26");
    					}
    					else if(seat2.getText().equals("") && class2.getText().equals(""))
    					{
    						class2.setText("Economy");
    						seat2.setText("26");
    					}
    					else if(seat3.getText().equals("") && class3.getText().equals(""))
    					{
    						class3.setText("Economy");
    						seat3.setText("26");
    					}
    					else
    					{
    						class4.setText("Economy");;
    						seat4.setText("26");
    					}	
    					c++;
                    }

                    if (S27.isSelected()) {
                    	if(seat1.getText().equals("") && class1.getText().equals(""))
    					{
    						class1.setText("Economy");
    						seat1.setText("27");
    					}
    					else if(seat2.getText().equals("") && class2.getText().equals(""))
    					{
    						class2.setText("Economy");
    						seat2.setText("27");
    					}
    					else if(seat3.getText().equals("") && class3.getText().equals(""))
    					{
    						class3.setText("Economy");
    						seat3.setText("27");
    					}
    					else
    					{
    						class4.setText("Economy");;
    						seat4.setText("27");
    					}	
    					c++;
                    }

                    if (S28.isSelected()) {
                    	if(seat1.getText().equals("") && class1.getText().equals(""))
    					{
    						class1.setText("Economy");
    						seat1.setText("28");
    					}
    					else if(seat2.getText().equals("") && class2.getText().equals(""))
    					{
    						class2.setText("Economy");
    						seat2.setText("28");
    					}
    					else if(seat3.getText().equals("") && class3.getText().equals(""))
    					{
    						class3.setText("Economy");
    						seat3.setText("28");
    					}
    					else
    					{
    						class4.setText("Economy");;
    						seat4.setText("28");
    					}	
    					c++;
                    }

                    if (S29.isSelected()) {
                    	if(seat1.getText().equals("") && class1.getText().equals(""))
    					{
    						class1.setText("Economy");
    						seat1.setText("29");
    					}
    					else if(seat2.getText().equals("") && class2.getText().equals(""))
    					{
    						class2.setText("Economy");
    						seat2.setText("29");
    					}
    					else if(seat3.getText().equals("") && class3.getText().equals(""))
    					{
    						class3.setText("Economy");
    						seat3.setText("29");
    					}
    					else
    					{
    						class4.setText("Economy");;
    						seat4.setText("29");
    					}	
    					c++;
                    }

                    if (S30.isSelected()) {
                    	if(seat1.getText().equals("") && class1.getText().equals(""))
    					{
    						class1.setText("Economy");
    						seat1.setText("30");
    					}
    					else if(seat2.getText().equals("") && class2.getText().equals(""))
    					{
    						class2.setText("Economy");
    						seat2.setText("30");
    					}
    					else if(seat3.getText().equals("") && class3.getText().equals(""))
    					{
    						class3.setText("Economy");
    						seat3.setText("30");
    					}
    					else
    					{
    						class4.setText("Economy");;
    						seat4.setText("30");
    					}	
    					c++;
                    }

                    if (S31.isSelected()) {
                    	if(seat1.getText().equals("") && class1.getText().equals(""))
    					{
    						class1.setText("Economy");
    						seat1.setText("31");
    					}
    					else if(seat2.getText().equals("") && class2.getText().equals(""))
    					{
    						class2.setText("Economy");
    						seat2.setText("31");
    					}
    					else if(seat3.getText().equals("") && class3.getText().equals(""))
    					{
    						class3.setText("Economy");
    						seat3.setText("31");
    					}
    					else
    					{
    						class4.setText("Economy");;
    						seat4.setText("31");
    					}	
    					c++;
                    }

                    if (S32.isSelected()) {
                    	if(seat1.getText().equals("") && class1.getText().equals(""))
    					{
    						class1.setText("Economy");
    						seat1.setText("32");
    					}
    					else if(seat2.getText().equals("") && class2.getText().equals(""))
    					{
    						class2.setText("Economy");
    						seat2.setText("32");
    					}
    					else if(seat3.getText().equals("") && class3.getText().equals(""))
    					{
    						class3.setText("Economy");
    						seat3.setText("32");
    					}
    					else
    					{
    						class4.setText("Economy");;
    						seat4.setText("32");
    					}	
    					c++;
                    }

                    if (S33.isSelected()) {
                    	if(seat1.getText().equals("") && class1.getText().equals(""))
    					{
    						class1.setText("Economy");
    						seat1.setText("33");
    					}
    					else if(seat2.getText().equals("") && class2.getText().equals(""))
    					{
    						class2.setText("Economy");
    						seat2.setText("33");
    					}
    					else if(seat3.getText().equals("") && class3.getText().equals(""))
    					{
    						class3.setText("Economy");
    						seat3.setText("33");
    					}
    					else
    					{
    						class4.setText("Economy");;
    						seat4.setText("33");
    					}	
    					c++;
                    }

                    if (S34.isSelected()) {
                    	if(seat1.getText().equals("") && class1.getText().equals(""))
    					{
    						class1.setText("Economy");
    						seat1.setText("34");
    					}
    					else if(seat2.getText().equals("") && class2.getText().equals(""))
    					{
    						class2.setText("Economy");
    						seat2.setText("34");
    					}
    					else if(seat3.getText().equals("") && class3.getText().equals(""))
    					{
    						class3.setText("Economy");
    						seat3.setText("34");
    					}
    					else
    					{
    						class4.setText("Economy");;
    						seat4.setText("34");
    					}	
    					c++;
                    }

                    if (S35.isSelected()) {
                    	if(seat1.getText().equals("") && class1.getText().equals(""))
    					{
    						class1.setText("Economy");
    						seat1.setText("35");
    					}
    					else if(seat2.getText().equals("") && class2.getText().equals(""))
    					{
    						class2.setText("Economy");
    						seat2.setText("35");
    					}
    					else if(seat3.getText().equals("") && class3.getText().equals(""))
    					{
    						class3.setText("Economy");
    						seat3.setText("35");
    					}
    					else
    					{
    						class4.setText("Economy");;
    						seat4.setText("35");
    					}	
    					c++;
                    }

                    if (S36.isSelected()) {
                    	if(seat1.getText().equals("") && class1.getText().equals(""))
    					{
    						class1.setText("Economy");
    						seat1.setText("36");
    					}
    					else if(seat2.getText().equals("") && class2.getText().equals(""))
    					{
    						class2.setText("Economy");
    						seat2.setText("36");
    					}
    					else if(seat3.getText().equals("") && class3.getText().equals(""))
    					{
    						class3.setText("Economy");
    						seat3.setText("36");
    					}
    					else
    					{
    						class4.setText("Economy");;
    						seat4.setText("36");
    					}	
    					c++;
                    }

                    if (S37.isSelected()) {
                    	if(seat1.getText().equals("") && class1.getText().equals(""))
    					{
    						class1.setText("Economy");
    						seat1.setText("37");
    					}
    					else if(seat2.getText().equals("") && class2.getText().equals(""))
    					{
    						class2.setText("Economy");
    						seat2.setText("37");
    					}
    					else if(seat3.getText().equals("") && class3.getText().equals(""))
    					{
    						class3.setText("Economy");
    						seat3.setText("37");
    					}
    					else
    					{
    						class4.setText("Economy");;
    						seat4.setText("37");
    					}	
    					c++;
                    }

                    if (S38.isSelected()) {
                    	if(seat1.getText().equals("") && class1.getText().equals(""))
    					{
    						class1.setText("Economy");
    						seat1.setText("38");
    					}
    					else if(seat2.getText().equals("") && class2.getText().equals(""))
    					{
    						class2.setText("Economy");
    						seat2.setText("38");
    					}
    					else if(seat3.getText().equals("") && class3.getText().equals(""))
    					{
    						class3.setText("Economy");
    						seat3.setText("38");
    					}
    					else
    					{
    						class4.setText("Economy");;
    						seat4.setText("38");
    					}	
    					c++;
                    }

                    if (S39.isSelected()) {
                    	if(seat1.getText().equals("") && class1.getText().equals(""))
    					{
    						class1.setText("Economy");
    						seat1.setText("39");
    					}
    					else if(seat2.getText().equals("") && class2.getText().equals(""))
    					{
    						class2.setText("Economy");
    						seat2.setText("39");
    					}
    					else if(seat3.getText().equals("") && class3.getText().equals(""))
    					{
    						class3.setText("Economy");
    						seat3.setText("39");
    					}
    					else
    					{
    						class4.setText("Economy");;
    						seat4.setText("39");
    					}	
    					c++;
                    }

                    if (S40.isSelected()) {
                    	if(seat1.getText().equals("") && class1.getText().equals(""))
    					{
    						class1.setText("Economy");
    						seat1.setText("40");
    					}
    					else if(seat2.getText().equals("") && class2.getText().equals(""))
    					{
    						class2.setText("Economy");
    						seat2.setText("40");
    					}
    					else if(seat3.getText().equals("") && class3.getText().equals(""))
    					{
    						class3.setText("Economy");
    						seat3.setText("40");
    					}
    					else
    					{
    						class4.setText("Economy");;
    						seat4.setText("40");
    					}	
    					c++;
                    }

                    if (S41.isSelected()) {
                    	if(seat1.getText().equals("") && class1.getText().equals(""))
    					{
    						class1.setText("Economy");
    						seat1.setText("41");
    					}
    					else if(seat2.getText().equals("") && class2.getText().equals(""))
    					{
    						class2.setText("Economy");
    						seat2.setText("41");
    					}
    					else if(seat3.getText().equals("") && class3.getText().equals(""))
    					{
    						class3.setText("Economy");
    						seat3.setText("41");
    					}
    					else
    					{
    						class4.setText("Economy");;
    						seat4.setText("41");
    					}	
    					c++;
                    }

                    if (S42.isSelected()) {
                    	if(seat1.getText().equals("") && class1.getText().equals(""))
    					{
    						class1.setText("Economy");
    						seat1.setText("42");
    					}
    					else if(seat2.getText().equals("") && class2.getText().equals(""))
    					{
    						class2.setText("Economy");
    						seat2.setText("42");
    					}
    					else if(seat3.getText().equals("") && class3.getText().equals(""))
    					{
    						class3.setText("Economy");
    						seat3.setText("42");
    					}
    					else
    					{
    						class4.setText("Economy");;
    						seat4.setText("42");
    					}	
    					c++;
                    }

                    if (S43.isSelected()) {
                    	if(seat1.getText().equals("") && class1.getText().equals(""))
    					{
    						class1.setText("Economy");
    						seat1.setText("43");
    					}
    					else if(seat2.getText().equals("") && class2.getText().equals(""))
    					{
    						class2.setText("Economy");
    						seat2.setText("43");
    					}
    					else if(seat3.getText().equals("") && class3.getText().equals(""))
    					{
    						class3.setText("Economy");
    						seat3.setText("43");
    					}
    					else
    					{
    						class4.setText("Economy");;
    						seat4.setText("43");
    					}	
    					c++;
                    }

                    if (S44.isSelected()) {
                    	if(seat1.getText().equals("") && class1.getText().equals(""))
    					{
    						class1.setText("Economy");
    						seat1.setText("44");
    					}
    					else if(seat2.getText().equals("") && class2.getText().equals(""))
    					{
    						class2.setText("Economy");
    						seat2.setText("44");
    					}
    					else if(seat3.getText().equals("") && class3.getText().equals(""))
    					{
    						class3.setText("Economy");
    						seat3.setText("44");
    					}
    					else
    					{
    						class4.setText("Economy");;
    						seat4.setText("44");
    					}	
    					c++;
                    }

                    if (S45.isSelected()) {
                    	if(seat1.getText().equals("") && class1.getText().equals(""))
    					{
    						class1.setText("Economy");
    						seat1.setText("45");
    					}
    					else if(seat2.getText().equals("") && class2.getText().equals(""))
    					{
    						class2.setText("Economy");
    						seat2.setText("45");
    					}
    					else if(seat3.getText().equals("") && class3.getText().equals(""))
    					{
    						class3.setText("Economy");
    						seat3.setText("45");
    					}
    					else
    					{
    						class4.setText("Economy");;
    						seat4.setText("45");
    					}	
    					c++;
                    }

                    if (S46.isSelected()) {
                    	if(seat1.getText().equals("") && class1.getText().equals(""))
    					{
    						class1.setText("Economy");
    						seat1.setText("46");
    					}
    					else if(seat2.getText().equals("") && class2.getText().equals(""))
    					{
    						class2.setText("Economy");
    						seat2.setText("46");
    					}
    					else if(seat3.getText().equals("") && class3.getText().equals(""))
    					{
    						class3.setText("Economy");
    						seat3.setText("46");
    					}
    					else
    					{
    						class4.setText("Economy");;
    						seat4.setText("46");
    					}	
    					c++;
                    }

                    if (S47.isSelected()) {
                    	if(seat1.getText().equals("") && class1.getText().equals(""))
    					{
    						class1.setText("Economy");
    						seat1.setText("47");
    					}
    					else if(seat2.getText().equals("") && class2.getText().equals(""))
    					{
    						class2.setText("Economy");
    						seat2.setText("47");
    					}
    					else if(seat3.getText().equals("") && class3.getText().equals(""))
    					{
    						class3.setText("Economy");
    						seat3.setText("47");
    					}
    					else
    					{
    						class4.setText("Economy");;
    						seat4.setText("47");
    					}	
    					c++;
                    }

                    if (S48.isSelected()) {
                    	if(seat1.getText().equals("") && class1.getText().equals(""))
    					{
    						class1.setText("Economy");
    						seat1.setText("48");
    					}
    					else if(seat2.getText().equals("") && class2.getText().equals(""))
    					{
    						class2.setText("Economy");
    						seat2.setText("48");
    					}
    					else if(seat3.getText().equals("") && class3.getText().equals(""))
    					{
    						class3.setText("Economy");
    						seat3.setText("48");
    					}
    					else
    					{
    						class4.setText("Economy");;
    						seat4.setText("48");
    					}	
    					c++;
                    }

                    if (S49.isSelected()) {
                    	if(seat1.getText().equals("") && class1.getText().equals(""))
    					{
    						class1.setText("Economy");
    						seat1.setText("49");
    					}
    					else if(seat2.getText().equals("") && class2.getText().equals(""))
    					{
    						class2.setText("Economy");
    						seat2.setText("49");
    					}
    					else if(seat3.getText().equals("") && class3.getText().equals(""))
    					{
    						class3.setText("Economy");
    						seat3.setText("49");
    					}
    					else
    					{
    						class4.setText("Economy");;
    						seat4.setText("49");
    					}	
    					c++;
                    }

                    if (S50.isSelected()) {
                    	if(seat1.getText().equals("") && class1.getText().equals(""))
    					{
    						class1.setText("Economy");
    						seat1.setText("50");
    					}
    					else if(seat2.getText().equals("") && class2.getText().equals(""))
    					{
    						class2.setText("Economy");
    						seat2.setText("50");
    					}
    					else if(seat3.getText().equals("") && class3.getText().equals(""))
    					{
    						class3.setText("Economy");
    						seat3.setText("50");
    					}
    					else
    					{
    						class4.setText("Economy");;
    						seat4.setText("50");
    					}	
    					c++;
                    }

                    if (S51.isSelected()) {
                    	if(seat1.getText().equals("") && class1.getText().equals(""))
    					{
    						class1.setText("Economy");
    						seat1.setText("51");
    					}
    					else if(seat2.getText().equals("") && class2.getText().equals(""))
    					{
    						class2.setText("Economy");
    						seat2.setText("51");
    					}
    					else if(seat3.getText().equals("") && class3.getText().equals(""))
    					{
    						class3.setText("Economy");
    						seat3.setText("51");
    					}
    					else
    					{
    						class4.setText("Economy");;
    						seat4.setText("51");
    					}	
    					c++;
                    }

                    if (S52.isSelected()) {
                    	if(seat1.getText().equals("") && class1.getText().equals(""))
    					{
    						class1.setText("Economy");
    						seat1.setText("52");
    					}
    					else if(seat2.getText().equals("") && class2.getText().equals(""))
    					{
    						class2.setText("Economy");
    						seat2.setText("52");
    					}
    					else if(seat3.getText().equals("") && class3.getText().equals(""))
    					{
    						class3.setText("Economy");
    						seat3.setText("52");
    					}
    					else
    					{
    						class4.setText("Economy");;
    						seat4.setText("52");
    					}	
    					c++;
                    }

                    if (S53.isSelected()) {
                    	if(seat1.getText().equals("") && class1.getText().equals(""))
    					{
    						class1.setText("Economy");
    						seat1.setText("53");
    					}
    					else if(seat2.getText().equals("") && class2.getText().equals(""))
    					{
    						class2.setText("Economy");
    						seat2.setText("53");
    					}
    					else if(seat3.getText().equals("") && class3.getText().equals(""))
    					{
    						class3.setText("Economy");
    						seat3.setText("53");
    					}
    					else
    					{
    						class4.setText("Economy");;
    						seat4.setText("53");
    					}	
    					c++;
                    }

                    if (S54.isSelected()) {
                    	if(seat1.getText().equals("") && class1.getText().equals(""))
    					{
    						class1.setText("Economy");
    						seat1.setText("54");
    					}
    					else if(seat2.getText().equals("") && class2.getText().equals(""))
    					{
    						class2.setText("Economy");
    						seat2.setText("54");
    					}
    					else if(seat3.getText().equals("") && class3.getText().equals(""))
    					{
    						class3.setText("Economy");
    						seat3.setText("54");
    					}
    					else
    					{
    						class4.setText("Economy");;
    						seat4.setText("45");
    					}	
    					c++;
                    }

                    if (S55.isSelected()) {
                    	if(seat1.getText().equals("") && class1.getText().equals(""))
    					{
    						class1.setText("Economy");
    						seat1.setText("55");
    					}
    					else if(seat2.getText().equals("") && class2.getText().equals(""))
    					{
    						class2.setText("Economy");
    						seat2.setText("55");
    					}
    					else if(seat3.getText().equals("") && class3.getText().equals(""))
    					{
    						class3.setText("Economy");
    						seat3.setText("55");
    					}
    					else
    					{
    						class4.setText("Economy");;
    						seat4.setText("55");
    					}	
    					c++;
                    }

                    if (S56.isSelected()) {
                    	if(seat1.getText().equals("") && class1.getText().equals(""))
    					{
    						class1.setText("Economy");
    						seat1.setText("56");
    					}
    					else if(seat2.getText().equals("") && class2.getText().equals(""))
    					{
    						class2.setText("Economy");
    						seat2.setText("56");
    					}
    					else if(seat3.getText().equals("") && class3.getText().equals(""))
    					{
    						class3.setText("Economy");
    						seat3.setText("56");
    					}
    					else
    					{
    						class4.setText("Economy");;
    						seat4.setText("56");
    					}	
    					c++;
                    }
                    aec=c*ep;
                    name.setVisible(true);
    				lblage.setVisible(true);
    				gender.setVisible(true);
    				lblmob.setVisible(true);
//    				submitform.setVisible(true);
    				lblSelectedSeat.setVisible(true);
    				lblclass.setVisible(true);
    				switch(c)
    				{
    				case 1:
    				{
    					
    					name1.setVisible(true);
    					age1.setVisible(true);
    					gender1.setVisible(true);
    					seat1.setVisible(true);
    					class1.setVisible(true);
    					total.setText(String.valueOf(aec));
    					break;
    				}
    				case 2:
    				{
    					name1.setVisible(true);
    					age1.setVisible(true);
    					gender1.setVisible(true);
    					mob1.setVisible(true);
    					seat1.setVisible(true);
    					class1.setVisible(true);
    					
    					name2.setVisible(true);
    					age2.setVisible(true);
    					gender2.setVisible(true);
    					mob2.setVisible(true);
    					seat2.setVisible(true);
    					class2.setVisible(true);
    					total.setText(String.valueOf(aec));
    					break;
    				}
    				case 3:
    				{
    					name1.setVisible(true);
    					age1.setVisible(true);
    					gender1.setVisible(true);
    					mob1.setVisible(true);
    					seat1.setVisible(true);
    					class1.setVisible(true);
    					
    					name2.setVisible(true);
    					age2.setVisible(true);
    					gender2.setVisible(true);
    					mob2.setVisible(true);
    					seat2.setVisible(true);
    					class2.setVisible(true);
    					
    					name3.setVisible(true);
    					age3.setVisible(true);
    					gender3.setVisible(true);
    					mob4.setVisible(true);
    					seat3.setVisible(true);
    					class3.setVisible(true);
    					total.setText(String.valueOf(aec));
    					break;
    				}
    				case 4:
    				{
    					name1.setVisible(true);
    					age1.setVisible(true);
    					gender1.setVisible(true);
    					mob1.setVisible(true);
    					seat1.setVisible(true);
    					class1.setVisible(true);
    					
    					name2.setVisible(true);
    					age2.setVisible(true);
    					gender2.setVisible(true);
    					mob2.setVisible(true);
    					seat2.setVisible(true);
    					class2.setVisible(true);
    					
    					name3.setVisible(true);
    					age3.setVisible(true);
    					gender3.setVisible(true);
    					mob3.setVisible(true);
    					seat3.setVisible(true);
    					class3.setVisible(true);
    					
    					name4.setVisible(true);
    					age4.setVisible(true);
    					gender4.setVisible(true);
    					mob4.setVisible(true);
    					seat4.setVisible(true);
    					class4.setVisible(true);
    					total.setText(String.valueOf(aec));
    					break;
    				}
    				}

                    JOptionPane.showMessageDialog(null, "done");
                } catch (ClassNotFoundException e1) {
                    // TODO Auto-generated catch block
                    e1.printStackTrace();
                } catch (SQLException e1) {
                    // TODO Auto-generated catch block
                    e1.printStackTrace();
                }
            	}
            	
            	
            }
        });
        frame.getContentPane().add(submit);
        
        JPanel classpanel = new JPanel();
        classpanel.setBounds(22, 377, 587, 93);
        classpanel.setBorder(new LineBorder(new Color(0, 0, 0), 1, true));
        frame.getContentPane().add(classpanel);
        classpanel.setLayout(null);
        classpanel.setVisible(false);
        
        JButton button = new JButton("Business");
        button.setForeground(Color.DARK_GRAY);
        button.setFont(new Font("Times New Roman", Font.BOLD, 16));
        button.addActionListener(new ActionListener() {
        	public void actionPerformed(ActionEvent e) {
        		
        			sc.setText("Business");
        			
        		   S1.setVisible(false);S2.setVisible(false);S3.setVisible(false);S4.setVisible(false);S4.setVisible(false);S5.setVisible(false);S6.setVisible(false);
          		   S7.setVisible(false);S8.setVisible(false);S9.setVisible(false);S10.setVisible(false);S11.setVisible(false);S12.setVisible(false);S13.setVisible(false);
          		   S14.setVisible(false);S15.setVisible(false);S16.setVisible(false);S17.setVisible(false);S18.setVisible(false);S19.setVisible(false);S20.setVisible(false);
          		   S21.setVisible(false);S22.setVisible(false);S23.setVisible(false);S24.setVisible(false);S25.setVisible(false);S26.setVisible(false);S27.setVisible(false);
          		   S28.setVisible(false);S29.setVisible(false);S30.setVisible(false);S31.setVisible(false);S32.setVisible(false);S33.setVisible(false);S34.setVisible(false);
          		   S35.setVisible(false);S36.setVisible(false);S37.setVisible(false);S38.setVisible(false);S39.setVisible(false);S40.setVisible(false);S41.setVisible(false);
          		   S42.setVisible(false);S43.setVisible(false);S44.setVisible(false);S45.setVisible(false);S46.setVisible(false);S47.setVisible(false);S48.setVisible(false);
          		   S49.setVisible(false);S50.setVisible(false);S51.setVisible(false);S52.setVisible(false);S53.setVisible(false);S54.setVisible(false);S55.setVisible(false);
          		   S56.setVisible(false);
          		   
          		   S1.setBackground(Color.WHITE);S2.setBackground(Color.WHITE);S3.setBackground(Color.WHITE);S4.setBackground(Color.WHITE);S4.setBackground(Color.WHITE);S5.setBackground(Color.WHITE);S6.setBackground(Color.WHITE);
       		       S7.setBackground(Color.WHITE);S8.setBackground(Color.WHITE);S9.setBackground(Color.WHITE);S10.setBackground(Color.WHITE);S11.setBackground(Color.WHITE);S12.setBackground(Color.WHITE);S13.setBackground(Color.WHITE);
       		       S14.setBackground(Color.WHITE);S15.setBackground(Color.WHITE);S16.setBackground(Color.WHITE);S17.setBackground(Color.WHITE);S18.setBackground(Color.WHITE);S19.setBackground(Color.WHITE);S20.setBackground(Color.WHITE);
       		       S21.setBackground(Color.WHITE);S22.setBackground(Color.WHITE);S23.setBackground(Color.WHITE);S24.setBackground(Color.WHITE);S25.setBackground(Color.WHITE);S26.setBackground(Color.WHITE);S27.setBackground(Color.WHITE);
       		       S28.setBackground(Color.WHITE);S29.setBackground(Color.WHITE);S30.setBackground(Color.WHITE);S31.setBackground(Color.WHITE);S32.setBackground(Color.WHITE);S33.setBackground(Color.WHITE);S34.setBackground(Color.WHITE);
       		       S35.setBackground(Color.WHITE);S36.setBackground(Color.WHITE);S37.setBackground(Color.WHITE);S38.setBackground(Color.WHITE);S39.setBackground(Color.WHITE);S40.setBackground(Color.WHITE);S41.setBackground(Color.WHITE);
       		       S42.setBackground(Color.WHITE);S43.setBackground(Color.WHITE);S44.setBackground(Color.WHITE);S45.setBackground(Color.WHITE);S46.setBackground(Color.WHITE);S47.setBackground(Color.WHITE);S48.setBackground(Color.WHITE);
       		       S49.setBackground(Color.WHITE);S50.setBackground(Color.WHITE);S51.setBackground(Color.WHITE);S52.setBackground(Color.WHITE);S53.setBackground(Color.WHITE);S54.setBackground(Color.WHITE);S55.setBackground(Color.WHITE);
       		       S56.setBackground(Color.WHITE);
          		   
          		   S1.setEnabled(true);S2.setEnabled(true);S3.setEnabled(true);S4.setEnabled(true);S4.setEnabled(true);S5.setEnabled(true);S6.setEnabled(true);
        		   S7.setEnabled(true);S8.setEnabled(true);S9.setEnabled(true);S10.setEnabled(true);S11.setEnabled(true);S12.setEnabled(true);S13.setEnabled(true);
        		   S14.setEnabled(true);S15.setEnabled(true);S16.setEnabled(true);S17.setEnabled(true);S18.setEnabled(true);S19.setEnabled(true);S20.setEnabled(true);
        		   S21.setEnabled(true);S22.setEnabled(true);S23.setEnabled(true);S24.setEnabled(true);S25.setEnabled(true);S26.setEnabled(true);S27.setEnabled(true);
        		   S28.setEnabled(true);S29.setEnabled(true);S30.setEnabled(true);S31.setEnabled(true);S32.setEnabled(true);S33.setEnabled(true);S34.setEnabled(true);
        		   S35.setEnabled(true);S36.setEnabled(true);S37.setEnabled(true);S38.setEnabled(true);S39.setEnabled(true);S40.setEnabled(true);S41.setEnabled(true);
        		   S42.setEnabled(true);S43.setEnabled(true);S44.setEnabled(true);S45.setEnabled(true);S46.setEnabled(true);S47.setEnabled(true);S48.setEnabled(true);
        		   S49.setEnabled(true);S50.setEnabled(true);S51.setEnabled(true);S52.setEnabled(true);S53.setEnabled(true);S54.setEnabled(true);S55.setEnabled(true);
        		   S56.setEnabled(true);
          		   
          		   S1.setSelected(false);S2.setSelected(false);S3.setSelected(false);S4.setSelected(false);S4.setSelected(false);S5.setSelected(false);S6.setSelected(false);
          		   S7.setSelected(false);S8.setSelected(false);S9.setSelected(false);S10.setSelected(false);S11.setSelected(false);S12.setSelected(false);S13.setSelected(false);
          		   S14.setSelected(false);S15.setSelected(false);S16.setSelected(false);S17.setSelected(false);S18.setSelected(false);S19.setSelected(false);S20.setSelected(false);
        		   S21.setSelected(false);S22.setSelected(false);S23.setSelected(false);S24.setSelected(false);S25.setSelected(false);S26.setSelected(false);S27.setSelected(false);
          		   S28.setSelected(false);S29.setSelected(false);S30.setSelected(false);S31.setSelected(false);S32.setSelected(false);S33.setSelected(false);S34.setSelected(false);
          		   S35.setSelected(false);S36.setSelected(false);S37.setSelected(false);S38.setSelected(false);S39.setSelected(false);S40.setSelected(false);S41.setSelected(false);
          		   S42.setSelected(false);S43.setSelected(false);S44.setSelected(false);S45.setSelected(false);S46.setSelected(false);S47.setSelected(false);S48.setSelected(false);
          		   S49.setSelected(false);S50.setSelected(false);S51.setSelected(false);S52.setSelected(false);S53.setSelected(false);S54.setSelected(false);S55.setSelected(false);
          		   S56.setSelected(false);
        		try {
                  Class.forName("com.mysql.jdbc.Driver");
                  Connection con = DriverManager.getConnection("jdbc:mysql://localhost:3306/airline", "root", "root");
                  Statement stmt = con.createStatement();
                  String sql1 = "select * from flightdetails where fid='"+fid.getText()+"'";
                  rs = stmt.executeQuery(sql1);
                  while(rs.next())
                  {
                	   int seats = Integer.parseInt(rs.getString("nobc"));
                	   if(seats==1)
                	   {
                		   S1.setVisible(true);
                	   }
                	   if(seats==2)
                	   {
                		   S1.setVisible(true);S2.setVisible(true);
                	   }
                	   if(seats==3)
                	   {
                		   S1.setVisible(true);S2.setVisible(true);S3.setVisible(true);
                	   }
                	   if(seats==4)
                	   {
                		   S1.setVisible(true);S2.setVisible(true);S3.setVisible(true);S4.setVisible(true);
                	   }
                	   if(seats==5)
                	   {
                		   S1.setVisible(true);S2.setVisible(true);S3.setVisible(true);S4.setVisible(true);S5.setVisible(true);
                	   }
                	   if(seats==6)
                	   {
                		   S1.setVisible(true);S2.setVisible(true);S3.setVisible(true);S4.setVisible(true);S4.setVisible(true);S5.setVisible(true);S6.setVisible(true);
                	   }
                	   if(seats==7)
                	   {
                		   S1.setVisible(true);S2.setVisible(true);S3.setVisible(true);S4.setVisible(true);S4.setVisible(true);S5.setVisible(true);S6.setVisible(true);
                		   S7.setVisible(true);
                	   }
                	   if(seats==8)
                	   {
                		   S1.setVisible(true);S2.setVisible(true);S3.setVisible(true);S4.setVisible(true);S4.setVisible(true);S5.setVisible(true);S6.setVisible(true);
                		   S7.setVisible(true);S8.setVisible(true);
                	   }
                	   if(seats==9)
                	   {
                		   S1.setVisible(true);S2.setVisible(true);S3.setVisible(true);S4.setVisible(true);S4.setVisible(true);S5.setVisible(true);S6.setVisible(true);
                		   S7.setVisible(true);S8.setVisible(true);S9.setVisible(true);
                	   }
                	   if(seats==10)
                	   {
                		   S1.setVisible(true);S2.setVisible(true);S3.setVisible(true);S4.setVisible(true);S4.setVisible(true);S5.setVisible(true);S6.setVisible(true);
                		   S7.setVisible(true);S8.setVisible(true);S9.setVisible(true);S10.setVisible(true);
                	   }
                	   if(seats==11)
                	   {
                		   S1.setVisible(true);S2.setVisible(true);S3.setVisible(true);S4.setVisible(true);S4.setVisible(true);S5.setVisible(true);S6.setVisible(true);
                		   S7.setVisible(true);S8.setVisible(true);S9.setVisible(true);S10.setVisible(true);S11.setVisible(true);
                	   }
                	   if(seats==12)
                	   {
                		   S1.setVisible(true);S2.setVisible(true);S3.setVisible(true);S4.setVisible(true);S4.setVisible(true);S5.setVisible(true);S6.setVisible(true);
                		   S7.setVisible(true);S8.setVisible(true);S9.setVisible(true);S10.setVisible(true);S11.setVisible(true);S12.setVisible(true);
                	   }
                	   if(seats==13)
                	   {
                		   S1.setVisible(true);S2.setVisible(true);S3.setVisible(true);S4.setVisible(true);S4.setVisible(true);S5.setVisible(true);S6.setVisible(true);
                		   S7.setVisible(true);S8.setVisible(true);S9.setVisible(true);S10.setVisible(true);S11.setVisible(true);S12.setVisible(true);S13.setVisible(true);
                	   }
                	   if(seats==14)
                	   {
                		   S1.setVisible(true);S2.setVisible(true);S3.setVisible(true);S4.setVisible(true);S4.setVisible(true);S5.setVisible(true);S6.setVisible(true);
                		   S7.setVisible(true);S8.setVisible(true);S9.setVisible(true);S10.setVisible(true);S11.setVisible(true);S12.setVisible(true);S13.setVisible(true);
                		   S14.setVisible(true);
                	   }
                	   if(seats==15)
                	   {
                		   S1.setVisible(true);S2.setVisible(true);S3.setVisible(true);S4.setVisible(true);S4.setVisible(true);S5.setVisible(true);S6.setVisible(true);
                		   S7.setVisible(true);S8.setVisible(true);S9.setVisible(true);S10.setVisible(true);S11.setVisible(true);S12.setVisible(true);S13.setVisible(true);
                		   S14.setVisible(true);S15.setVisible(true);
                	   }
                	   if(seats==16)
                	   {
                		   S1.setVisible(true);S2.setVisible(true);S3.setVisible(true);S4.setVisible(true);S4.setVisible(true);S5.setVisible(true);S6.setVisible(true);
                		   S7.setVisible(true);S8.setVisible(true);S9.setVisible(true);S10.setVisible(true);S11.setVisible(true);S12.setVisible(true);S13.setVisible(true);
                		   S14.setVisible(true);S15.setVisible(true);S16.setVisible(true);
                	   }
                	   if(seats==17)
                	   {
                		   S1.setVisible(true);S2.setVisible(true);S3.setVisible(true);S4.setVisible(true);S4.setVisible(true);S5.setVisible(true);S6.setVisible(true);
                		   S7.setVisible(true);S8.setVisible(true);S9.setVisible(true);S10.setVisible(true);S11.setVisible(true);S12.setVisible(true);S13.setVisible(true);
                		   S14.setVisible(true);S15.setVisible(true);S16.setVisible(true);S17.setVisible(true);
                	   }
                	   if(seats==18)
                	   {
                		   S1.setVisible(true);S2.setVisible(true);S3.setVisible(true);S4.setVisible(true);S4.setVisible(true);S5.setVisible(true);S6.setVisible(true);
                		   S7.setVisible(true);S8.setVisible(true);S9.setVisible(true);S10.setVisible(true);S11.setVisible(true);S12.setVisible(true);S13.setVisible(true);
                		   S14.setVisible(true);S15.setVisible(true);S16.setVisible(true);S17.setVisible(true);S18.setVisible(true);
                	   }
                	   if(seats==19)
                	   {
                		   S1.setVisible(true);S2.setVisible(true);S3.setVisible(true);S4.setVisible(true);S4.setVisible(true);S5.setVisible(true);S6.setVisible(true);
                		   S7.setVisible(true);S8.setVisible(true);S9.setVisible(true);S10.setVisible(true);S11.setVisible(true);S12.setVisible(true);S13.setVisible(true);
                		   S14.setVisible(true);S15.setVisible(true);S16.setVisible(true);S17.setVisible(true);S18.setVisible(true);S19.setVisible(true);
                	   }
                	   if(seats==20)
                	   {
                		   S1.setVisible(true);S2.setVisible(true);S3.setVisible(true);S4.setVisible(true);S4.setVisible(true);S5.setVisible(true);S6.setVisible(true);
                		   S7.setVisible(true);S8.setVisible(true);S9.setVisible(true);S10.setVisible(true);S11.setVisible(true);S12.setVisible(true);S13.setVisible(true);
                		   S14.setVisible(true);S15.setVisible(true);S16.setVisible(true);S17.setVisible(true);S18.setVisible(true);S19.setVisible(true);S20.setVisible(true);
                	   }
                	   if(seats==21)
                	   {
                		   S1.setVisible(true);S2.setVisible(true);S3.setVisible(true);S4.setVisible(true);S4.setVisible(true);S5.setVisible(true);S6.setVisible(true);
                		   S7.setVisible(true);S8.setVisible(true);S9.setVisible(true);S10.setVisible(true);S11.setVisible(true);S12.setVisible(true);S13.setVisible(true);
                		   S14.setVisible(true);S15.setVisible(true);S16.setVisible(true);S17.setVisible(true);S18.setVisible(true);S19.setVisible(true);S20.setVisible(true);
                		   S21.setVisible(true);
                	   }
                	   if(seats==22)
                	   {
                		   S1.setVisible(true);S2.setVisible(true);S3.setVisible(true);S4.setVisible(true);S4.setVisible(true);S5.setVisible(true);S6.setVisible(true);
                		   S7.setVisible(true);S8.setVisible(true);S9.setVisible(true);S10.setVisible(true);S11.setVisible(true);S12.setVisible(true);S13.setVisible(true);
                		   S14.setVisible(true);S15.setVisible(true);S16.setVisible(true);S17.setVisible(true);S18.setVisible(true);S19.setVisible(true);S20.setVisible(true);
                		   S21.setVisible(true);S22.setVisible(true);
                	   }
                	   if(seats==23)
                	   {
                		   S1.setVisible(true);S2.setVisible(true);S3.setVisible(true);S4.setVisible(true);S4.setVisible(true);S5.setVisible(true);S6.setVisible(true);
                		   S7.setVisible(true);S8.setVisible(true);S9.setVisible(true);S10.setVisible(true);S11.setVisible(true);S12.setVisible(true);S13.setVisible(true);
                		   S14.setVisible(true);S15.setVisible(true);S16.setVisible(true);S17.setVisible(true);S18.setVisible(true);S19.setVisible(true);S20.setVisible(true);
                		   S21.setVisible(true);S22.setVisible(true);S23.setVisible(true);
                	   }
                	   if(seats==24)
                	   {
                		   S1.setVisible(true);S2.setVisible(true);S3.setVisible(true);S4.setVisible(true);S4.setVisible(true);S5.setVisible(true);S6.setVisible(true);
                		   S7.setVisible(true);S8.setVisible(true);S9.setVisible(true);S10.setVisible(true);S11.setVisible(true);S12.setVisible(true);S13.setVisible(true);
                		   S14.setVisible(true);S15.setVisible(true);S16.setVisible(true);S17.setVisible(true);S18.setVisible(true);S19.setVisible(true);S20.setVisible(true);
                		   S21.setVisible(true);S22.setVisible(true);S23.setVisible(true);S24.setVisible(true);
                	   }
                	   if(seats==25)
                	   {
                		   S1.setVisible(true);S2.setVisible(true);S3.setVisible(true);S4.setVisible(true);S4.setVisible(true);S5.setVisible(true);S6.setVisible(true);
                		   S7.setVisible(true);S8.setVisible(true);S9.setVisible(true);S10.setVisible(true);S11.setVisible(true);S12.setVisible(true);S13.setVisible(true);
                		   S14.setVisible(true);S15.setVisible(true);S16.setVisible(true);S17.setVisible(true);S18.setVisible(true);S19.setVisible(true);S20.setVisible(true);
                		   S21.setVisible(true);S22.setVisible(true);S23.setVisible(true);S24.setVisible(true);S25.setVisible(true);
                	   }
                	   if(seats==26)
                	   {
                		   S1.setVisible(true);S2.setVisible(true);S3.setVisible(true);S4.setVisible(true);S4.setVisible(true);S5.setVisible(true);S6.setVisible(true);
                		   S7.setVisible(true);S8.setVisible(true);S9.setVisible(true);S10.setVisible(true);S11.setVisible(true);S12.setVisible(true);S13.setVisible(true);
                		   S14.setVisible(true);S15.setVisible(true);S16.setVisible(true);S17.setVisible(true);S18.setVisible(true);S19.setVisible(true);S20.setVisible(true);
                		   S21.setVisible(true);S22.setVisible(true);S23.setVisible(true);S24.setVisible(true);S25.setVisible(true);S26.setVisible(true);
                	   }
                	   if(seats==27)
                	   {
                		   S1.setVisible(true);S2.setVisible(true);S3.setVisible(true);S4.setVisible(true);S4.setVisible(true);S5.setVisible(true);S6.setVisible(true);
                		   S7.setVisible(true);S8.setVisible(true);S9.setVisible(true);S10.setVisible(true);S11.setVisible(true);S12.setVisible(true);S13.setVisible(true);
                		   S14.setVisible(true);S15.setVisible(true);S16.setVisible(true);S17.setVisible(true);S18.setVisible(true);S19.setVisible(true);S20.setVisible(true);
                		   S21.setVisible(true);S22.setVisible(true);S23.setVisible(true);S24.setVisible(true);S25.setVisible(true);S26.setVisible(true);S27.setVisible(true);
                	   }
                	   if(seats==28)
                	   {
                		   S1.setVisible(true);S2.setVisible(true);S3.setVisible(true);S4.setVisible(true);S4.setVisible(true);S5.setVisible(true);S6.setVisible(true);
                		   S7.setVisible(true);S8.setVisible(true);S9.setVisible(true);S10.setVisible(true);S11.setVisible(true);S12.setVisible(true);S13.setVisible(true);
                		   S14.setVisible(true);S15.setVisible(true);S16.setVisible(true);S17.setVisible(true);S18.setVisible(true);S19.setVisible(true);S20.setVisible(true);
                		   S21.setVisible(true);S22.setVisible(true);S23.setVisible(true);S24.setVisible(true);S25.setVisible(true);S26.setVisible(true);S27.setVisible(true);
                		   S28.setVisible(true);
                	   }
                	   if(seats==29)
                	   {
                		   S1.setVisible(true);S2.setVisible(true);S3.setVisible(true);S4.setVisible(true);S4.setVisible(true);S5.setVisible(true);S6.setVisible(true);
                		   S7.setVisible(true);S8.setVisible(true);S9.setVisible(true);S10.setVisible(true);S11.setVisible(true);S12.setVisible(true);S13.setVisible(true);
                		   S14.setVisible(true);S15.setVisible(true);S16.setVisible(true);S17.setVisible(true);S18.setVisible(true);S19.setVisible(true);S20.setVisible(true);
                		   S21.setVisible(true);S22.setVisible(true);S23.setVisible(true);S24.setVisible(true);S25.setVisible(true);S26.setVisible(true);S27.setVisible(true);
                		   S28.setVisible(true);S29.setVisible(true);
                	   }
                	   if(seats==30)
                	   {
                		   S1.setVisible(true);S2.setVisible(true);S3.setVisible(true);S4.setVisible(true);S4.setVisible(true);S5.setVisible(true);S6.setVisible(true);
                		   S7.setVisible(true);S8.setVisible(true);S9.setVisible(true);S10.setVisible(true);S11.setVisible(true);S12.setVisible(true);S13.setVisible(true);
                		   S14.setVisible(true);S15.setVisible(true);S16.setVisible(true);S17.setVisible(true);S18.setVisible(true);S19.setVisible(true);S20.setVisible(true);
                		   S21.setVisible(true);S22.setVisible(true);S23.setVisible(true);S24.setVisible(true);S25.setVisible(true);S26.setVisible(true);S27.setVisible(true);
                		   S28.setVisible(true);S29.setVisible(true);S30.setVisible(true);
                	   }
                	   if(seats==31)
                	   {
                		   S1.setVisible(true);S2.setVisible(true);S3.setVisible(true);S4.setVisible(true);S4.setVisible(true);S5.setVisible(true);S6.setVisible(true);
                		   S7.setVisible(true);S8.setVisible(true);S9.setVisible(true);S10.setVisible(true);S11.setVisible(true);S12.setVisible(true);S13.setVisible(true);
                		   S14.setVisible(true);S15.setVisible(true);S16.setVisible(true);S17.setVisible(true);S18.setVisible(true);S19.setVisible(true);S20.setVisible(true);
                		   S21.setVisible(true);S22.setVisible(true);S23.setVisible(true);S24.setVisible(true);S25.setVisible(true);S26.setVisible(true);S27.setVisible(true);
                		   S28.setVisible(true);S29.setVisible(true);S30.setVisible(true);S31.setVisible(true);
                	   }
                	   if(seats==32)
                	   {
                		   S1.setVisible(true);S2.setVisible(true);S3.setVisible(true);S4.setVisible(true);S4.setVisible(true);S5.setVisible(true);S6.setVisible(true);
                		   S7.setVisible(true);S8.setVisible(true);S9.setVisible(true);S10.setVisible(true);S11.setVisible(true);S12.setVisible(true);S13.setVisible(true);
                		   S14.setVisible(true);S15.setVisible(true);S16.setVisible(true);S17.setVisible(true);S18.setVisible(true);S19.setVisible(true);S20.setVisible(true);
                		   S21.setVisible(true);S22.setVisible(true);S23.setVisible(true);S24.setVisible(true);S25.setVisible(true);S26.setVisible(true);S27.setVisible(true);
                		   S28.setVisible(true);S29.setVisible(true);S30.setVisible(true);S31.setVisible(true);S32.setVisible(true);
                	   }
                	   if(seats==33)
                	   {
                		   S1.setVisible(true);S2.setVisible(true);S3.setVisible(true);S4.setVisible(true);S4.setVisible(true);S5.setVisible(true);S6.setVisible(true);
                		   S7.setVisible(true);S8.setVisible(true);S9.setVisible(true);S10.setVisible(true);S11.setVisible(true);S12.setVisible(true);S13.setVisible(true);
                		   S14.setVisible(true);S15.setVisible(true);S16.setVisible(true);S17.setVisible(true);S18.setVisible(true);S19.setVisible(true);S20.setVisible(true);
                		   S21.setVisible(true);S22.setVisible(true);S23.setVisible(true);S24.setVisible(true);S25.setVisible(true);S26.setVisible(true);S27.setVisible(true);
                		   S28.setVisible(true);S29.setVisible(true);S30.setVisible(true);S31.setVisible(true);S32.setVisible(true);S33.setVisible(true);
                	   }
                	   if(seats==34)
                	   {
                		   S1.setVisible(true);S2.setVisible(true);S3.setVisible(true);S4.setVisible(true);S4.setVisible(true);S5.setVisible(true);S6.setVisible(true);
                		   S7.setVisible(true);S8.setVisible(true);S9.setVisible(true);S10.setVisible(true);S11.setVisible(true);S12.setVisible(true);S13.setVisible(true);
                		   S14.setVisible(true);S15.setVisible(true);S16.setVisible(true);S17.setVisible(true);S18.setVisible(true);S19.setVisible(true);S20.setVisible(true);
                		   S21.setVisible(true);S22.setVisible(true);S23.setVisible(true);S24.setVisible(true);S25.setVisible(true);S26.setVisible(true);S27.setVisible(true);
                		   S28.setVisible(true);S29.setVisible(true);S30.setVisible(true);S31.setVisible(true);S32.setVisible(true);S33.setVisible(true);S34.setVisible(true);
                	   }
                	   if(seats==35)
                	   {
                		   S1.setVisible(true);S2.setVisible(true);S3.setVisible(true);S4.setVisible(true);S4.setVisible(true);S5.setVisible(true);S6.setVisible(true);
                		   S7.setVisible(true);S8.setVisible(true);S9.setVisible(true);S10.setVisible(true);S11.setVisible(true);S12.setVisible(true);S13.setVisible(true);
                		   S14.setVisible(true);S15.setVisible(true);S16.setVisible(true);S17.setVisible(true);S18.setVisible(true);S19.setVisible(true);S20.setVisible(true);
                		   S21.setVisible(true);S22.setVisible(true);S23.setVisible(true);S24.setVisible(true);S25.setVisible(true);S26.setVisible(true);S27.setVisible(true);
                		   S28.setVisible(true);S29.setVisible(true);S30.setVisible(true);S31.setVisible(true);S32.setVisible(true);S33.setVisible(true);S34.setVisible(true);
                		   S35.setVisible(true);
                	   }
                	   if(seats==36)
                	   {
                		   S1.setVisible(true);S2.setVisible(true);S3.setVisible(true);S4.setVisible(true);S4.setVisible(true);S5.setVisible(true);S6.setVisible(true);
                		   S7.setVisible(true);S8.setVisible(true);S9.setVisible(true);S10.setVisible(true);S11.setVisible(true);S12.setVisible(true);S13.setVisible(true);
                		   S14.setVisible(true);S15.setVisible(true);S16.setVisible(true);S17.setVisible(true);S18.setVisible(true);S19.setVisible(true);S20.setVisible(true);
                		   S21.setVisible(true);S22.setVisible(true);S23.setVisible(true);S24.setVisible(true);S25.setVisible(true);S26.setVisible(true);S27.setVisible(true);
                		   S28.setVisible(true);S29.setVisible(true);S30.setVisible(true);S31.setVisible(true);S32.setVisible(true);S33.setVisible(true);S34.setVisible(true);
                		   S35.setVisible(true);S36.setVisible(true);
                	   }
                	   if(seats==37)
                	   {
                		   S1.setVisible(true);S2.setVisible(true);S3.setVisible(true);S4.setVisible(true);S4.setVisible(true);S5.setVisible(true);S6.setVisible(true);
                		   S7.setVisible(true);S8.setVisible(true);S9.setVisible(true);S10.setVisible(true);S11.setVisible(true);S12.setVisible(true);S13.setVisible(true);
                		   S14.setVisible(true);S15.setVisible(true);S16.setVisible(true);S17.setVisible(true);S18.setVisible(true);S19.setVisible(true);S20.setVisible(true);
                		   S21.setVisible(true);S22.setVisible(true);S23.setVisible(true);S24.setVisible(true);S25.setVisible(true);S26.setVisible(true);S27.setVisible(true);
                		   S28.setVisible(true);S29.setVisible(true);S30.setVisible(true);S31.setVisible(true);S32.setVisible(true);S33.setVisible(true);S34.setVisible(true);
                		   S35.setVisible(true);S36.setVisible(true);S37.setVisible(true);
                	   }
                	   if(seats==38)
                	   {
                		   S1.setVisible(true);S2.setVisible(true);S3.setVisible(true);S4.setVisible(true);S4.setVisible(true);S5.setVisible(true);S6.setVisible(true);
                		   S7.setVisible(true);S8.setVisible(true);S9.setVisible(true);S10.setVisible(true);S11.setVisible(true);S12.setVisible(true);S13.setVisible(true);
                		   S14.setVisible(true);S15.setVisible(true);S16.setVisible(true);S17.setVisible(true);S18.setVisible(true);S19.setVisible(true);S20.setVisible(true);
                		   S21.setVisible(true);S22.setVisible(true);S23.setVisible(true);S24.setVisible(true);S25.setVisible(true);S26.setVisible(true);S27.setVisible(true);
                		   S28.setVisible(true);S29.setVisible(true);S30.setVisible(true);S31.setVisible(true);S32.setVisible(true);S33.setVisible(true);S34.setVisible(true);
                		   S35.setVisible(true);S36.setVisible(true);S37.setVisible(true);S38.setVisible(true);
                	   }
                	   if(seats==39)
                	   {
                		   S1.setVisible(true);S2.setVisible(true);S3.setVisible(true);S4.setVisible(true);S4.setVisible(true);S5.setVisible(true);S6.setVisible(true);
                		   S7.setVisible(true);S8.setVisible(true);S9.setVisible(true);S10.setVisible(true);S11.setVisible(true);S12.setVisible(true);S13.setVisible(true);
                		   S14.setVisible(true);S15.setVisible(true);S16.setVisible(true);S17.setVisible(true);S18.setVisible(true);S19.setVisible(true);S20.setVisible(true);
                		   S21.setVisible(true);S22.setVisible(true);S23.setVisible(true);S24.setVisible(true);S25.setVisible(true);S26.setVisible(true);S27.setVisible(true);
                		   S28.setVisible(true);S29.setVisible(true);S30.setVisible(true);S31.setVisible(true);S32.setVisible(true);S33.setVisible(true);S34.setVisible(true);
                		   S35.setVisible(true);S36.setVisible(true);S37.setVisible(true);S38.setVisible(true);S39.setVisible(true);
                	   }
                	   if(seats==40)
                	   {
                		   S1.setVisible(true);S2.setVisible(true);S3.setVisible(true);S4.setVisible(true);S4.setVisible(true);S5.setVisible(true);S6.setVisible(true);
                		   S7.setVisible(true);S8.setVisible(true);S9.setVisible(true);S10.setVisible(true);S11.setVisible(true);S12.setVisible(true);S13.setVisible(true);
                		   S14.setVisible(true);S15.setVisible(true);S16.setVisible(true);S17.setVisible(true);S18.setVisible(true);S19.setVisible(true);S20.setVisible(true);
                		   S21.setVisible(true);S22.setVisible(true);S23.setVisible(true);S24.setVisible(true);S25.setVisible(true);S26.setVisible(true);S27.setVisible(true);
                		   S28.setVisible(true);S29.setVisible(true);S30.setVisible(true);S31.setVisible(true);S32.setVisible(true);S33.setVisible(true);S34.setVisible(true);
                		   S35.setVisible(true);S36.setVisible(true);S37.setVisible(true);S38.setVisible(true);S39.setVisible(true);S40.setVisible(true);
                	   }
                	   if(seats==41)
                	   {
                		   S1.setVisible(true);S2.setVisible(true);S3.setVisible(true);S4.setVisible(true);S4.setVisible(true);S5.setVisible(true);S6.setVisible(true);
                		   S7.setVisible(true);S8.setVisible(true);S9.setVisible(true);S10.setVisible(true);S11.setVisible(true);S12.setVisible(true);S13.setVisible(true);
                		   S14.setVisible(true);S15.setVisible(true);S16.setVisible(true);S17.setVisible(true);S18.setVisible(true);S19.setVisible(true);S20.setVisible(true);
                		   S21.setVisible(true);S22.setVisible(true);S23.setVisible(true);S24.setVisible(true);S25.setVisible(true);S26.setVisible(true);S27.setVisible(true);
                		   S28.setVisible(true);S29.setVisible(true);S30.setVisible(true);S31.setVisible(true);S32.setVisible(true);S33.setVisible(true);S34.setVisible(true);
                		   S35.setVisible(true);S36.setVisible(true);S37.setVisible(true);S38.setVisible(true);S39.setVisible(true);S40.setVisible(true);S41.setVisible(true);
                	   }
                	   if(seats==42)
                	   {
                		   S1.setVisible(true);S2.setVisible(true);S3.setVisible(true);S4.setVisible(true);S4.setVisible(true);S5.setVisible(true);S6.setVisible(true);
                		   S7.setVisible(true);S8.setVisible(true);S9.setVisible(true);S10.setVisible(true);S11.setVisible(true);S12.setVisible(true);S13.setVisible(true);
                		   S14.setVisible(true);S15.setVisible(true);S16.setVisible(true);S17.setVisible(true);S18.setVisible(true);S19.setVisible(true);S20.setVisible(true);
                		   S21.setVisible(true);S22.setVisible(true);S23.setVisible(true);S24.setVisible(true);S25.setVisible(true);S26.setVisible(true);S27.setVisible(true);
                		   S28.setVisible(true);S29.setVisible(true);S30.setVisible(true);S31.setVisible(true);S32.setVisible(true);S33.setVisible(true);S34.setVisible(true);
                		   S35.setVisible(true);S36.setVisible(true);S37.setVisible(true);S38.setVisible(true);S39.setVisible(true);S40.setVisible(true);S41.setVisible(true);
                		   S42.setVisible(true);
                	   }
                	   if(seats==43)
                	   {
                		   S1.setVisible(true);S2.setVisible(true);S3.setVisible(true);S4.setVisible(true);S4.setVisible(true);S5.setVisible(true);S6.setVisible(true);
                		   S7.setVisible(true);S8.setVisible(true);S9.setVisible(true);S10.setVisible(true);S11.setVisible(true);S12.setVisible(true);S13.setVisible(true);
                		   S14.setVisible(true);S15.setVisible(true);S16.setVisible(true);S17.setVisible(true);S18.setVisible(true);S19.setVisible(true);S20.setVisible(true);
                		   S21.setVisible(true);S22.setVisible(true);S23.setVisible(true);S24.setVisible(true);S25.setVisible(true);S26.setVisible(true);S27.setVisible(true);
                		   S28.setVisible(true);S29.setVisible(true);S30.setVisible(true);S31.setVisible(true);S32.setVisible(true);S33.setVisible(true);S34.setVisible(true);
                		   S35.setVisible(true);S36.setVisible(true);S37.setVisible(true);S38.setVisible(true);S39.setVisible(true);S40.setVisible(true);S41.setVisible(true);
                		   S42.setVisible(true);S43.setVisible(true);
                	   }
                	   if(seats==44)
                	   {
                		   S1.setVisible(true);S2.setVisible(true);S3.setVisible(true);S4.setVisible(true);S4.setVisible(true);S5.setVisible(true);S6.setVisible(true);
                		   S7.setVisible(true);S8.setVisible(true);S9.setVisible(true);S10.setVisible(true);S11.setVisible(true);S12.setVisible(true);S13.setVisible(true);
                		   S14.setVisible(true);S15.setVisible(true);S16.setVisible(true);S17.setVisible(true);S18.setVisible(true);S19.setVisible(true);S20.setVisible(true);
                		   S21.setVisible(true);S22.setVisible(true);S23.setVisible(true);S24.setVisible(true);S25.setVisible(true);S26.setVisible(true);S27.setVisible(true);
                		   S28.setVisible(true);S29.setVisible(true);S30.setVisible(true);S31.setVisible(true);S32.setVisible(true);S33.setVisible(true);S34.setVisible(true);
                		   S35.setVisible(true);S36.setVisible(true);S37.setVisible(true);S38.setVisible(true);S39.setVisible(true);S40.setVisible(true);S41.setVisible(true);
                		   S42.setVisible(true);S43.setVisible(true);S44.setVisible(true);
                	   }
                	   
                	   if(seats==45)
                	   {
                		   S1.setVisible(true);S2.setVisible(true);S3.setVisible(true);S4.setVisible(true);S4.setVisible(true);S5.setVisible(true);S6.setVisible(true);
                		   S7.setVisible(true);S8.setVisible(true);S9.setVisible(true);S10.setVisible(true);S11.setVisible(true);S12.setVisible(true);S13.setVisible(true);
                		   S14.setVisible(true);S15.setVisible(true);S16.setVisible(true);S17.setVisible(true);S18.setVisible(true);S19.setVisible(true);S20.setVisible(true);
                		   S21.setVisible(true);S22.setVisible(true);S23.setVisible(true);S24.setVisible(true);S25.setVisible(true);S26.setVisible(true);S27.setVisible(true);
                		   S28.setVisible(true);S29.setVisible(true);S30.setVisible(true);S31.setVisible(true);S32.setVisible(true);S33.setVisible(true);S34.setVisible(true);
                		   S35.setVisible(true);S36.setVisible(true);S37.setVisible(true);S38.setVisible(true);S39.setVisible(true);S40.setVisible(true);S41.setVisible(true);
                		   S42.setVisible(true);S43.setVisible(true);S44.setVisible(true);S45.setVisible(true);
                	   }
                	   if(seats==46)
                	   {
                		   S1.setVisible(true);S2.setVisible(true);S3.setVisible(true);S4.setVisible(true);S4.setVisible(true);S5.setVisible(true);S6.setVisible(true);
                		   S7.setVisible(true);S8.setVisible(true);S9.setVisible(true);S10.setVisible(true);S11.setVisible(true);S12.setVisible(true);S13.setVisible(true);
                		   S14.setVisible(true);S15.setVisible(true);S16.setVisible(true);S17.setVisible(true);S18.setVisible(true);S19.setVisible(true);S20.setVisible(true);
                		   S21.setVisible(true);S22.setVisible(true);S23.setVisible(true);S24.setVisible(true);S25.setVisible(true);S26.setVisible(true);S27.setVisible(true);
                		   S28.setVisible(true);S29.setVisible(true);S30.setVisible(true);S31.setVisible(true);S32.setVisible(true);S33.setVisible(true);S34.setVisible(true);
                		   S35.setVisible(true);S36.setVisible(true);S37.setVisible(true);S38.setVisible(true);S39.setVisible(true);S40.setVisible(true);S41.setVisible(true);
                		   S42.setVisible(true);S43.setVisible(true);S44.setVisible(true);S45.setVisible(true);S46.setVisible(true);
                	   }
                	   if(seats==47)
                	   {
                		   S1.setVisible(true);S2.setVisible(true);S3.setVisible(true);S4.setVisible(true);S4.setVisible(true);S5.setVisible(true);S6.setVisible(true);
                		   S7.setVisible(true);S8.setVisible(true);S9.setVisible(true);S10.setVisible(true);S11.setVisible(true);S12.setVisible(true);S13.setVisible(true);
                		   S14.setVisible(true);S15.setVisible(true);S16.setVisible(true);S17.setVisible(true);S18.setVisible(true);S19.setVisible(true);S20.setVisible(true);
                		   S28.setVisible(true);S29.setVisible(true);S30.setVisible(true);S31.setVisible(true);S32.setVisible(true);S33.setVisible(true);S34.setVisible(true);
                		   S35.setVisible(true);S36.setVisible(true);S37.setVisible(true);S38.setVisible(true);S39.setVisible(true);S40.setVisible(true);S41.setVisible(true);
                		   S42.setVisible(true);S43.setVisible(true);S44.setVisible(true);S45.setVisible(true);S46.setVisible(true);S47.setVisible(true);
                	   }
                	   if(seats==48)
                	   {
                		   S1.setVisible(true);S2.setVisible(true);S3.setVisible(true);S4.setVisible(true);S4.setVisible(true);S5.setVisible(true);S6.setVisible(true);
                		   S7.setVisible(true);S8.setVisible(true);S9.setVisible(true);S10.setVisible(true);S11.setVisible(true);S12.setVisible(true);S13.setVisible(true);
                		   S14.setVisible(true);S15.setVisible(true);S16.setVisible(true);S17.setVisible(true);S18.setVisible(true);S19.setVisible(true);S20.setVisible(true);
                		   S21.setVisible(true);S22.setVisible(true);S23.setVisible(true);S24.setVisible(true);S25.setVisible(true);S26.setVisible(true);S27.setVisible(true);
                		   S28.setVisible(true);S29.setVisible(true);S30.setVisible(true);S31.setVisible(true);S32.setVisible(true);S33.setVisible(true);S34.setVisible(true);
                		   S35.setVisible(true);S36.setVisible(true);S37.setVisible(true);S38.setVisible(true);S39.setVisible(true);S40.setVisible(true);S41.setVisible(true);
                		   S42.setVisible(true);S43.setVisible(true);S44.setVisible(true);S45.setVisible(true);S46.setVisible(true);S47.setVisible(true);S48.setVisible(true);
                	   }
                	   if(seats==49)
                	   {
                		   S1.setVisible(true);S2.setVisible(true);S3.setVisible(true);S4.setVisible(true);S4.setVisible(true);S5.setVisible(true);S6.setVisible(true);
                		   S7.setVisible(true);S8.setVisible(true);S9.setVisible(true);S10.setVisible(true);S11.setVisible(true);S12.setVisible(true);S13.setVisible(true);
                		   S14.setVisible(true);S15.setVisible(true);S16.setVisible(true);S17.setVisible(true);S18.setVisible(true);S19.setVisible(true);S20.setVisible(true);
                		   S21.setVisible(true);S22.setVisible(true);S23.setVisible(true);S24.setVisible(true);S25.setVisible(true);S26.setVisible(true);S27.setVisible(true);
                		   S28.setVisible(true);S29.setVisible(true);S30.setVisible(true);S31.setVisible(true);S32.setVisible(true);S33.setVisible(true);S34.setVisible(true);
                		   S35.setVisible(true);S36.setVisible(true);S37.setVisible(true);S38.setVisible(true);S39.setVisible(true);S40.setVisible(true);S41.setVisible(true);
                		   S42.setVisible(true);S43.setVisible(true);S44.setVisible(true);S45.setVisible(true);S46.setVisible(true);S47.setVisible(true);S48.setVisible(true);
                		   S49.setVisible(true);
                	   }
                	   if(seats==50)
                	   {
                		   S1.setVisible(true);S2.setVisible(true);S3.setVisible(true);S4.setVisible(true);S4.setVisible(true);S5.setVisible(true);S6.setVisible(true);
                		   S7.setVisible(true);S8.setVisible(true);S9.setVisible(true);S10.setVisible(true);S11.setVisible(true);S12.setVisible(true);S13.setVisible(true);
                		   S14.setVisible(true);S15.setVisible(true);S16.setVisible(true);S17.setVisible(true);S18.setVisible(true);S19.setVisible(true);S20.setVisible(true);
                		   S21.setVisible(true);S22.setVisible(true);S23.setVisible(true);S24.setVisible(true);S25.setVisible(true);S26.setVisible(true);S27.setVisible(true);
                		   S28.setVisible(true);S29.setVisible(true);S30.setVisible(true);S31.setVisible(true);S32.setVisible(true);S33.setVisible(true);S34.setVisible(true);
                		   S35.setVisible(true);S36.setVisible(true);S37.setVisible(true);S38.setVisible(true);S39.setVisible(true);S40.setVisible(true);S41.setVisible(true);
                		   S42.setVisible(true);S43.setVisible(true);S44.setVisible(true);S45.setVisible(true);S46.setVisible(true);S47.setVisible(true);S48.setVisible(true);
                		   S49.setVisible(true);S50.setVisible(true);
                	   }
                	   if(seats==51)
                	   {
                		   S1.setVisible(true);S2.setVisible(true);S3.setVisible(true);S4.setVisible(true);S4.setVisible(true);S5.setVisible(true);S6.setVisible(true);
                		   S7.setVisible(true);S8.setVisible(true);S9.setVisible(true);S10.setVisible(true);S11.setVisible(true);S12.setVisible(true);S13.setVisible(true);
                		   S14.setVisible(true);S15.setVisible(true);S16.setVisible(true);S17.setVisible(true);S18.setVisible(true);S19.setVisible(true);S20.setVisible(true);
                		   S21.setVisible(true);S22.setVisible(true);S23.setVisible(true);S24.setVisible(true);S25.setVisible(true);S26.setVisible(true);S27.setVisible(true);
                		   S28.setVisible(true);S29.setVisible(true);S30.setVisible(true);S31.setVisible(true);S32.setVisible(true);S33.setVisible(true);S34.setVisible(true);
                		   S35.setVisible(true);S36.setVisible(true);S37.setVisible(true);S38.setVisible(true);S39.setVisible(true);S40.setVisible(true);S41.setVisible(true);
                		   S42.setVisible(true);S43.setVisible(true);S44.setVisible(true);S45.setVisible(true);S46.setVisible(true);S47.setVisible(true);S48.setVisible(true);
                		   S49.setVisible(true);S50.setVisible(true);S51.setVisible(true);
                	   }
                	   if(seats==52)
                	   {
                		   S1.setVisible(true);S2.setVisible(true);S3.setVisible(true);S4.setVisible(true);S4.setVisible(true);S5.setVisible(true);S6.setVisible(true);
                		   S7.setVisible(true);S8.setVisible(true);S9.setVisible(true);S10.setVisible(true);S11.setVisible(true);S12.setVisible(true);S13.setVisible(true);
                		   S14.setVisible(true);S15.setVisible(true);S16.setVisible(true);S17.setVisible(true);S18.setVisible(true);S19.setVisible(true);S20.setVisible(true);
                		   S21.setVisible(true);S22.setVisible(true);S23.setVisible(true);S24.setVisible(true);S25.setVisible(true);S26.setVisible(true);S27.setVisible(true);
                		   S28.setVisible(true);S29.setVisible(true);S30.setVisible(true);S31.setVisible(true);S32.setVisible(true);S33.setVisible(true);S34.setVisible(true);
                		   S35.setVisible(true);S36.setVisible(true);S37.setVisible(true);S38.setVisible(true);S39.setVisible(true);S40.setVisible(true);S41.setVisible(true);
                		   S42.setVisible(true);S43.setVisible(true);S44.setVisible(true);S45.setVisible(true);S46.setVisible(true);S47.setVisible(true);S48.setVisible(true);
                		   S49.setVisible(true);S50.setVisible(true);S51.setVisible(true);S52.setVisible(true);
                	   }
                	   if(seats==53)
                	   {
                		   S1.setVisible(true);S2.setVisible(true);S3.setVisible(true);S4.setVisible(true);S4.setVisible(true);S5.setVisible(true);S6.setVisible(true);
                		   S7.setVisible(true);S8.setVisible(true);S9.setVisible(true);S10.setVisible(true);S11.setVisible(true);S12.setVisible(true);S13.setVisible(true);
                		   S14.setVisible(true);S15.setVisible(true);S16.setVisible(true);S17.setVisible(true);S18.setVisible(true);S19.setVisible(true);S20.setVisible(true);
                		   S21.setVisible(true);S22.setVisible(true);S23.setVisible(true);S24.setVisible(true);S25.setVisible(true);S26.setVisible(true);S27.setVisible(true);
                		   S28.setVisible(true);S29.setVisible(true);S30.setVisible(true);S31.setVisible(true);S32.setVisible(true);S33.setVisible(true);S34.setVisible(true);
                		   S35.setVisible(true);S36.setVisible(true);S37.setVisible(true);S38.setVisible(true);S39.setVisible(true);S40.setVisible(true);S41.setVisible(true);
                		   S42.setVisible(true);S43.setVisible(true);S44.setVisible(true);S45.setVisible(true);S46.setVisible(true);S47.setVisible(true);S48.setVisible(true);
                		   S49.setVisible(true);S50.setVisible(true);S51.setVisible(true);S52.setVisible(true);S53.setVisible(true);
                	   }
                	   if(seats==54)
                	   {
                		   S1.setVisible(true);S2.setVisible(true);S3.setVisible(true);S4.setVisible(true);S4.setVisible(true);S5.setVisible(true);S6.setVisible(true);
                		   S7.setVisible(true);S8.setVisible(true);S9.setVisible(true);S10.setVisible(true);S11.setVisible(true);S12.setVisible(true);S13.setVisible(true);
                		   S14.setVisible(true);S15.setVisible(true);S16.setVisible(true);S17.setVisible(true);S18.setVisible(true);S19.setVisible(true);S20.setVisible(true);
                		   S21.setVisible(true);S22.setVisible(true);S23.setVisible(true);S24.setVisible(true);S25.setVisible(true);S26.setVisible(true);S27.setVisible(true);
                		   S28.setVisible(true);S29.setVisible(true);S30.setVisible(true);S31.setVisible(true);S32.setVisible(true);S33.setVisible(true);S34.setVisible(true);
                		   S35.setVisible(true);S36.setVisible(true);S37.setVisible(true);S38.setVisible(true);S39.setVisible(true);S40.setVisible(true);S41.setVisible(true);
                		   S42.setVisible(true);S43.setVisible(true);S44.setVisible(true);S45.setVisible(true);S46.setVisible(true);S47.setVisible(true);S48.setVisible(true);
                		   S49.setVisible(true);S50.setVisible(true);S51.setVisible(true);S52.setVisible(true);S53.setVisible(true);S54.setVisible(true);
                	   }
                	   if(seats==55)
                	   {
                		   S1.setVisible(true);S2.setVisible(true);S3.setVisible(true);S4.setVisible(true);S4.setVisible(true);S5.setVisible(true);S6.setVisible(true);
                		   S7.setVisible(true);S8.setVisible(true);S9.setVisible(true);S10.setVisible(true);S11.setVisible(true);S12.setVisible(true);S13.setVisible(true);
                		   S14.setVisible(true);S15.setVisible(true);S16.setVisible(true);S17.setVisible(true);S18.setVisible(true);S19.setVisible(true);S20.setVisible(true);
                		   S21.setVisible(true);S22.setVisible(true);S23.setVisible(true);S24.setVisible(true);S25.setVisible(true);S26.setVisible(true);S27.setVisible(true);
                		   S28.setVisible(true);S29.setVisible(true);S30.setVisible(true);S31.setVisible(true);S32.setVisible(true);S33.setVisible(true);S34.setVisible(true);
                		   S35.setVisible(true);S36.setVisible(true);S37.setVisible(true);S38.setVisible(true);S39.setVisible(true);S40.setVisible(true);S41.setVisible(true);
                		   S42.setVisible(true);S43.setVisible(true);S44.setVisible(true);S45.setVisible(true);S46.setVisible(true);S47.setVisible(true);S48.setVisible(true);
                		   S49.setVisible(true);S50.setVisible(true);S51.setVisible(true);S52.setVisible(true);S53.setVisible(true);S54.setVisible(true);S55.setVisible(true);
                	   }
                	   if(seats==56)
                	   {
                		   S1.setVisible(true);S2.setVisible(true);S3.setVisible(true);S4.setVisible(true);S4.setVisible(true);S5.setVisible(true);S6.setVisible(true);
                		   S7.setVisible(true);S8.setVisible(true);S9.setVisible(true);S10.setVisible(true);S11.setVisible(true);S12.setVisible(true);S13.setVisible(true);
                		   S14.setVisible(true);S15.setVisible(true);S16.setVisible(true);S17.setVisible(true);S18.setVisible(true);S19.setVisible(true);S20.setVisible(true);
                		   S21.setVisible(true);S22.setVisible(true);S23.setVisible(true);S24.setVisible(true);S25.setVisible(true);S26.setVisible(true);S27.setVisible(true);
                		   S28.setVisible(true);S29.setVisible(true);S30.setVisible(true);S31.setVisible(true);S32.setVisible(true);S33.setVisible(true);S34.setVisible(true);
                		   S35.setVisible(true);S36.setVisible(true);S37.setVisible(true);S38.setVisible(true);S39.setVisible(true);S40.setVisible(true);S41.setVisible(true);
                		   S42.setVisible(true);S43.setVisible(true);S44.setVisible(true);S45.setVisible(true);S46.setVisible(true);S47.setVisible(true);S48.setVisible(true);
                		   S49.setVisible(true);S50.setVisible(true);S51.setVisible(true);S52.setVisible(true);S53.setVisible(true);S54.setVisible(true);S55.setVisible(true);
                		   S56.setVisible(true);
                	   }
                	   
                	   }  
                	   
                  
                 
        			}
        		catch (ClassNotFoundException e1) {
                  // TODO Auto-generated catch block
                  e1.printStackTrace();
              } catch (SQLException e1) {
                  // TODO Auto-generated catch block
                  e1.printStackTrace();
              }
        		
        		
            	try {
                    Class.forName("com.mysql.jdbc.Driver");
                    Connection con = DriverManager.getConnection("jdbc:mysql://localhost:3306/airline", "root", "root");
                    Statement stmt = con.createStatement();
                    String sql1 = "select * from reserve where class='"+sc.getText()+"' AND fid='"+fid.getText()+"'and doj='"+doj.getText()+"'";							//Refine the search by adding flightID and coach type
                    rs = stmt.executeQuery(sql1);
                    while (rs.next()) {

                        int check = Integer.parseInt(rs.getString("seatid"));
                        switch (check) {
                            case 1: {
                                S1.setEnabled(false);
                                S1.setBackground(Color.yellow);
                                break;
                            }
                            case 2: {
                                S2.setEnabled(false);
                                S2.setBackground(Color.yellow);
                                break;
                            }
                            case 3: {
                                S3.setEnabled(false);
                                S3.setBackground(Color.yellow);
                                break;
                            }
                            case 4: {
                                S4.setEnabled(false);
                                S4.setBackground(Color.yellow);
                                break;
                            }
                            case 5: {
                                S5.setEnabled(false);
                                S5.setBackground(Color.yellow);
                                break;
                            }
                            case 6: {
                                S6.setEnabled(false);
                                S6.setBackground(Color.yellow);
                                break;
                            }
                            case 7: {
                                S7.setEnabled(false);
                                S7.setBackground(Color.yellow);
                                break;
                            }
                            case 8: {
                                S8.setEnabled(false);
                                S8.setBackground(Color.yellow);
                                break;
                            }
                            case 9: {
                                S9.setEnabled(false);
                                S9.setBackground(Color.yellow);
                                break;
                            }
                            case 10:{
                                S10.setEnabled(false);
                                S10.setBackground(Color.yellow);
                                break;
                            }
                            case 11: {
                                S11.setEnabled(false);
                                S11.setBackground(Color.yellow);
                                break;
                            }
                            case 12: {
                                S12.setEnabled(false);
                                S12.setBackground(Color.yellow);
                                break;
                            }
                            case 13: {
                                S13.setEnabled(false);
                                S13.setBackground(Color.yellow);
                                break;
                            }
                            case 14: {
                                S14.setEnabled(false);
                                S14.setBackground(Color.yellow);
                                break;
                            }
                            case 15: {
                                S15.setEnabled(false);
                                S15.setBackground(Color.yellow);
                                break;
                            }
                            case 16: {
                                S16.setEnabled(false);
                                S16.setBackground(Color.yellow);
                                break;
                            }
                            case 17: {
                                S17.setEnabled(false);
                                S17.setBackground(Color.yellow);
                                break;
                            }
                            case 18: {
                                S18.setEnabled(false);
                                S18.setBackground(Color.yellow);
                                break;
                            }
                            case 19: {
                                S19.setEnabled(false);
                                S19.setBackground(Color.yellow);
                                break;
                            }
                            case 20: {
                                S20.setEnabled(false);
                                S20.setBackground(Color.yellow);
                                break;
                            }
                            case 21: {
                                S21.setEnabled(false);
                                S21.setBackground(Color.yellow);
                                break;
                            }
                            case 22: {
                                S22.setEnabled(false);
                                S22.setBackground(Color.yellow);
                                break;
                            }
                            case 23: {
                                S23.setEnabled(false);
                                S23.setBackground(Color.yellow);
                                break;
                            }
                            case 24: {
                                S24.setEnabled(false);
                                S24.setBackground(Color.yellow);
                                break;
                            }
                            case 25: {
                                S25.setEnabled(false);
                                S25.setBackground(Color.yellow);
                                break;
                            }
                            case 26: {
                                S26.setEnabled(false);
                                S26.setBackground(Color.yellow);
                                break;
                            }
                            case 27: {
                                S27.setEnabled(false);
                                S27.setBackground(Color.yellow);
                                break;
                            }
                            case 28: {
                                S28.setEnabled(false);
                                S28.setBackground(Color.yellow);
                                break;
                            }
                            case 29: {
                                S29.setEnabled(false);
                                S29.setBackground(Color.yellow);
                                break;
                            }
                            case 30: {
                                S30.setEnabled(false);
                                S30.setBackground(Color.yellow);
                                break;
                            }
                            case 31: {
                                S31.setEnabled(false);
                                S31.setBackground(Color.yellow);
                                break;
                            }
                            case 32: {
                                S32.setEnabled(false);
                                S32.setBackground(Color.yellow);
                                break;
                            }
                            case 33: {
                                S33.setEnabled(false);
                                S33.setBackground(Color.yellow);
                                break;
                            }
                            case 34: {
                                S34.setEnabled(false);
                                S34.setBackground(Color.yellow);
                                break;
                            }
                            case 35: {
                                S35.setEnabled(false);
                                S35.setBackground(Color.yellow);
                                break;
                            }
                            case 36: {
                                S36.setEnabled(false);
                                S36.setBackground(Color.yellow);
                                break;
                            }
                            case 37: {
                                S37.setEnabled(false);
                                S37.setBackground(Color.yellow);
                                break;
                            }
                            case 38: {
                                S38.setEnabled(false);
                                S38.setBackground(Color.yellow);
                                break;
                            }
                            case 39: {
                                S39.setEnabled(false);
                                S39.setBackground(Color.yellow);
                                break;
                            }
                            case 40: {
                                S40.setEnabled(false);
                                S40.setBackground(Color.yellow);
                                break;
                            }
                            case 41: {
                                S41.setEnabled(false);
                                S41.setBackground(Color.yellow);
                                break;
                            }
                            case 42: {
                                S42.setEnabled(false);
                                S42.setBackground(Color.yellow);
                                break;
                            }
                            case 43: {
                                S43.setEnabled(false);
                                S43.setBackground(Color.yellow);
                                break;
                            }
                            case 44: {
                                S44.setEnabled(false);
                                S44.setBackground(Color.yellow);
                                break;
                            }
                            case 45: {
                                S45.setEnabled(false);
                                S45.setBackground(Color.yellow);
                                break;
                            }
                            case 46: {
                                S46.setEnabled(false);
                                S46.setBackground(Color.yellow);
                                break;
                            }
                            case 47: {
                                S47.setEnabled(false);
                                S47.setBackground(Color.yellow);
                                break;
                            }
                            case 48: {
                                S48.setEnabled(false);
                                S48.setBackground(Color.yellow);
                                break;
                            }
                            case 49: {
                                S49.setEnabled(false);
                                S49.setBackground(Color.yellow);
                                break;
                            }
                            case 50: {
                                S50.setEnabled(false);
                                S50.setBackground(Color.yellow);
                                break;
                            }
                            case 51: {
                                S51.setEnabled(false);
                                S51.setBackground(Color.yellow);
                                break;
                            }
                            case 52: {
                                S52.setEnabled(false);
                                S52.setBackground(Color.yellow);
                                break;
                            }
                            case 53: {
                                S53.setEnabled(false);
                                S53.setBackground(Color.yellow);
                                break;
                            }
                            case 54: {
                                S54.setEnabled(false);
                                S54.setBackground(Color.yellow);
                                break;
                            }
                            case 55: {
                                S55.setEnabled(false);
                                S55.setBackground(Color.yellow);
                                break;
                            }
                            case 56: {
                                S56.setEnabled(false);
                                S56.setBackground(Color.yellow);
                                break;
                            }
                                                  
                        }
                    }
                } catch (ClassNotFoundException e1) {
                    // TODO Auto-generated catch block
                    e1.printStackTrace();
                } catch (SQLException e1) {
                    // TODO Auto-generated catch block
                    e1.printStackTrace();
                }
            	
            	
        	}
        	
        });
        button.setBounds(67, 55, 116, 25);
        classpanel.add(button);
        
        JButton button_1 = new JButton("First");
        button_1.setForeground(Color.DARK_GRAY);
        button_1.setFont(new Font("Times New Roman", Font.BOLD, 16));
        button_1.addActionListener(new ActionListener() {
        	public void actionPerformed(ActionEvent e) {
        		
        		sc.setText("First");
        		
        		S1.setVisible(false);S2.setVisible(false);S3.setVisible(false);S4.setVisible(false);S4.setVisible(false);S5.setVisible(false);S6.setVisible(false);
       		   S7.setVisible(false);S8.setVisible(false);S9.setVisible(false);S10.setVisible(false);S11.setVisible(false);S12.setVisible(false);S13.setVisible(false);
       		   S14.setVisible(false);S15.setVisible(false);S16.setVisible(false);S17.setVisible(false);S18.setVisible(false);S19.setVisible(false);S20.setVisible(false);
       		   S21.setVisible(false);S22.setVisible(false);S23.setVisible(false);S24.setVisible(false);S25.setVisible(false);S26.setVisible(false);S27.setVisible(false);
       		   S28.setVisible(false);S29.setVisible(false);S30.setVisible(false);S31.setVisible(false);S32.setVisible(false);S33.setVisible(false);S34.setVisible(false);
       		   S35.setVisible(false);S36.setVisible(false);S37.setVisible(false);S38.setVisible(false);S39.setVisible(false);S40.setVisible(false);S41.setVisible(false);
       		   S42.setVisible(false);S43.setVisible(false);S44.setVisible(false);S45.setVisible(false);S46.setVisible(false);S47.setVisible(false);S48.setVisible(false);
       		   S49.setVisible(false);S50.setVisible(false);S51.setVisible(false);S52.setVisible(false);S53.setVisible(false);S54.setVisible(false);S55.setVisible(false);
       		   S56.setVisible(false);
       		   
       		   S1.setBackground(Color.WHITE);S2.setBackground(Color.WHITE);S3.setBackground(Color.WHITE);S4.setBackground(Color.WHITE);S4.setBackground(Color.WHITE);S5.setBackground(Color.WHITE);S6.setBackground(Color.WHITE);
    		       S7.setBackground(Color.WHITE);S8.setBackground(Color.WHITE);S9.setBackground(Color.WHITE);S10.setBackground(Color.WHITE);S11.setBackground(Color.WHITE);S12.setBackground(Color.WHITE);S13.setBackground(Color.WHITE);
    		       S14.setBackground(Color.WHITE);S15.setBackground(Color.WHITE);S16.setBackground(Color.WHITE);S17.setBackground(Color.WHITE);S18.setBackground(Color.WHITE);S19.setBackground(Color.WHITE);S20.setBackground(Color.WHITE);
    		       S21.setBackground(Color.WHITE);S22.setBackground(Color.WHITE);S23.setBackground(Color.WHITE);S24.setBackground(Color.WHITE);S25.setBackground(Color.WHITE);S26.setBackground(Color.WHITE);S27.setBackground(Color.WHITE);
    		       S28.setBackground(Color.WHITE);S29.setBackground(Color.WHITE);S30.setBackground(Color.WHITE);S31.setBackground(Color.WHITE);S32.setBackground(Color.WHITE);S33.setBackground(Color.WHITE);S34.setBackground(Color.WHITE);
    		       S35.setBackground(Color.WHITE);S36.setBackground(Color.WHITE);S37.setBackground(Color.WHITE);S38.setBackground(Color.WHITE);S39.setBackground(Color.WHITE);S40.setBackground(Color.WHITE);S41.setBackground(Color.WHITE);
    		       S42.setBackground(Color.WHITE);S43.setBackground(Color.WHITE);S44.setBackground(Color.WHITE);S45.setBackground(Color.WHITE);S46.setBackground(Color.WHITE);S47.setBackground(Color.WHITE);S48.setBackground(Color.WHITE);
    		       S49.setBackground(Color.WHITE);S50.setBackground(Color.WHITE);S51.setBackground(Color.WHITE);S52.setBackground(Color.WHITE);S53.setBackground(Color.WHITE);S54.setBackground(Color.WHITE);S55.setBackground(Color.WHITE);
    		       S56.setBackground(Color.WHITE);
       		   
       		   S1.setEnabled(true);S2.setEnabled(true);S3.setEnabled(true);S4.setEnabled(true);S4.setEnabled(true);S5.setEnabled(true);S6.setEnabled(true);
     		   S7.setEnabled(true);S8.setEnabled(true);S9.setEnabled(true);S10.setEnabled(true);S11.setEnabled(true);S12.setEnabled(true);S13.setEnabled(true);
     		   S14.setEnabled(true);S15.setEnabled(true);S16.setEnabled(true);S17.setEnabled(true);S18.setEnabled(true);S19.setEnabled(true);S20.setEnabled(true);
     		   S21.setEnabled(true);S22.setEnabled(true);S23.setEnabled(true);S24.setEnabled(true);S25.setEnabled(true);S26.setEnabled(true);S27.setEnabled(true);
     		   S28.setEnabled(true);S29.setEnabled(true);S30.setEnabled(true);S31.setEnabled(true);S32.setEnabled(true);S33.setEnabled(true);S34.setEnabled(true);
     		   S35.setEnabled(true);S36.setEnabled(true);S37.setEnabled(true);S38.setEnabled(true);S39.setEnabled(true);S40.setEnabled(true);S41.setEnabled(true);
     		   S42.setEnabled(true);S43.setEnabled(true);S44.setEnabled(true);S45.setEnabled(true);S46.setEnabled(true);S47.setEnabled(true);S48.setEnabled(true);
     		   S49.setEnabled(true);S50.setEnabled(true);S51.setEnabled(true);S52.setEnabled(true);S53.setEnabled(true);S54.setEnabled(true);S55.setEnabled(true);
     		   S56.setEnabled(true);
       		   
       		   S1.setSelected(false);S2.setSelected(false);S3.setSelected(false);S4.setSelected(false);S4.setSelected(false);S5.setSelected(false);S6.setSelected(false);
       		   S7.setSelected(false);S8.setSelected(false);S9.setSelected(false);S10.setSelected(false);S11.setSelected(false);S12.setSelected(false);S13.setSelected(false);
       		   S14.setSelected(false);S15.setSelected(false);S16.setSelected(false);S17.setSelected(false);S18.setSelected(false);S19.setSelected(false);S20.setSelected(false);
     		   S21.setSelected(false);S22.setSelected(false);S23.setSelected(false);S24.setSelected(false);S25.setSelected(false);S26.setSelected(false);S27.setSelected(false);
       		   S28.setSelected(false);S29.setSelected(false);S30.setSelected(false);S31.setSelected(false);S32.setSelected(false);S33.setSelected(false);S34.setSelected(false);
       		   S35.setSelected(false);S36.setSelected(false);S37.setSelected(false);S38.setSelected(false);S39.setSelected(false);S40.setSelected(false);S41.setSelected(false);
       		   S42.setSelected(false);S43.setSelected(false);S44.setSelected(false);S45.setSelected(false);S46.setSelected(false);S47.setSelected(false);S48.setSelected(false);
       		   S49.setSelected(false);S50.setSelected(false);S51.setSelected(false);S52.setSelected(false);S53.setSelected(false);S54.setSelected(false);S55.setSelected(false);
       		   S56.setSelected(false);
     		   
       		try {
                Class.forName("com.mysql.jdbc.Driver");
                Connection con = DriverManager.getConnection("jdbc:mysql://localhost:3306/airline", "root", "root");
                Statement stmt = con.createStatement();
                String sql1 = "select * from flightdetails where fid='"+fid.getText()+"'";
                rs = stmt.executeQuery(sql1);
                while(rs.next())
                {
              	   int seats = Integer.parseInt(rs.getString("nofc"));
              	   if(seats==1)
              	   {
              		   S1.setVisible(true);
              	   }
              	   if(seats==2)
              	   {
              		   S1.setVisible(true);S2.setVisible(true);
              	   }
              	   if(seats==3)
              	   {
              		   S1.setVisible(true);S2.setVisible(true);S3.setVisible(true);
              	   }
              	   if(seats==4)
              	   {
              		   S1.setVisible(true);S2.setVisible(true);S3.setVisible(true);S4.setVisible(true);
              	   }
              	   if(seats==5)
              	   {
              		   S1.setVisible(true);S2.setVisible(true);S3.setVisible(true);S4.setVisible(true);S5.setVisible(true);
              	   }
              	   if(seats==6)
              	   {
              		   S1.setVisible(true);S2.setVisible(true);S3.setVisible(true);S4.setVisible(true);S4.setVisible(true);S5.setVisible(true);S6.setVisible(true);
              	   }
              	   if(seats==7)
              	   {
              		   S1.setVisible(true);S2.setVisible(true);S3.setVisible(true);S4.setVisible(true);S4.setVisible(true);S5.setVisible(true);S6.setVisible(true);
              		   S7.setVisible(true);
              	   }
              	   if(seats==8)
              	   {
              		   S1.setVisible(true);S2.setVisible(true);S3.setVisible(true);S4.setVisible(true);S4.setVisible(true);S5.setVisible(true);S6.setVisible(true);
              		   S7.setVisible(true);S8.setVisible(true);
              	   }
              	   if(seats==9)
              	   {
              		   S1.setVisible(true);S2.setVisible(true);S3.setVisible(true);S4.setVisible(true);S4.setVisible(true);S5.setVisible(true);S6.setVisible(true);
              		   S7.setVisible(true);S8.setVisible(true);S9.setVisible(true);
              	   }
              	   if(seats==10)
              	   {
              		   S1.setVisible(true);S2.setVisible(true);S3.setVisible(true);S4.setVisible(true);S4.setVisible(true);S5.setVisible(true);S6.setVisible(true);
              		   S7.setVisible(true);S8.setVisible(true);S9.setVisible(true);S10.setVisible(true);
              	   }
              	   if(seats==11)
              	   {
              		   S1.setVisible(true);S2.setVisible(true);S3.setVisible(true);S4.setVisible(true);S4.setVisible(true);S5.setVisible(true);S6.setVisible(true);
              		   S7.setVisible(true);S8.setVisible(true);S9.setVisible(true);S10.setVisible(true);S11.setVisible(true);
              	   }
              	   if(seats==12)
              	   {
              		   S1.setVisible(true);S2.setVisible(true);S3.setVisible(true);S4.setVisible(true);S4.setVisible(true);S5.setVisible(true);S6.setVisible(true);
              		   S7.setVisible(true);S8.setVisible(true);S9.setVisible(true);S10.setVisible(true);S11.setVisible(true);S12.setVisible(true);
              	   }
              	   if(seats==13)
              	   {
              		   S1.setVisible(true);S2.setVisible(true);S3.setVisible(true);S4.setVisible(true);S4.setVisible(true);S5.setVisible(true);S6.setVisible(true);
              		   S7.setVisible(true);S8.setVisible(true);S9.setVisible(true);S10.setVisible(true);S11.setVisible(true);S12.setVisible(true);S13.setVisible(true);
              	   }
              	   if(seats==14)
              	   {
              		   S1.setVisible(true);S2.setVisible(true);S3.setVisible(true);S4.setVisible(true);S4.setVisible(true);S5.setVisible(true);S6.setVisible(true);
              		   S7.setVisible(true);S8.setVisible(true);S9.setVisible(true);S10.setVisible(true);S11.setVisible(true);S12.setVisible(true);S13.setVisible(true);
              		   S14.setVisible(true);
              	   }
              	   if(seats==15)
              	   {
              		   S1.setVisible(true);S2.setVisible(true);S3.setVisible(true);S4.setVisible(true);S4.setVisible(true);S5.setVisible(true);S6.setVisible(true);
              		   S7.setVisible(true);S8.setVisible(true);S9.setVisible(true);S10.setVisible(true);S11.setVisible(true);S12.setVisible(true);S13.setVisible(true);
              		   S14.setVisible(true);S15.setVisible(true);
              	   }
              	   if(seats==16)
              	   {
              		   S1.setVisible(true);S2.setVisible(true);S3.setVisible(true);S4.setVisible(true);S4.setVisible(true);S5.setVisible(true);S6.setVisible(true);
              		   S7.setVisible(true);S8.setVisible(true);S9.setVisible(true);S10.setVisible(true);S11.setVisible(true);S12.setVisible(true);S13.setVisible(true);
              		   S14.setVisible(true);S15.setVisible(true);S16.setVisible(true);
              	   }
              	   if(seats==17)
              	   {
              		   S1.setVisible(true);S2.setVisible(true);S3.setVisible(true);S4.setVisible(true);S4.setVisible(true);S5.setVisible(true);S6.setVisible(true);
              		   S7.setVisible(true);S8.setVisible(true);S9.setVisible(true);S10.setVisible(true);S11.setVisible(true);S12.setVisible(true);S13.setVisible(true);
              		   S14.setVisible(true);S15.setVisible(true);S16.setVisible(true);S17.setVisible(true);
              	   }
              	   if(seats==18)
              	   {
              		   S1.setVisible(true);S2.setVisible(true);S3.setVisible(true);S4.setVisible(true);S4.setVisible(true);S5.setVisible(true);S6.setVisible(true);
              		   S7.setVisible(true);S8.setVisible(true);S9.setVisible(true);S10.setVisible(true);S11.setVisible(true);S12.setVisible(true);S13.setVisible(true);
              		   S14.setVisible(true);S15.setVisible(true);S16.setVisible(true);S17.setVisible(true);S18.setVisible(true);
              	   }
              	   if(seats==19)
              	   {
              		   S1.setVisible(true);S2.setVisible(true);S3.setVisible(true);S4.setVisible(true);S4.setVisible(true);S5.setVisible(true);S6.setVisible(true);
              		   S7.setVisible(true);S8.setVisible(true);S9.setVisible(true);S10.setVisible(true);S11.setVisible(true);S12.setVisible(true);S13.setVisible(true);
              		   S14.setVisible(true);S15.setVisible(true);S16.setVisible(true);S17.setVisible(true);S18.setVisible(true);S19.setVisible(true);
              	   }
              	   if(seats==20)
              	   {
              		   S1.setVisible(true);S2.setVisible(true);S3.setVisible(true);S4.setVisible(true);S4.setVisible(true);S5.setVisible(true);S6.setVisible(true);
              		   S7.setVisible(true);S8.setVisible(true);S9.setVisible(true);S10.setVisible(true);S11.setVisible(true);S12.setVisible(true);S13.setVisible(true);
              		   S14.setVisible(true);S15.setVisible(true);S16.setVisible(true);S17.setVisible(true);S18.setVisible(true);S19.setVisible(true);S20.setVisible(true);
              	   }
              	   if(seats==21)
              	   {
              		   S1.setVisible(true);S2.setVisible(true);S3.setVisible(true);S4.setVisible(true);S4.setVisible(true);S5.setVisible(true);S6.setVisible(true);
              		   S7.setVisible(true);S8.setVisible(true);S9.setVisible(true);S10.setVisible(true);S11.setVisible(true);S12.setVisible(true);S13.setVisible(true);
              		   S14.setVisible(true);S15.setVisible(true);S16.setVisible(true);S17.setVisible(true);S18.setVisible(true);S19.setVisible(true);S20.setVisible(true);
              		   S21.setVisible(true);
              	   }
              	   if(seats==22)
              	   {
              		   S1.setVisible(true);S2.setVisible(true);S3.setVisible(true);S4.setVisible(true);S4.setVisible(true);S5.setVisible(true);S6.setVisible(true);
              		   S7.setVisible(true);S8.setVisible(true);S9.setVisible(true);S10.setVisible(true);S11.setVisible(true);S12.setVisible(true);S13.setVisible(true);
              		   S14.setVisible(true);S15.setVisible(true);S16.setVisible(true);S17.setVisible(true);S18.setVisible(true);S19.setVisible(true);S20.setVisible(true);
              		   S21.setVisible(true);S22.setVisible(true);
              	   }
              	   if(seats==23)
              	   {
              		   S1.setVisible(true);S2.setVisible(true);S3.setVisible(true);S4.setVisible(true);S4.setVisible(true);S5.setVisible(true);S6.setVisible(true);
              		   S7.setVisible(true);S8.setVisible(true);S9.setVisible(true);S10.setVisible(true);S11.setVisible(true);S12.setVisible(true);S13.setVisible(true);
              		   S14.setVisible(true);S15.setVisible(true);S16.setVisible(true);S17.setVisible(true);S18.setVisible(true);S19.setVisible(true);S20.setVisible(true);
              		   S21.setVisible(true);S22.setVisible(true);S23.setVisible(true);
              	   }
              	   if(seats==24)
              	   {
              		   S1.setVisible(true);S2.setVisible(true);S3.setVisible(true);S4.setVisible(true);S4.setVisible(true);S5.setVisible(true);S6.setVisible(true);
              		   S7.setVisible(true);S8.setVisible(true);S9.setVisible(true);S10.setVisible(true);S11.setVisible(true);S12.setVisible(true);S13.setVisible(true);
              		   S14.setVisible(true);S15.setVisible(true);S16.setVisible(true);S17.setVisible(true);S18.setVisible(true);S19.setVisible(true);S20.setVisible(true);
              		   S21.setVisible(true);S22.setVisible(true);S23.setVisible(true);S24.setVisible(true);
              	   }
              	   if(seats==25)
              	   {
              		   S1.setVisible(true);S2.setVisible(true);S3.setVisible(true);S4.setVisible(true);S4.setVisible(true);S5.setVisible(true);S6.setVisible(true);
              		   S7.setVisible(true);S8.setVisible(true);S9.setVisible(true);S10.setVisible(true);S11.setVisible(true);S12.setVisible(true);S13.setVisible(true);
              		   S14.setVisible(true);S15.setVisible(true);S16.setVisible(true);S17.setVisible(true);S18.setVisible(true);S19.setVisible(true);S20.setVisible(true);
              		   S21.setVisible(true);S22.setVisible(true);S23.setVisible(true);S24.setVisible(true);S25.setVisible(true);
              	   }
              	   if(seats==26)
              	   {
              		   S1.setVisible(true);S2.setVisible(true);S3.setVisible(true);S4.setVisible(true);S4.setVisible(true);S5.setVisible(true);S6.setVisible(true);
              		   S7.setVisible(true);S8.setVisible(true);S9.setVisible(true);S10.setVisible(true);S11.setVisible(true);S12.setVisible(true);S13.setVisible(true);
              		   S14.setVisible(true);S15.setVisible(true);S16.setVisible(true);S17.setVisible(true);S18.setVisible(true);S19.setVisible(true);S20.setVisible(true);
              		   S21.setVisible(true);S22.setVisible(true);S23.setVisible(true);S24.setVisible(true);S25.setVisible(true);S26.setVisible(true);
              	   }
              	   if(seats==27)
              	   {
              		   S1.setVisible(true);S2.setVisible(true);S3.setVisible(true);S4.setVisible(true);S4.setVisible(true);S5.setVisible(true);S6.setVisible(true);
              		   S7.setVisible(true);S8.setVisible(true);S9.setVisible(true);S10.setVisible(true);S11.setVisible(true);S12.setVisible(true);S13.setVisible(true);
              		   S14.setVisible(true);S15.setVisible(true);S16.setVisible(true);S17.setVisible(true);S18.setVisible(true);S19.setVisible(true);S20.setVisible(true);
              		   S21.setVisible(true);S22.setVisible(true);S23.setVisible(true);S24.setVisible(true);S25.setVisible(true);S26.setVisible(true);S27.setVisible(true);
              	   }
              	   if(seats==28)
              	   {
              		   S1.setVisible(true);S2.setVisible(true);S3.setVisible(true);S4.setVisible(true);S4.setVisible(true);S5.setVisible(true);S6.setVisible(true);
              		   S7.setVisible(true);S8.setVisible(true);S9.setVisible(true);S10.setVisible(true);S11.setVisible(true);S12.setVisible(true);S13.setVisible(true);
              		   S14.setVisible(true);S15.setVisible(true);S16.setVisible(true);S17.setVisible(true);S18.setVisible(true);S19.setVisible(true);S20.setVisible(true);
              		   S21.setVisible(true);S22.setVisible(true);S23.setVisible(true);S24.setVisible(true);S25.setVisible(true);S26.setVisible(true);S27.setVisible(true);
              		   S28.setVisible(true);
              	   }
              	   if(seats==29)
              	   {
              		   S1.setVisible(true);S2.setVisible(true);S3.setVisible(true);S4.setVisible(true);S4.setVisible(true);S5.setVisible(true);S6.setVisible(true);
              		   S7.setVisible(true);S8.setVisible(true);S9.setVisible(true);S10.setVisible(true);S11.setVisible(true);S12.setVisible(true);S13.setVisible(true);
              		   S14.setVisible(true);S15.setVisible(true);S16.setVisible(true);S17.setVisible(true);S18.setVisible(true);S19.setVisible(true);S20.setVisible(true);
              		   S21.setVisible(true);S22.setVisible(true);S23.setVisible(true);S24.setVisible(true);S25.setVisible(true);S26.setVisible(true);S27.setVisible(true);
              		   S28.setVisible(true);S29.setVisible(true);
              	   }
              	   if(seats==30)
              	   {
              		   S1.setVisible(true);S2.setVisible(true);S3.setVisible(true);S4.setVisible(true);S4.setVisible(true);S5.setVisible(true);S6.setVisible(true);
              		   S7.setVisible(true);S8.setVisible(true);S9.setVisible(true);S10.setVisible(true);S11.setVisible(true);S12.setVisible(true);S13.setVisible(true);
              		   S14.setVisible(true);S15.setVisible(true);S16.setVisible(true);S17.setVisible(true);S18.setVisible(true);S19.setVisible(true);S20.setVisible(true);
              		   S21.setVisible(true);S22.setVisible(true);S23.setVisible(true);S24.setVisible(true);S25.setVisible(true);S26.setVisible(true);S27.setVisible(true);
              		   S28.setVisible(true);S29.setVisible(true);S30.setVisible(true);
              	   }
              	   if(seats==31)
              	   {
              		   S1.setVisible(true);S2.setVisible(true);S3.setVisible(true);S4.setVisible(true);S4.setVisible(true);S5.setVisible(true);S6.setVisible(true);
              		   S7.setVisible(true);S8.setVisible(true);S9.setVisible(true);S10.setVisible(true);S11.setVisible(true);S12.setVisible(true);S13.setVisible(true);
              		   S14.setVisible(true);S15.setVisible(true);S16.setVisible(true);S17.setVisible(true);S18.setVisible(true);S19.setVisible(true);S20.setVisible(true);
              		   S21.setVisible(true);S22.setVisible(true);S23.setVisible(true);S24.setVisible(true);S25.setVisible(true);S26.setVisible(true);S27.setVisible(true);
              		   S28.setVisible(true);S29.setVisible(true);S30.setVisible(true);S31.setVisible(true);
              	   }
              	   if(seats==32)
              	   {
              		   S1.setVisible(true);S2.setVisible(true);S3.setVisible(true);S4.setVisible(true);S4.setVisible(true);S5.setVisible(true);S6.setVisible(true);
              		   S7.setVisible(true);S8.setVisible(true);S9.setVisible(true);S10.setVisible(true);S11.setVisible(true);S12.setVisible(true);S13.setVisible(true);
              		   S14.setVisible(true);S15.setVisible(true);S16.setVisible(true);S17.setVisible(true);S18.setVisible(true);S19.setVisible(true);S20.setVisible(true);
              		   S21.setVisible(true);S22.setVisible(true);S23.setVisible(true);S24.setVisible(true);S25.setVisible(true);S26.setVisible(true);S27.setVisible(true);
              		   S28.setVisible(true);S29.setVisible(true);S30.setVisible(true);S31.setVisible(true);S32.setVisible(true);
              	   }
              	   if(seats==33)
              	   {
              		   S1.setVisible(true);S2.setVisible(true);S3.setVisible(true);S4.setVisible(true);S4.setVisible(true);S5.setVisible(true);S6.setVisible(true);
              		   S7.setVisible(true);S8.setVisible(true);S9.setVisible(true);S10.setVisible(true);S11.setVisible(true);S12.setVisible(true);S13.setVisible(true);
              		   S14.setVisible(true);S15.setVisible(true);S16.setVisible(true);S17.setVisible(true);S18.setVisible(true);S19.setVisible(true);S20.setVisible(true);
              		   S21.setVisible(true);S22.setVisible(true);S23.setVisible(true);S24.setVisible(true);S25.setVisible(true);S26.setVisible(true);S27.setVisible(true);
              		   S28.setVisible(true);S29.setVisible(true);S30.setVisible(true);S31.setVisible(true);S32.setVisible(true);S33.setVisible(true);
              	   }
              	   if(seats==34)
              	   {
              		   S1.setVisible(true);S2.setVisible(true);S3.setVisible(true);S4.setVisible(true);S4.setVisible(true);S5.setVisible(true);S6.setVisible(true);
              		   S7.setVisible(true);S8.setVisible(true);S9.setVisible(true);S10.setVisible(true);S11.setVisible(true);S12.setVisible(true);S13.setVisible(true);
              		   S14.setVisible(true);S15.setVisible(true);S16.setVisible(true);S17.setVisible(true);S18.setVisible(true);S19.setVisible(true);S20.setVisible(true);
              		   S21.setVisible(true);S22.setVisible(true);S23.setVisible(true);S24.setVisible(true);S25.setVisible(true);S26.setVisible(true);S27.setVisible(true);
              		   S28.setVisible(true);S29.setVisible(true);S30.setVisible(true);S31.setVisible(true);S32.setVisible(true);S33.setVisible(true);S34.setVisible(true);
              	   }
              	   if(seats==35)
              	   {
              		   S1.setVisible(true);S2.setVisible(true);S3.setVisible(true);S4.setVisible(true);S4.setVisible(true);S5.setVisible(true);S6.setVisible(true);
              		   S7.setVisible(true);S8.setVisible(true);S9.setVisible(true);S10.setVisible(true);S11.setVisible(true);S12.setVisible(true);S13.setVisible(true);
              		   S14.setVisible(true);S15.setVisible(true);S16.setVisible(true);S17.setVisible(true);S18.setVisible(true);S19.setVisible(true);S20.setVisible(true);
              		   S21.setVisible(true);S22.setVisible(true);S23.setVisible(true);S24.setVisible(true);S25.setVisible(true);S26.setVisible(true);S27.setVisible(true);
              		   S28.setVisible(true);S29.setVisible(true);S30.setVisible(true);S31.setVisible(true);S32.setVisible(true);S33.setVisible(true);S34.setVisible(true);
              		   S35.setVisible(true);
              	   }
              	   if(seats==36)
              	   {
              		   S1.setVisible(true);S2.setVisible(true);S3.setVisible(true);S4.setVisible(true);S4.setVisible(true);S5.setVisible(true);S6.setVisible(true);
              		   S7.setVisible(true);S8.setVisible(true);S9.setVisible(true);S10.setVisible(true);S11.setVisible(true);S12.setVisible(true);S13.setVisible(true);
              		   S14.setVisible(true);S15.setVisible(true);S16.setVisible(true);S17.setVisible(true);S18.setVisible(true);S19.setVisible(true);S20.setVisible(true);
              		   S21.setVisible(true);S22.setVisible(true);S23.setVisible(true);S24.setVisible(true);S25.setVisible(true);S26.setVisible(true);S27.setVisible(true);
              		   S28.setVisible(true);S29.setVisible(true);S30.setVisible(true);S31.setVisible(true);S32.setVisible(true);S33.setVisible(true);S34.setVisible(true);
              		   S35.setVisible(true);S36.setVisible(true);
              	   }
              	   if(seats==37)
              	   {
              		   S1.setVisible(true);S2.setVisible(true);S3.setVisible(true);S4.setVisible(true);S4.setVisible(true);S5.setVisible(true);S6.setVisible(true);
              		   S7.setVisible(true);S8.setVisible(true);S9.setVisible(true);S10.setVisible(true);S11.setVisible(true);S12.setVisible(true);S13.setVisible(true);
              		   S14.setVisible(true);S15.setVisible(true);S16.setVisible(true);S17.setVisible(true);S18.setVisible(true);S19.setVisible(true);S20.setVisible(true);
              		   S21.setVisible(true);S22.setVisible(true);S23.setVisible(true);S24.setVisible(true);S25.setVisible(true);S26.setVisible(true);S27.setVisible(true);
              		   S28.setVisible(true);S29.setVisible(true);S30.setVisible(true);S31.setVisible(true);S32.setVisible(true);S33.setVisible(true);S34.setVisible(true);
              		   S35.setVisible(true);S36.setVisible(true);S37.setVisible(true);
              	   }
              	   if(seats==38)
              	   {
              		   S1.setVisible(true);S2.setVisible(true);S3.setVisible(true);S4.setVisible(true);S4.setVisible(true);S5.setVisible(true);S6.setVisible(true);
              		   S7.setVisible(true);S8.setVisible(true);S9.setVisible(true);S10.setVisible(true);S11.setVisible(true);S12.setVisible(true);S13.setVisible(true);
              		   S14.setVisible(true);S15.setVisible(true);S16.setVisible(true);S17.setVisible(true);S18.setVisible(true);S19.setVisible(true);S20.setVisible(true);
              		   S21.setVisible(true);S22.setVisible(true);S23.setVisible(true);S24.setVisible(true);S25.setVisible(true);S26.setVisible(true);S27.setVisible(true);
              		   S28.setVisible(true);S29.setVisible(true);S30.setVisible(true);S31.setVisible(true);S32.setVisible(true);S33.setVisible(true);S34.setVisible(true);
              		   S35.setVisible(true);S36.setVisible(true);S37.setVisible(true);S38.setVisible(true);
              	   }
              	   if(seats==39)
              	   {
              		   S1.setVisible(true);S2.setVisible(true);S3.setVisible(true);S4.setVisible(true);S4.setVisible(true);S5.setVisible(true);S6.setVisible(true);
              		   S7.setVisible(true);S8.setVisible(true);S9.setVisible(true);S10.setVisible(true);S11.setVisible(true);S12.setVisible(true);S13.setVisible(true);
              		   S14.setVisible(true);S15.setVisible(true);S16.setVisible(true);S17.setVisible(true);S18.setVisible(true);S19.setVisible(true);S20.setVisible(true);
              		   S21.setVisible(true);S22.setVisible(true);S23.setVisible(true);S24.setVisible(true);S25.setVisible(true);S26.setVisible(true);S27.setVisible(true);
              		   S28.setVisible(true);S29.setVisible(true);S30.setVisible(true);S31.setVisible(true);S32.setVisible(true);S33.setVisible(true);S34.setVisible(true);
              		   S35.setVisible(true);S36.setVisible(true);S37.setVisible(true);S38.setVisible(true);S39.setVisible(true);
              	   }
              	   if(seats==40)
              	   {
              		   S1.setVisible(true);S2.setVisible(true);S3.setVisible(true);S4.setVisible(true);S4.setVisible(true);S5.setVisible(true);S6.setVisible(true);
              		   S7.setVisible(true);S8.setVisible(true);S9.setVisible(true);S10.setVisible(true);S11.setVisible(true);S12.setVisible(true);S13.setVisible(true);
              		   S14.setVisible(true);S15.setVisible(true);S16.setVisible(true);S17.setVisible(true);S18.setVisible(true);S19.setVisible(true);S20.setVisible(true);
              		   S21.setVisible(true);S22.setVisible(true);S23.setVisible(true);S24.setVisible(true);S25.setVisible(true);S26.setVisible(true);S27.setVisible(true);
              		   S28.setVisible(true);S29.setVisible(true);S30.setVisible(true);S31.setVisible(true);S32.setVisible(true);S33.setVisible(true);S34.setVisible(true);
              		   S35.setVisible(true);S36.setVisible(true);S37.setVisible(true);S38.setVisible(true);S39.setVisible(true);S40.setVisible(true);
              	   }
              	   if(seats==41)
              	   {
              		   S1.setVisible(true);S2.setVisible(true);S3.setVisible(true);S4.setVisible(true);S4.setVisible(true);S5.setVisible(true);S6.setVisible(true);
              		   S7.setVisible(true);S8.setVisible(true);S9.setVisible(true);S10.setVisible(true);S11.setVisible(true);S12.setVisible(true);S13.setVisible(true);
              		   S14.setVisible(true);S15.setVisible(true);S16.setVisible(true);S17.setVisible(true);S18.setVisible(true);S19.setVisible(true);S20.setVisible(true);
              		   S21.setVisible(true);S22.setVisible(true);S23.setVisible(true);S24.setVisible(true);S25.setVisible(true);S26.setVisible(true);S27.setVisible(true);
              		   S28.setVisible(true);S29.setVisible(true);S30.setVisible(true);S31.setVisible(true);S32.setVisible(true);S33.setVisible(true);S34.setVisible(true);
              		   S35.setVisible(true);S36.setVisible(true);S37.setVisible(true);S38.setVisible(true);S39.setVisible(true);S40.setVisible(true);S41.setVisible(true);
              	   }
              	   if(seats==42)
              	   {
              		   S1.setVisible(true);S2.setVisible(true);S3.setVisible(true);S4.setVisible(true);S4.setVisible(true);S5.setVisible(true);S6.setVisible(true);
              		   S7.setVisible(true);S8.setVisible(true);S9.setVisible(true);S10.setVisible(true);S11.setVisible(true);S12.setVisible(true);S13.setVisible(true);
              		   S14.setVisible(true);S15.setVisible(true);S16.setVisible(true);S17.setVisible(true);S18.setVisible(true);S19.setVisible(true);S20.setVisible(true);
              		   S21.setVisible(true);S22.setVisible(true);S23.setVisible(true);S24.setVisible(true);S25.setVisible(true);S26.setVisible(true);S27.setVisible(true);
              		   S28.setVisible(true);S29.setVisible(true);S30.setVisible(true);S31.setVisible(true);S32.setVisible(true);S33.setVisible(true);S34.setVisible(true);
              		   S35.setVisible(true);S36.setVisible(true);S37.setVisible(true);S38.setVisible(true);S39.setVisible(true);S40.setVisible(true);S41.setVisible(true);
              		   S42.setVisible(true);
              	   }
              	   if(seats==43)
              	   {
              		   S1.setVisible(true);S2.setVisible(true);S3.setVisible(true);S4.setVisible(true);S4.setVisible(true);S5.setVisible(true);S6.setVisible(true);
              		   S7.setVisible(true);S8.setVisible(true);S9.setVisible(true);S10.setVisible(true);S11.setVisible(true);S12.setVisible(true);S13.setVisible(true);
              		   S14.setVisible(true);S15.setVisible(true);S16.setVisible(true);S17.setVisible(true);S18.setVisible(true);S19.setVisible(true);S20.setVisible(true);
              		   S21.setVisible(true);S22.setVisible(true);S23.setVisible(true);S24.setVisible(true);S25.setVisible(true);S26.setVisible(true);S27.setVisible(true);
              		   S28.setVisible(true);S29.setVisible(true);S30.setVisible(true);S31.setVisible(true);S32.setVisible(true);S33.setVisible(true);S34.setVisible(true);
              		   S35.setVisible(true);S36.setVisible(true);S37.setVisible(true);S38.setVisible(true);S39.setVisible(true);S40.setVisible(true);S41.setVisible(true);
              		   S42.setVisible(true);S43.setVisible(true);
              	   }
              	   if(seats==44)
              	   {
              		   S1.setVisible(true);S2.setVisible(true);S3.setVisible(true);S4.setVisible(true);S4.setVisible(true);S5.setVisible(true);S6.setVisible(true);
              		   S7.setVisible(true);S8.setVisible(true);S9.setVisible(true);S10.setVisible(true);S11.setVisible(true);S12.setVisible(true);S13.setVisible(true);
              		   S14.setVisible(true);S15.setVisible(true);S16.setVisible(true);S17.setVisible(true);S18.setVisible(true);S19.setVisible(true);S20.setVisible(true);
              		   S21.setVisible(true);S22.setVisible(true);S23.setVisible(true);S24.setVisible(true);S25.setVisible(true);S26.setVisible(true);S27.setVisible(true);
              		   S28.setVisible(true);S29.setVisible(true);S30.setVisible(true);S31.setVisible(true);S32.setVisible(true);S33.setVisible(true);S34.setVisible(true);
              		   S35.setVisible(true);S36.setVisible(true);S37.setVisible(true);S38.setVisible(true);S39.setVisible(true);S40.setVisible(true);S41.setVisible(true);
              		   S42.setVisible(true);S43.setVisible(true);S44.setVisible(true);
              	   }
              	   
              	   if(seats==45)
              	   {
              		   S1.setVisible(true);S2.setVisible(true);S3.setVisible(true);S4.setVisible(true);S4.setVisible(true);S5.setVisible(true);S6.setVisible(true);
              		   S7.setVisible(true);S8.setVisible(true);S9.setVisible(true);S10.setVisible(true);S11.setVisible(true);S12.setVisible(true);S13.setVisible(true);
              		   S14.setVisible(true);S15.setVisible(true);S16.setVisible(true);S17.setVisible(true);S18.setVisible(true);S19.setVisible(true);S20.setVisible(true);
              		   S21.setVisible(true);S22.setVisible(true);S23.setVisible(true);S24.setVisible(true);S25.setVisible(true);S26.setVisible(true);S27.setVisible(true);
              		   S28.setVisible(true);S29.setVisible(true);S30.setVisible(true);S31.setVisible(true);S32.setVisible(true);S33.setVisible(true);S34.setVisible(true);
              		   S35.setVisible(true);S36.setVisible(true);S37.setVisible(true);S38.setVisible(true);S39.setVisible(true);S40.setVisible(true);S41.setVisible(true);
              		   S42.setVisible(true);S43.setVisible(true);S44.setVisible(true);S45.setVisible(true);
              	   }
              	   if(seats==46)
              	   {
              		   S1.setVisible(true);S2.setVisible(true);S3.setVisible(true);S4.setVisible(true);S4.setVisible(true);S5.setVisible(true);S6.setVisible(true);
              		   S7.setVisible(true);S8.setVisible(true);S9.setVisible(true);S10.setVisible(true);S11.setVisible(true);S12.setVisible(true);S13.setVisible(true);
              		   S14.setVisible(true);S15.setVisible(true);S16.setVisible(true);S17.setVisible(true);S18.setVisible(true);S19.setVisible(true);S20.setVisible(true);
              		   S21.setVisible(true);S22.setVisible(true);S23.setVisible(true);S24.setVisible(true);S25.setVisible(true);S26.setVisible(true);S27.setVisible(true);
              		   S28.setVisible(true);S29.setVisible(true);S30.setVisible(true);S31.setVisible(true);S32.setVisible(true);S33.setVisible(true);S34.setVisible(true);
              		   S35.setVisible(true);S36.setVisible(true);S37.setVisible(true);S38.setVisible(true);S39.setVisible(true);S40.setVisible(true);S41.setVisible(true);
              		   S42.setVisible(true);S43.setVisible(true);S44.setVisible(true);S45.setVisible(true);S46.setVisible(true);
              	   }
              	   if(seats==47)
              	   {
              		   S1.setVisible(true);S2.setVisible(true);S3.setVisible(true);S4.setVisible(true);S4.setVisible(true);S5.setVisible(true);S6.setVisible(true);
              		   S7.setVisible(true);S8.setVisible(true);S9.setVisible(true);S10.setVisible(true);S11.setVisible(true);S12.setVisible(true);S13.setVisible(true);
              		   S14.setVisible(true);S15.setVisible(true);S16.setVisible(true);S17.setVisible(true);S18.setVisible(true);S19.setVisible(true);S20.setVisible(true);
              		   S28.setVisible(true);S29.setVisible(true);S30.setVisible(true);S31.setVisible(true);S32.setVisible(true);S33.setVisible(true);S34.setVisible(true);
              		   S35.setVisible(true);S36.setVisible(true);S37.setVisible(true);S38.setVisible(true);S39.setVisible(true);S40.setVisible(true);S41.setVisible(true);
              		   S42.setVisible(true);S43.setVisible(true);S44.setVisible(true);S45.setVisible(true);S46.setVisible(true);S47.setVisible(true);
              	   }
              	   if(seats==48)
              	   {
              		   S1.setVisible(true);S2.setVisible(true);S3.setVisible(true);S4.setVisible(true);S4.setVisible(true);S5.setVisible(true);S6.setVisible(true);
              		   S7.setVisible(true);S8.setVisible(true);S9.setVisible(true);S10.setVisible(true);S11.setVisible(true);S12.setVisible(true);S13.setVisible(true);
              		   S14.setVisible(true);S15.setVisible(true);S16.setVisible(true);S17.setVisible(true);S18.setVisible(true);S19.setVisible(true);S20.setVisible(true);
              		   S21.setVisible(true);S22.setVisible(true);S23.setVisible(true);S24.setVisible(true);S25.setVisible(true);S26.setVisible(true);S27.setVisible(true);
              		   S28.setVisible(true);S29.setVisible(true);S30.setVisible(true);S31.setVisible(true);S32.setVisible(true);S33.setVisible(true);S34.setVisible(true);
              		   S35.setVisible(true);S36.setVisible(true);S37.setVisible(true);S38.setVisible(true);S39.setVisible(true);S40.setVisible(true);S41.setVisible(true);
              		   S42.setVisible(true);S43.setVisible(true);S44.setVisible(true);S45.setVisible(true);S46.setVisible(true);S47.setVisible(true);S48.setVisible(true);
              	   }
              	   if(seats==49)
              	   {
              		   S1.setVisible(true);S2.setVisible(true);S3.setVisible(true);S4.setVisible(true);S4.setVisible(true);S5.setVisible(true);S6.setVisible(true);
              		   S7.setVisible(true);S8.setVisible(true);S9.setVisible(true);S10.setVisible(true);S11.setVisible(true);S12.setVisible(true);S13.setVisible(true);
              		   S14.setVisible(true);S15.setVisible(true);S16.setVisible(true);S17.setVisible(true);S18.setVisible(true);S19.setVisible(true);S20.setVisible(true);
              		   S21.setVisible(true);S22.setVisible(true);S23.setVisible(true);S24.setVisible(true);S25.setVisible(true);S26.setVisible(true);S27.setVisible(true);
              		   S28.setVisible(true);S29.setVisible(true);S30.setVisible(true);S31.setVisible(true);S32.setVisible(true);S33.setVisible(true);S34.setVisible(true);
              		   S35.setVisible(true);S36.setVisible(true);S37.setVisible(true);S38.setVisible(true);S39.setVisible(true);S40.setVisible(true);S41.setVisible(true);
              		   S42.setVisible(true);S43.setVisible(true);S44.setVisible(true);S45.setVisible(true);S46.setVisible(true);S47.setVisible(true);S48.setVisible(true);
              		   S49.setVisible(true);
              	   }
              	   if(seats==50)
              	   {
              		   S1.setVisible(true);S2.setVisible(true);S3.setVisible(true);S4.setVisible(true);S4.setVisible(true);S5.setVisible(true);S6.setVisible(true);
              		   S7.setVisible(true);S8.setVisible(true);S9.setVisible(true);S10.setVisible(true);S11.setVisible(true);S12.setVisible(true);S13.setVisible(true);
              		   S14.setVisible(true);S15.setVisible(true);S16.setVisible(true);S17.setVisible(true);S18.setVisible(true);S19.setVisible(true);S20.setVisible(true);
              		   S21.setVisible(true);S22.setVisible(true);S23.setVisible(true);S24.setVisible(true);S25.setVisible(true);S26.setVisible(true);S27.setVisible(true);
              		   S28.setVisible(true);S29.setVisible(true);S30.setVisible(true);S31.setVisible(true);S32.setVisible(true);S33.setVisible(true);S34.setVisible(true);
              		   S35.setVisible(true);S36.setVisible(true);S37.setVisible(true);S38.setVisible(true);S39.setVisible(true);S40.setVisible(true);S41.setVisible(true);
              		   S42.setVisible(true);S43.setVisible(true);S44.setVisible(true);S45.setVisible(true);S46.setVisible(true);S47.setVisible(true);S48.setVisible(true);
              		   S49.setVisible(true);S50.setVisible(true);
              	   }
              	   if(seats==51)
              	   {
              		   S1.setVisible(true);S2.setVisible(true);S3.setVisible(true);S4.setVisible(true);S4.setVisible(true);S5.setVisible(true);S6.setVisible(true);
              		   S7.setVisible(true);S8.setVisible(true);S9.setVisible(true);S10.setVisible(true);S11.setVisible(true);S12.setVisible(true);S13.setVisible(true);
              		   S14.setVisible(true);S15.setVisible(true);S16.setVisible(true);S17.setVisible(true);S18.setVisible(true);S19.setVisible(true);S20.setVisible(true);
              		   S21.setVisible(true);S22.setVisible(true);S23.setVisible(true);S24.setVisible(true);S25.setVisible(true);S26.setVisible(true);S27.setVisible(true);
              		   S28.setVisible(true);S29.setVisible(true);S30.setVisible(true);S31.setVisible(true);S32.setVisible(true);S33.setVisible(true);S34.setVisible(true);
              		   S35.setVisible(true);S36.setVisible(true);S37.setVisible(true);S38.setVisible(true);S39.setVisible(true);S40.setVisible(true);S41.setVisible(true);
              		   S42.setVisible(true);S43.setVisible(true);S44.setVisible(true);S45.setVisible(true);S46.setVisible(true);S47.setVisible(true);S48.setVisible(true);
              		   S49.setVisible(true);S50.setVisible(true);S51.setVisible(true);
              	   }
              	   if(seats==52)
              	   {
              		   S1.setVisible(true);S2.setVisible(true);S3.setVisible(true);S4.setVisible(true);S4.setVisible(true);S5.setVisible(true);S6.setVisible(true);
              		   S7.setVisible(true);S8.setVisible(true);S9.setVisible(true);S10.setVisible(true);S11.setVisible(true);S12.setVisible(true);S13.setVisible(true);
              		   S14.setVisible(true);S15.setVisible(true);S16.setVisible(true);S17.setVisible(true);S18.setVisible(true);S19.setVisible(true);S20.setVisible(true);
              		   S21.setVisible(true);S22.setVisible(true);S23.setVisible(true);S24.setVisible(true);S25.setVisible(true);S26.setVisible(true);S27.setVisible(true);
              		   S28.setVisible(true);S29.setVisible(true);S30.setVisible(true);S31.setVisible(true);S32.setVisible(true);S33.setVisible(true);S34.setVisible(true);
              		   S35.setVisible(true);S36.setVisible(true);S37.setVisible(true);S38.setVisible(true);S39.setVisible(true);S40.setVisible(true);S41.setVisible(true);
              		   S42.setVisible(true);S43.setVisible(true);S44.setVisible(true);S45.setVisible(true);S46.setVisible(true);S47.setVisible(true);S48.setVisible(true);
              		   S49.setVisible(true);S50.setVisible(true);S51.setVisible(true);S52.setVisible(true);
              	   }
              	   if(seats==53)
              	   {
              		   S1.setVisible(true);S2.setVisible(true);S3.setVisible(true);S4.setVisible(true);S4.setVisible(true);S5.setVisible(true);S6.setVisible(true);
              		   S7.setVisible(true);S8.setVisible(true);S9.setVisible(true);S10.setVisible(true);S11.setVisible(true);S12.setVisible(true);S13.setVisible(true);
              		   S14.setVisible(true);S15.setVisible(true);S16.setVisible(true);S17.setVisible(true);S18.setVisible(true);S19.setVisible(true);S20.setVisible(true);
              		   S21.setVisible(true);S22.setVisible(true);S23.setVisible(true);S24.setVisible(true);S25.setVisible(true);S26.setVisible(true);S27.setVisible(true);
              		   S28.setVisible(true);S29.setVisible(true);S30.setVisible(true);S31.setVisible(true);S32.setVisible(true);S33.setVisible(true);S34.setVisible(true);
              		   S35.setVisible(true);S36.setVisible(true);S37.setVisible(true);S38.setVisible(true);S39.setVisible(true);S40.setVisible(true);S41.setVisible(true);
              		   S42.setVisible(true);S43.setVisible(true);S44.setVisible(true);S45.setVisible(true);S46.setVisible(true);S47.setVisible(true);S48.setVisible(true);
              		   S49.setVisible(true);S50.setVisible(true);S51.setVisible(true);S52.setVisible(true);S53.setVisible(true);
              	   }
              	   if(seats==54)
              	   {
              		   S1.setVisible(true);S2.setVisible(true);S3.setVisible(true);S4.setVisible(true);S4.setVisible(true);S5.setVisible(true);S6.setVisible(true);
              		   S7.setVisible(true);S8.setVisible(true);S9.setVisible(true);S10.setVisible(true);S11.setVisible(true);S12.setVisible(true);S13.setVisible(true);
              		   S14.setVisible(true);S15.setVisible(true);S16.setVisible(true);S17.setVisible(true);S18.setVisible(true);S19.setVisible(true);S20.setVisible(true);
              		   S21.setVisible(true);S22.setVisible(true);S23.setVisible(true);S24.setVisible(true);S25.setVisible(true);S26.setVisible(true);S27.setVisible(true);
              		   S28.setVisible(true);S29.setVisible(true);S30.setVisible(true);S31.setVisible(true);S32.setVisible(true);S33.setVisible(true);S34.setVisible(true);
              		   S35.setVisible(true);S36.setVisible(true);S37.setVisible(true);S38.setVisible(true);S39.setVisible(true);S40.setVisible(true);S41.setVisible(true);
              		   S42.setVisible(true);S43.setVisible(true);S44.setVisible(true);S45.setVisible(true);S46.setVisible(true);S47.setVisible(true);S48.setVisible(true);
              		   S49.setVisible(true);S50.setVisible(true);S51.setVisible(true);S52.setVisible(true);S53.setVisible(true);S54.setVisible(true);
              	   }
              	   if(seats==55)
              	   {
              		   S1.setVisible(true);S2.setVisible(true);S3.setVisible(true);S4.setVisible(true);S4.setVisible(true);S5.setVisible(true);S6.setVisible(true);
              		   S7.setVisible(true);S8.setVisible(true);S9.setVisible(true);S10.setVisible(true);S11.setVisible(true);S12.setVisible(true);S13.setVisible(true);
              		   S14.setVisible(true);S15.setVisible(true);S16.setVisible(true);S17.setVisible(true);S18.setVisible(true);S19.setVisible(true);S20.setVisible(true);
              		   S21.setVisible(true);S22.setVisible(true);S23.setVisible(true);S24.setVisible(true);S25.setVisible(true);S26.setVisible(true);S27.setVisible(true);
              		   S28.setVisible(true);S29.setVisible(true);S30.setVisible(true);S31.setVisible(true);S32.setVisible(true);S33.setVisible(true);S34.setVisible(true);
              		   S35.setVisible(true);S36.setVisible(true);S37.setVisible(true);S38.setVisible(true);S39.setVisible(true);S40.setVisible(true);S41.setVisible(true);
              		   S42.setVisible(true);S43.setVisible(true);S44.setVisible(true);S45.setVisible(true);S46.setVisible(true);S47.setVisible(true);S48.setVisible(true);
              		   S49.setVisible(true);S50.setVisible(true);S51.setVisible(true);S52.setVisible(true);S53.setVisible(true);S54.setVisible(true);S55.setVisible(true);
              	   }
              	   if(seats==56)
              	   {
              		   S1.setVisible(true);S2.setVisible(true);S3.setVisible(true);S4.setVisible(true);S4.setVisible(true);S5.setVisible(true);S6.setVisible(true);
              		   S7.setVisible(true);S8.setVisible(true);S9.setVisible(true);S10.setVisible(true);S11.setVisible(true);S12.setVisible(true);S13.setVisible(true);
              		   S14.setVisible(true);S15.setVisible(true);S16.setVisible(true);S17.setVisible(true);S18.setVisible(true);S19.setVisible(true);S20.setVisible(true);
              		   S21.setVisible(true);S22.setVisible(true);S23.setVisible(true);S24.setVisible(true);S25.setVisible(true);S26.setVisible(true);S27.setVisible(true);
              		   S28.setVisible(true);S29.setVisible(true);S30.setVisible(true);S31.setVisible(true);S32.setVisible(true);S33.setVisible(true);S34.setVisible(true);
              		   S35.setVisible(true);S36.setVisible(true);S37.setVisible(true);S38.setVisible(true);S39.setVisible(true);S40.setVisible(true);S41.setVisible(true);
              		   S42.setVisible(true);S43.setVisible(true);S44.setVisible(true);S45.setVisible(true);S46.setVisible(true);S47.setVisible(true);S48.setVisible(true);
              		   S49.setVisible(true);S50.setVisible(true);S51.setVisible(true);S52.setVisible(true);S53.setVisible(true);S54.setVisible(true);S55.setVisible(true);
              		   S56.setVisible(true);
              	   }
              	   
              	   }  
              	   
                
               
      			}
        		catch (ClassNotFoundException e1) {
                  // TODO Auto-generated catch block
                  e1.printStackTrace();
              } catch (SQLException e1) {
                  // TODO Auto-generated catch block
                  e1.printStackTrace();
              }
        		
        		
            	try {
                    Class.forName("com.mysql.jdbc.Driver");
                    Connection con = DriverManager.getConnection("jdbc:mysql://localhost:3306/airline", "root", "root");
                    Statement stmt = con.createStatement();
                    String sql1 = "select * from reserve where class='"+sc.getText()+"' AND fid='"+fid.getText()+"'and doj='"+doj.getText()+"'";							//Refine the search by adding flightID and coach type
                    rs = stmt.executeQuery(sql1);
                    while (rs.next()) {

                        int check = Integer.parseInt(rs.getString("seatid"));
                        switch (check) {
                            case 1: {
                                S1.setEnabled(false);
                                S1.setBackground(Color.yellow);
                                break;
                            }
                            case 2: {
                                S2.setEnabled(false);
                                S2.setBackground(Color.yellow);
                                break;
                            }
                            case 3: {
                                S3.setEnabled(false);
                                S3.setBackground(Color.yellow);
                                break;
                            }
                            case 4: {
                                S4.setEnabled(false);
                                S4.setBackground(Color.yellow);
                                break;
                            }
                            case 5: {
                                S5.setEnabled(false);
                                S5.setBackground(Color.yellow);
                                break;
                            }
                            case 6: {
                                S6.setEnabled(false);
                                S6.setBackground(Color.yellow);
                                break;
                            }
                            case 7: {
                                S7.setEnabled(false);
                                S7.setBackground(Color.yellow);
                                break;
                            }
                            case 8: {
                                S8.setEnabled(false);
                                S8.setBackground(Color.yellow);
                                break;
                            }
                            case 9: {
                                S9.setEnabled(false);
                                S9.setBackground(Color.yellow);
                                break;
                            }
                            case 10:{
                                S10.setEnabled(false);
                                S10.setBackground(Color.yellow);
                                break;
                            }
                            case 11: {
                                S11.setEnabled(false);
                                S11.setBackground(Color.yellow);
                                break;
                            }
                            case 12: {
                                S12.setEnabled(false);
                                S12.setBackground(Color.yellow);
                                break;
                            }
                            case 13: {
                                S13.setEnabled(false);
                                S13.setBackground(Color.yellow);
                                break;
                            }
                            case 14: {
                                S14.setEnabled(false);
                                S14.setBackground(Color.yellow);
                                break;
                            }
                            case 15: {
                                S15.setEnabled(false);
                                S15.setBackground(Color.yellow);
                                break;
                            }
                            case 16: {
                                S16.setEnabled(false);
                                S16.setBackground(Color.yellow);
                                break;
                            }
                            case 17: {
                                S17.setEnabled(false);
                                S17.setBackground(Color.yellow);
                                break;
                            }
                            case 18: {
                                S18.setEnabled(false);
                                S18.setBackground(Color.yellow);
                                break;
                            }
                            case 19: {
                                S19.setEnabled(false);
                                S19.setBackground(Color.yellow);
                                break;
                            }
                            case 20: {
                                S20.setEnabled(false);
                                S20.setBackground(Color.yellow);
                                break;
                            }
                            case 21: {
                                S21.setEnabled(false);
                                S21.setBackground(Color.yellow);
                                break;
                            }
                            case 22: {
                                S22.setEnabled(false);
                                S22.setBackground(Color.yellow);
                                break;
                            }
                            case 23: {
                                S23.setEnabled(false);
                                S23.setBackground(Color.yellow);
                                break;
                            }
                            case 24: {
                                S24.setEnabled(false);
                                S24.setBackground(Color.yellow);
                                break;
                            }
                            case 25: {
                                S25.setEnabled(false);
                                S25.setBackground(Color.yellow);
                                break;
                            }
                            case 26: {
                                S26.setEnabled(false);
                                S26.setBackground(Color.yellow);
                                break;
                            }
                            case 27: {
                                S27.setEnabled(false);
                                S27.setBackground(Color.yellow);
                                break;
                            }
                            case 28: {
                                S28.setEnabled(false);
                                S28.setBackground(Color.yellow);
                                break;
                            }
                            case 29: {
                                S29.setEnabled(false);
                                S29.setBackground(Color.yellow);
                                break;
                            }
                            case 30: {
                                S30.setEnabled(false);
                                S30.setBackground(Color.yellow);
                                break;
                            }
                            case 31: {
                                S31.setEnabled(false);
                                S31.setBackground(Color.yellow);
                                break;
                            }
                            case 32: {
                                S32.setEnabled(false);
                                S32.setBackground(Color.yellow);
                                break;
                            }
                            case 33: {
                                S33.setEnabled(false);
                                S33.setBackground(Color.yellow);
                                break;
                            }
                            case 34: {
                                S34.setEnabled(false);
                                S34.setBackground(Color.yellow);
                                break;
                            }
                            case 35: {
                                S35.setEnabled(false);
                                S35.setBackground(Color.yellow);
                                break;
                            }
                            case 36: {
                                S36.setEnabled(false);
                                S36.setBackground(Color.yellow);
                                break;
                            }
                            case 37: {
                                S37.setEnabled(false);
                                S37.setBackground(Color.yellow);
                                break;
                            }
                            case 38: {
                                S38.setEnabled(false);
                                S38.setBackground(Color.yellow);
                                break;
                            }
                            case 39: {
                                S39.setEnabled(false);
                                S39.setBackground(Color.yellow);
                                break;
                            }
                            case 40: {
                                S40.setEnabled(false);
                                S40.setBackground(Color.yellow);
                                break;
                            }
                            case 41: {
                                S41.setEnabled(false);
                                S41.setBackground(Color.yellow);
                                break;
                            }
                            case 42: {
                                S42.setEnabled(false);
                                S42.setBackground(Color.yellow);
                                break;
                            }
                            case 43: {
                                S43.setEnabled(false);
                                S43.setBackground(Color.yellow);
                                break;
                            }
                            case 44: {
                                S44.setEnabled(false);
                                S44.setBackground(Color.yellow);
                                break;
                            }
                            case 45: {
                                S45.setEnabled(false);
                                S45.setBackground(Color.yellow);
                                break;
                            }
                            case 46: {
                                S46.setEnabled(false);
                                S46.setBackground(Color.yellow);
                                break;
                            }
                            case 47: {
                                S47.setEnabled(false);
                                S47.setBackground(Color.yellow);
                                break;
                            }
                            case 48: {
                                S48.setEnabled(false);
                                S48.setBackground(Color.yellow);
                                break;
                            }
                            case 49: {
                                S49.setEnabled(false);
                                S49.setBackground(Color.yellow);
                                break;
                            }
                            case 50: {
                                S50.setEnabled(false);
                                S50.setBackground(Color.yellow);
                                break;
                            }
                            case 51: {
                                S51.setEnabled(false);
                                S51.setBackground(Color.yellow);
                                break;
                            }
                            case 52: {
                                S52.setEnabled(false);
                                S52.setBackground(Color.yellow);
                                break;
                            }
                            case 53: {
                                S53.setEnabled(false);
                                S53.setBackground(Color.yellow);
                                break;
                            }
                            case 54: {
                                S54.setEnabled(false);
                                S54.setBackground(Color.yellow);
                                break;
                            }
                            case 55: {
                                S55.setEnabled(false);
                                S55.setBackground(Color.yellow);
                                break;
                            }
                            case 56: {
                                S56.setEnabled(false);
                                S56.setBackground(Color.yellow);
                                break;
                            }
                                                  
                        }
                    }
                } catch (ClassNotFoundException e1) {
                    // TODO Auto-generated catch block
                    e1.printStackTrace();
                } catch (SQLException e1) {
                    // TODO Auto-generated catch block
                    e1.printStackTrace();
                }
        	}
        });
        button_1.setBounds(195, 55, 116, 25);
        classpanel.add(button_1);
        
        JButton button_2 = new JButton("Economy ");
        button_2.setForeground(Color.DARK_GRAY);
        button_2.setFont(new Font("Times New Roman", Font.BOLD, 16));
        button_2.addActionListener(new ActionListener() {
        	public void actionPerformed(ActionEvent e) {
        		
        		sc.setText("Economy");
        		
        		S1.setVisible(false);S2.setVisible(false);S3.setVisible(false);S4.setVisible(false);S4.setVisible(false);S5.setVisible(false);S6.setVisible(false);
       		   S7.setVisible(false);S8.setVisible(false);S9.setVisible(false);S10.setVisible(false);S11.setVisible(false);S12.setVisible(false);S13.setVisible(false);
       		   S14.setVisible(false);S15.setVisible(false);S16.setVisible(false);S17.setVisible(false);S18.setVisible(false);S19.setVisible(false);S20.setVisible(false);
       		   S21.setVisible(false);S22.setVisible(false);S23.setVisible(false);S24.setVisible(false);S25.setVisible(false);S26.setVisible(false);S27.setVisible(false);
       		   S28.setVisible(false);S29.setVisible(false);S30.setVisible(false);S31.setVisible(false);S32.setVisible(false);S33.setVisible(false);S34.setVisible(false);
       		   S35.setVisible(false);S36.setVisible(false);S37.setVisible(false);S38.setVisible(false);S39.setVisible(false);S40.setVisible(false);S41.setVisible(false);
       		   S42.setVisible(false);S43.setVisible(false);S44.setVisible(false);S45.setVisible(false);S46.setVisible(false);S47.setVisible(false);S48.setVisible(false);
       		   S49.setVisible(false);S50.setVisible(false);S51.setVisible(false);S52.setVisible(false);S53.setVisible(false);S54.setVisible(false);S55.setVisible(false);
       		   S56.setVisible(false);
       		   
       		   S1.setBackground(Color.WHITE);S2.setBackground(Color.WHITE);S3.setBackground(Color.WHITE);S4.setBackground(Color.WHITE);S4.setBackground(Color.WHITE);S5.setBackground(Color.WHITE);S6.setBackground(Color.WHITE);
    		       S7.setBackground(Color.WHITE);S8.setBackground(Color.WHITE);S9.setBackground(Color.WHITE);S10.setBackground(Color.WHITE);S11.setBackground(Color.WHITE);S12.setBackground(Color.WHITE);S13.setBackground(Color.WHITE);
    		       S14.setBackground(Color.WHITE);S15.setBackground(Color.WHITE);S16.setBackground(Color.WHITE);S17.setBackground(Color.WHITE);S18.setBackground(Color.WHITE);S19.setBackground(Color.WHITE);S20.setBackground(Color.WHITE);
    		       S21.setBackground(Color.WHITE);S22.setBackground(Color.WHITE);S23.setBackground(Color.WHITE);S24.setBackground(Color.WHITE);S25.setBackground(Color.WHITE);S26.setBackground(Color.WHITE);S27.setBackground(Color.WHITE);
    		       S28.setBackground(Color.WHITE);S29.setBackground(Color.WHITE);S30.setBackground(Color.WHITE);S31.setBackground(Color.WHITE);S32.setBackground(Color.WHITE);S33.setBackground(Color.WHITE);S34.setBackground(Color.WHITE);
    		       S35.setBackground(Color.WHITE);S36.setBackground(Color.WHITE);S37.setBackground(Color.WHITE);S38.setBackground(Color.WHITE);S39.setBackground(Color.WHITE);S40.setBackground(Color.WHITE);S41.setBackground(Color.WHITE);
    		       S42.setBackground(Color.WHITE);S43.setBackground(Color.WHITE);S44.setBackground(Color.WHITE);S45.setBackground(Color.WHITE);S46.setBackground(Color.WHITE);S47.setBackground(Color.WHITE);S48.setBackground(Color.WHITE);
    		       S49.setBackground(Color.WHITE);S50.setBackground(Color.WHITE);S51.setBackground(Color.WHITE);S52.setBackground(Color.WHITE);S53.setBackground(Color.WHITE);S54.setBackground(Color.WHITE);S55.setBackground(Color.WHITE);
    		       S56.setBackground(Color.WHITE);
       		   
       		   S1.setEnabled(true);S2.setEnabled(true);S3.setEnabled(true);S4.setEnabled(true);S4.setEnabled(true);S5.setEnabled(true);S6.setEnabled(true);
     		   S7.setEnabled(true);S8.setEnabled(true);S9.setEnabled(true);S10.setEnabled(true);S11.setEnabled(true);S12.setEnabled(true);S13.setEnabled(true);
     		   S14.setEnabled(true);S15.setEnabled(true);S16.setEnabled(true);S17.setEnabled(true);S18.setEnabled(true);S19.setEnabled(true);S20.setEnabled(true);
     		   S21.setEnabled(true);S22.setEnabled(true);S23.setEnabled(true);S24.setEnabled(true);S25.setEnabled(true);S26.setEnabled(true);S27.setEnabled(true);
     		   S28.setEnabled(true);S29.setEnabled(true);S30.setEnabled(true);S31.setEnabled(true);S32.setEnabled(true);S33.setEnabled(true);S34.setEnabled(true);
     		   S35.setEnabled(true);S36.setEnabled(true);S37.setEnabled(true);S38.setEnabled(true);S39.setEnabled(true);S40.setEnabled(true);S41.setEnabled(true);
     		   S42.setEnabled(true);S43.setEnabled(true);S44.setEnabled(true);S45.setEnabled(true);S46.setEnabled(true);S47.setEnabled(true);S48.setEnabled(true);
     		   S49.setEnabled(true);S50.setEnabled(true);S51.setEnabled(true);S52.setEnabled(true);S53.setEnabled(true);S54.setEnabled(true);S55.setEnabled(true);
     		   S56.setEnabled(true);
       		   
       		   S1.setSelected(false);S2.setSelected(false);S3.setSelected(false);S4.setSelected(false);S4.setSelected(false);S5.setSelected(false);S6.setSelected(false);
       		   S7.setSelected(false);S8.setSelected(false);S9.setSelected(false);S10.setSelected(false);S11.setSelected(false);S12.setSelected(false);S13.setSelected(false);
       		   S14.setSelected(false);S15.setSelected(false);S16.setSelected(false);S17.setSelected(false);S18.setSelected(false);S19.setSelected(false);S20.setSelected(false);
     		   S21.setSelected(false);S22.setSelected(false);S23.setSelected(false);S24.setSelected(false);S25.setSelected(false);S26.setSelected(false);S27.setSelected(false);
       		   S28.setSelected(false);S29.setSelected(false);S30.setSelected(false);S31.setSelected(false);S32.setSelected(false);S33.setSelected(false);S34.setSelected(false);
       		   S35.setSelected(false);S36.setSelected(false);S37.setSelected(false);S38.setSelected(false);S39.setSelected(false);S40.setSelected(false);S41.setSelected(false);
       		   S42.setSelected(false);S43.setSelected(false);S44.setSelected(false);S45.setSelected(false);S46.setSelected(false);S47.setSelected(false);S48.setSelected(false);
       		   S49.setSelected(false);S50.setSelected(false);S51.setSelected(false);S52.setSelected(false);S53.setSelected(false);S54.setSelected(false);S55.setSelected(false);
       		   S56.setSelected(false);
      		   
       		try {
                Class.forName("com.mysql.jdbc.Driver");
                Connection con = DriverManager.getConnection("jdbc:mysql://localhost:3306/airline", "root", "root");
                Statement stmt = con.createStatement();
                String sql1 = "select * from flightdetails where fid='"+fid.getText()+"'";
                rs = stmt.executeQuery(sql1);
                while(rs.next())
                {
              	   int seats = Integer.parseInt(rs.getString("noec"));
              	   if(seats==1)
              	   {
              		   S1.setVisible(true);
              	   }
              	   if(seats==2)
              	   {
              		   S1.setVisible(true);S2.setVisible(true);
              	   }
              	   if(seats==3)
              	   {
              		   S1.setVisible(true);S2.setVisible(true);S3.setVisible(true);
              	   }
              	   if(seats==4)
              	   {
              		   S1.setVisible(true);S2.setVisible(true);S3.setVisible(true);S4.setVisible(true);
              	   }
              	   if(seats==5)
              	   {
              		   S1.setVisible(true);S2.setVisible(true);S3.setVisible(true);S4.setVisible(true);S5.setVisible(true);
              	   }
              	   if(seats==6)
              	   {
              		   S1.setVisible(true);S2.setVisible(true);S3.setVisible(true);S4.setVisible(true);S4.setVisible(true);S5.setVisible(true);S6.setVisible(true);
              	   }
              	   if(seats==7)
              	   {
              		   S1.setVisible(true);S2.setVisible(true);S3.setVisible(true);S4.setVisible(true);S4.setVisible(true);S5.setVisible(true);S6.setVisible(true);
              		   S7.setVisible(true);
              	   }
              	   if(seats==8)
              	   {
              		   S1.setVisible(true);S2.setVisible(true);S3.setVisible(true);S4.setVisible(true);S4.setVisible(true);S5.setVisible(true);S6.setVisible(true);
              		   S7.setVisible(true);S8.setVisible(true);
              	   }
              	   if(seats==9)
              	   {
              		   S1.setVisible(true);S2.setVisible(true);S3.setVisible(true);S4.setVisible(true);S4.setVisible(true);S5.setVisible(true);S6.setVisible(true);
              		   S7.setVisible(true);S8.setVisible(true);S9.setVisible(true);
              	   }
              	   if(seats==10)
              	   {
              		   S1.setVisible(true);S2.setVisible(true);S3.setVisible(true);S4.setVisible(true);S4.setVisible(true);S5.setVisible(true);S6.setVisible(true);
              		   S7.setVisible(true);S8.setVisible(true);S9.setVisible(true);S10.setVisible(true);
              	   }
              	   if(seats==11)
              	   {
              		   S1.setVisible(true);S2.setVisible(true);S3.setVisible(true);S4.setVisible(true);S4.setVisible(true);S5.setVisible(true);S6.setVisible(true);
              		   S7.setVisible(true);S8.setVisible(true);S9.setVisible(true);S10.setVisible(true);S11.setVisible(true);
              	   }
              	   if(seats==12)
              	   {
              		   S1.setVisible(true);S2.setVisible(true);S3.setVisible(true);S4.setVisible(true);S4.setVisible(true);S5.setVisible(true);S6.setVisible(true);
              		   S7.setVisible(true);S8.setVisible(true);S9.setVisible(true);S10.setVisible(true);S11.setVisible(true);S12.setVisible(true);
              	   }
              	   if(seats==13)
              	   {
              		   S1.setVisible(true);S2.setVisible(true);S3.setVisible(true);S4.setVisible(true);S4.setVisible(true);S5.setVisible(true);S6.setVisible(true);
              		   S7.setVisible(true);S8.setVisible(true);S9.setVisible(true);S10.setVisible(true);S11.setVisible(true);S12.setVisible(true);S13.setVisible(true);
              	   }
              	   if(seats==14)
              	   {
              		   S1.setVisible(true);S2.setVisible(true);S3.setVisible(true);S4.setVisible(true);S4.setVisible(true);S5.setVisible(true);S6.setVisible(true);
              		   S7.setVisible(true);S8.setVisible(true);S9.setVisible(true);S10.setVisible(true);S11.setVisible(true);S12.setVisible(true);S13.setVisible(true);
              		   S14.setVisible(true);
              	   }
              	   if(seats==15)
              	   {
              		   S1.setVisible(true);S2.setVisible(true);S3.setVisible(true);S4.setVisible(true);S4.setVisible(true);S5.setVisible(true);S6.setVisible(true);
              		   S7.setVisible(true);S8.setVisible(true);S9.setVisible(true);S10.setVisible(true);S11.setVisible(true);S12.setVisible(true);S13.setVisible(true);
              		   S14.setVisible(true);S15.setVisible(true);
              	   }
              	   if(seats==16)
              	   {
              		   S1.setVisible(true);S2.setVisible(true);S3.setVisible(true);S4.setVisible(true);S4.setVisible(true);S5.setVisible(true);S6.setVisible(true);
              		   S7.setVisible(true);S8.setVisible(true);S9.setVisible(true);S10.setVisible(true);S11.setVisible(true);S12.setVisible(true);S13.setVisible(true);
              		   S14.setVisible(true);S15.setVisible(true);S16.setVisible(true);
              	   }
              	   if(seats==17)
              	   {
              		   S1.setVisible(true);S2.setVisible(true);S3.setVisible(true);S4.setVisible(true);S4.setVisible(true);S5.setVisible(true);S6.setVisible(true);
              		   S7.setVisible(true);S8.setVisible(true);S9.setVisible(true);S10.setVisible(true);S11.setVisible(true);S12.setVisible(true);S13.setVisible(true);
              		   S14.setVisible(true);S15.setVisible(true);S16.setVisible(true);S17.setVisible(true);
              	   }
              	   if(seats==18)
              	   {
              		   S1.setVisible(true);S2.setVisible(true);S3.setVisible(true);S4.setVisible(true);S4.setVisible(true);S5.setVisible(true);S6.setVisible(true);
              		   S7.setVisible(true);S8.setVisible(true);S9.setVisible(true);S10.setVisible(true);S11.setVisible(true);S12.setVisible(true);S13.setVisible(true);
              		   S14.setVisible(true);S15.setVisible(true);S16.setVisible(true);S17.setVisible(true);S18.setVisible(true);
              	   }
              	   if(seats==19)
              	   {
              		   S1.setVisible(true);S2.setVisible(true);S3.setVisible(true);S4.setVisible(true);S4.setVisible(true);S5.setVisible(true);S6.setVisible(true);
              		   S7.setVisible(true);S8.setVisible(true);S9.setVisible(true);S10.setVisible(true);S11.setVisible(true);S12.setVisible(true);S13.setVisible(true);
              		   S14.setVisible(true);S15.setVisible(true);S16.setVisible(true);S17.setVisible(true);S18.setVisible(true);S19.setVisible(true);
              	   }
              	   if(seats==20)
              	   {
              		   S1.setVisible(true);S2.setVisible(true);S3.setVisible(true);S4.setVisible(true);S4.setVisible(true);S5.setVisible(true);S6.setVisible(true);
              		   S7.setVisible(true);S8.setVisible(true);S9.setVisible(true);S10.setVisible(true);S11.setVisible(true);S12.setVisible(true);S13.setVisible(true);
              		   S14.setVisible(true);S15.setVisible(true);S16.setVisible(true);S17.setVisible(true);S18.setVisible(true);S19.setVisible(true);S20.setVisible(true);
              	   }
              	   if(seats==21)
              	   {
              		   S1.setVisible(true);S2.setVisible(true);S3.setVisible(true);S4.setVisible(true);S4.setVisible(true);S5.setVisible(true);S6.setVisible(true);
              		   S7.setVisible(true);S8.setVisible(true);S9.setVisible(true);S10.setVisible(true);S11.setVisible(true);S12.setVisible(true);S13.setVisible(true);
              		   S14.setVisible(true);S15.setVisible(true);S16.setVisible(true);S17.setVisible(true);S18.setVisible(true);S19.setVisible(true);S20.setVisible(true);
              		   S21.setVisible(true);
              	   }
              	   if(seats==22)
              	   {
              		   S1.setVisible(true);S2.setVisible(true);S3.setVisible(true);S4.setVisible(true);S4.setVisible(true);S5.setVisible(true);S6.setVisible(true);
              		   S7.setVisible(true);S8.setVisible(true);S9.setVisible(true);S10.setVisible(true);S11.setVisible(true);S12.setVisible(true);S13.setVisible(true);
              		   S14.setVisible(true);S15.setVisible(true);S16.setVisible(true);S17.setVisible(true);S18.setVisible(true);S19.setVisible(true);S20.setVisible(true);
              		   S21.setVisible(true);S22.setVisible(true);
              	   }
              	   if(seats==23)
              	   {
              		   S1.setVisible(true);S2.setVisible(true);S3.setVisible(true);S4.setVisible(true);S4.setVisible(true);S5.setVisible(true);S6.setVisible(true);
              		   S7.setVisible(true);S8.setVisible(true);S9.setVisible(true);S10.setVisible(true);S11.setVisible(true);S12.setVisible(true);S13.setVisible(true);
              		   S14.setVisible(true);S15.setVisible(true);S16.setVisible(true);S17.setVisible(true);S18.setVisible(true);S19.setVisible(true);S20.setVisible(true);
              		   S21.setVisible(true);S22.setVisible(true);S23.setVisible(true);
              	   }
              	   if(seats==24)
              	   {
              		   S1.setVisible(true);S2.setVisible(true);S3.setVisible(true);S4.setVisible(true);S4.setVisible(true);S5.setVisible(true);S6.setVisible(true);
              		   S7.setVisible(true);S8.setVisible(true);S9.setVisible(true);S10.setVisible(true);S11.setVisible(true);S12.setVisible(true);S13.setVisible(true);
              		   S14.setVisible(true);S15.setVisible(true);S16.setVisible(true);S17.setVisible(true);S18.setVisible(true);S19.setVisible(true);S20.setVisible(true);
              		   S21.setVisible(true);S22.setVisible(true);S23.setVisible(true);S24.setVisible(true);
              	   }
              	   if(seats==25)
              	   {
              		   S1.setVisible(true);S2.setVisible(true);S3.setVisible(true);S4.setVisible(true);S4.setVisible(true);S5.setVisible(true);S6.setVisible(true);
              		   S7.setVisible(true);S8.setVisible(true);S9.setVisible(true);S10.setVisible(true);S11.setVisible(true);S12.setVisible(true);S13.setVisible(true);
              		   S14.setVisible(true);S15.setVisible(true);S16.setVisible(true);S17.setVisible(true);S18.setVisible(true);S19.setVisible(true);S20.setVisible(true);
              		   S21.setVisible(true);S22.setVisible(true);S23.setVisible(true);S24.setVisible(true);S25.setVisible(true);
              	   }
              	   if(seats==26)
              	   {
              		   S1.setVisible(true);S2.setVisible(true);S3.setVisible(true);S4.setVisible(true);S4.setVisible(true);S5.setVisible(true);S6.setVisible(true);
              		   S7.setVisible(true);S8.setVisible(true);S9.setVisible(true);S10.setVisible(true);S11.setVisible(true);S12.setVisible(true);S13.setVisible(true);
              		   S14.setVisible(true);S15.setVisible(true);S16.setVisible(true);S17.setVisible(true);S18.setVisible(true);S19.setVisible(true);S20.setVisible(true);
              		   S21.setVisible(true);S22.setVisible(true);S23.setVisible(true);S24.setVisible(true);S25.setVisible(true);S26.setVisible(true);
              	   }
              	   if(seats==27)
              	   {
              		   S1.setVisible(true);S2.setVisible(true);S3.setVisible(true);S4.setVisible(true);S4.setVisible(true);S5.setVisible(true);S6.setVisible(true);
              		   S7.setVisible(true);S8.setVisible(true);S9.setVisible(true);S10.setVisible(true);S11.setVisible(true);S12.setVisible(true);S13.setVisible(true);
              		   S14.setVisible(true);S15.setVisible(true);S16.setVisible(true);S17.setVisible(true);S18.setVisible(true);S19.setVisible(true);S20.setVisible(true);
              		   S21.setVisible(true);S22.setVisible(true);S23.setVisible(true);S24.setVisible(true);S25.setVisible(true);S26.setVisible(true);S27.setVisible(true);
              	   }
              	   if(seats==28)
              	   {
              		   S1.setVisible(true);S2.setVisible(true);S3.setVisible(true);S4.setVisible(true);S4.setVisible(true);S5.setVisible(true);S6.setVisible(true);
              		   S7.setVisible(true);S8.setVisible(true);S9.setVisible(true);S10.setVisible(true);S11.setVisible(true);S12.setVisible(true);S13.setVisible(true);
              		   S14.setVisible(true);S15.setVisible(true);S16.setVisible(true);S17.setVisible(true);S18.setVisible(true);S19.setVisible(true);S20.setVisible(true);
              		   S21.setVisible(true);S22.setVisible(true);S23.setVisible(true);S24.setVisible(true);S25.setVisible(true);S26.setVisible(true);S27.setVisible(true);
              		   S28.setVisible(true);
              	   }
              	   if(seats==29)
              	   {
              		   S1.setVisible(true);S2.setVisible(true);S3.setVisible(true);S4.setVisible(true);S4.setVisible(true);S5.setVisible(true);S6.setVisible(true);
              		   S7.setVisible(true);S8.setVisible(true);S9.setVisible(true);S10.setVisible(true);S11.setVisible(true);S12.setVisible(true);S13.setVisible(true);
              		   S14.setVisible(true);S15.setVisible(true);S16.setVisible(true);S17.setVisible(true);S18.setVisible(true);S19.setVisible(true);S20.setVisible(true);
              		   S21.setVisible(true);S22.setVisible(true);S23.setVisible(true);S24.setVisible(true);S25.setVisible(true);S26.setVisible(true);S27.setVisible(true);
              		   S28.setVisible(true);S29.setVisible(true);
              	   }
              	   if(seats==30)
              	   {
              		   S1.setVisible(true);S2.setVisible(true);S3.setVisible(true);S4.setVisible(true);S4.setVisible(true);S5.setVisible(true);S6.setVisible(true);
              		   S7.setVisible(true);S8.setVisible(true);S9.setVisible(true);S10.setVisible(true);S11.setVisible(true);S12.setVisible(true);S13.setVisible(true);
              		   S14.setVisible(true);S15.setVisible(true);S16.setVisible(true);S17.setVisible(true);S18.setVisible(true);S19.setVisible(true);S20.setVisible(true);
              		   S21.setVisible(true);S22.setVisible(true);S23.setVisible(true);S24.setVisible(true);S25.setVisible(true);S26.setVisible(true);S27.setVisible(true);
              		   S28.setVisible(true);S29.setVisible(true);S30.setVisible(true);
              	   }
              	   if(seats==31)
              	   {
              		   S1.setVisible(true);S2.setVisible(true);S3.setVisible(true);S4.setVisible(true);S4.setVisible(true);S5.setVisible(true);S6.setVisible(true);
              		   S7.setVisible(true);S8.setVisible(true);S9.setVisible(true);S10.setVisible(true);S11.setVisible(true);S12.setVisible(true);S13.setVisible(true);
              		   S14.setVisible(true);S15.setVisible(true);S16.setVisible(true);S17.setVisible(true);S18.setVisible(true);S19.setVisible(true);S20.setVisible(true);
              		   S21.setVisible(true);S22.setVisible(true);S23.setVisible(true);S24.setVisible(true);S25.setVisible(true);S26.setVisible(true);S27.setVisible(true);
              		   S28.setVisible(true);S29.setVisible(true);S30.setVisible(true);S31.setVisible(true);
              	   }
              	   if(seats==32)
              	   {
              		   S1.setVisible(true);S2.setVisible(true);S3.setVisible(true);S4.setVisible(true);S4.setVisible(true);S5.setVisible(true);S6.setVisible(true);
              		   S7.setVisible(true);S8.setVisible(true);S9.setVisible(true);S10.setVisible(true);S11.setVisible(true);S12.setVisible(true);S13.setVisible(true);
              		   S14.setVisible(true);S15.setVisible(true);S16.setVisible(true);S17.setVisible(true);S18.setVisible(true);S19.setVisible(true);S20.setVisible(true);
              		   S21.setVisible(true);S22.setVisible(true);S23.setVisible(true);S24.setVisible(true);S25.setVisible(true);S26.setVisible(true);S27.setVisible(true);
              		   S28.setVisible(true);S29.setVisible(true);S30.setVisible(true);S31.setVisible(true);S32.setVisible(true);
              	   }
              	   if(seats==33)
              	   {
              		   S1.setVisible(true);S2.setVisible(true);S3.setVisible(true);S4.setVisible(true);S4.setVisible(true);S5.setVisible(true);S6.setVisible(true);
              		   S7.setVisible(true);S8.setVisible(true);S9.setVisible(true);S10.setVisible(true);S11.setVisible(true);S12.setVisible(true);S13.setVisible(true);
              		   S14.setVisible(true);S15.setVisible(true);S16.setVisible(true);S17.setVisible(true);S18.setVisible(true);S19.setVisible(true);S20.setVisible(true);
              		   S21.setVisible(true);S22.setVisible(true);S23.setVisible(true);S24.setVisible(true);S25.setVisible(true);S26.setVisible(true);S27.setVisible(true);
              		   S28.setVisible(true);S29.setVisible(true);S30.setVisible(true);S31.setVisible(true);S32.setVisible(true);S33.setVisible(true);
              	   }
              	   if(seats==34)
              	   {
              		   S1.setVisible(true);S2.setVisible(true);S3.setVisible(true);S4.setVisible(true);S4.setVisible(true);S5.setVisible(true);S6.setVisible(true);
              		   S7.setVisible(true);S8.setVisible(true);S9.setVisible(true);S10.setVisible(true);S11.setVisible(true);S12.setVisible(true);S13.setVisible(true);
              		   S14.setVisible(true);S15.setVisible(true);S16.setVisible(true);S17.setVisible(true);S18.setVisible(true);S19.setVisible(true);S20.setVisible(true);
              		   S21.setVisible(true);S22.setVisible(true);S23.setVisible(true);S24.setVisible(true);S25.setVisible(true);S26.setVisible(true);S27.setVisible(true);
              		   S28.setVisible(true);S29.setVisible(true);S30.setVisible(true);S31.setVisible(true);S32.setVisible(true);S33.setVisible(true);S34.setVisible(true);
              	   }
              	   if(seats==35)
              	   {
              		   S1.setVisible(true);S2.setVisible(true);S3.setVisible(true);S4.setVisible(true);S4.setVisible(true);S5.setVisible(true);S6.setVisible(true);
              		   S7.setVisible(true);S8.setVisible(true);S9.setVisible(true);S10.setVisible(true);S11.setVisible(true);S12.setVisible(true);S13.setVisible(true);
              		   S14.setVisible(true);S15.setVisible(true);S16.setVisible(true);S17.setVisible(true);S18.setVisible(true);S19.setVisible(true);S20.setVisible(true);
              		   S21.setVisible(true);S22.setVisible(true);S23.setVisible(true);S24.setVisible(true);S25.setVisible(true);S26.setVisible(true);S27.setVisible(true);
              		   S28.setVisible(true);S29.setVisible(true);S30.setVisible(true);S31.setVisible(true);S32.setVisible(true);S33.setVisible(true);S34.setVisible(true);
              		   S35.setVisible(true);
              	   }
              	   if(seats==36)
              	   {
              		   S1.setVisible(true);S2.setVisible(true);S3.setVisible(true);S4.setVisible(true);S4.setVisible(true);S5.setVisible(true);S6.setVisible(true);
              		   S7.setVisible(true);S8.setVisible(true);S9.setVisible(true);S10.setVisible(true);S11.setVisible(true);S12.setVisible(true);S13.setVisible(true);
              		   S14.setVisible(true);S15.setVisible(true);S16.setVisible(true);S17.setVisible(true);S18.setVisible(true);S19.setVisible(true);S20.setVisible(true);
              		   S21.setVisible(true);S22.setVisible(true);S23.setVisible(true);S24.setVisible(true);S25.setVisible(true);S26.setVisible(true);S27.setVisible(true);
              		   S28.setVisible(true);S29.setVisible(true);S30.setVisible(true);S31.setVisible(true);S32.setVisible(true);S33.setVisible(true);S34.setVisible(true);
              		   S35.setVisible(true);S36.setVisible(true);
              	   }
              	   if(seats==37)
              	   {
              		   S1.setVisible(true);S2.setVisible(true);S3.setVisible(true);S4.setVisible(true);S4.setVisible(true);S5.setVisible(true);S6.setVisible(true);
              		   S7.setVisible(true);S8.setVisible(true);S9.setVisible(true);S10.setVisible(true);S11.setVisible(true);S12.setVisible(true);S13.setVisible(true);
              		   S14.setVisible(true);S15.setVisible(true);S16.setVisible(true);S17.setVisible(true);S18.setVisible(true);S19.setVisible(true);S20.setVisible(true);
              		   S21.setVisible(true);S22.setVisible(true);S23.setVisible(true);S24.setVisible(true);S25.setVisible(true);S26.setVisible(true);S27.setVisible(true);
              		   S28.setVisible(true);S29.setVisible(true);S30.setVisible(true);S31.setVisible(true);S32.setVisible(true);S33.setVisible(true);S34.setVisible(true);
              		   S35.setVisible(true);S36.setVisible(true);S37.setVisible(true);
              	   }
              	   if(seats==38)
              	   {
              		   S1.setVisible(true);S2.setVisible(true);S3.setVisible(true);S4.setVisible(true);S4.setVisible(true);S5.setVisible(true);S6.setVisible(true);
              		   S7.setVisible(true);S8.setVisible(true);S9.setVisible(true);S10.setVisible(true);S11.setVisible(true);S12.setVisible(true);S13.setVisible(true);
              		   S14.setVisible(true);S15.setVisible(true);S16.setVisible(true);S17.setVisible(true);S18.setVisible(true);S19.setVisible(true);S20.setVisible(true);
              		   S21.setVisible(true);S22.setVisible(true);S23.setVisible(true);S24.setVisible(true);S25.setVisible(true);S26.setVisible(true);S27.setVisible(true);
              		   S28.setVisible(true);S29.setVisible(true);S30.setVisible(true);S31.setVisible(true);S32.setVisible(true);S33.setVisible(true);S34.setVisible(true);
              		   S35.setVisible(true);S36.setVisible(true);S37.setVisible(true);S38.setVisible(true);
              	   }
              	   if(seats==39)
              	   {
              		   S1.setVisible(true);S2.setVisible(true);S3.setVisible(true);S4.setVisible(true);S4.setVisible(true);S5.setVisible(true);S6.setVisible(true);
              		   S7.setVisible(true);S8.setVisible(true);S9.setVisible(true);S10.setVisible(true);S11.setVisible(true);S12.setVisible(true);S13.setVisible(true);
              		   S14.setVisible(true);S15.setVisible(true);S16.setVisible(true);S17.setVisible(true);S18.setVisible(true);S19.setVisible(true);S20.setVisible(true);
              		   S21.setVisible(true);S22.setVisible(true);S23.setVisible(true);S24.setVisible(true);S25.setVisible(true);S26.setVisible(true);S27.setVisible(true);
              		   S28.setVisible(true);S29.setVisible(true);S30.setVisible(true);S31.setVisible(true);S32.setVisible(true);S33.setVisible(true);S34.setVisible(true);
              		   S35.setVisible(true);S36.setVisible(true);S37.setVisible(true);S38.setVisible(true);S39.setVisible(true);
              	   }
              	   if(seats==40)
              	   {
              		   S1.setVisible(true);S2.setVisible(true);S3.setVisible(true);S4.setVisible(true);S4.setVisible(true);S5.setVisible(true);S6.setVisible(true);
              		   S7.setVisible(true);S8.setVisible(true);S9.setVisible(true);S10.setVisible(true);S11.setVisible(true);S12.setVisible(true);S13.setVisible(true);
              		   S14.setVisible(true);S15.setVisible(true);S16.setVisible(true);S17.setVisible(true);S18.setVisible(true);S19.setVisible(true);S20.setVisible(true);
              		   S21.setVisible(true);S22.setVisible(true);S23.setVisible(true);S24.setVisible(true);S25.setVisible(true);S26.setVisible(true);S27.setVisible(true);
              		   S28.setVisible(true);S29.setVisible(true);S30.setVisible(true);S31.setVisible(true);S32.setVisible(true);S33.setVisible(true);S34.setVisible(true);
              		   S35.setVisible(true);S36.setVisible(true);S37.setVisible(true);S38.setVisible(true);S39.setVisible(true);S40.setVisible(true);
              	   }
              	   if(seats==41)
              	   {
              		   S1.setVisible(true);S2.setVisible(true);S3.setVisible(true);S4.setVisible(true);S4.setVisible(true);S5.setVisible(true);S6.setVisible(true);
              		   S7.setVisible(true);S8.setVisible(true);S9.setVisible(true);S10.setVisible(true);S11.setVisible(true);S12.setVisible(true);S13.setVisible(true);
              		   S14.setVisible(true);S15.setVisible(true);S16.setVisible(true);S17.setVisible(true);S18.setVisible(true);S19.setVisible(true);S20.setVisible(true);
              		   S21.setVisible(true);S22.setVisible(true);S23.setVisible(true);S24.setVisible(true);S25.setVisible(true);S26.setVisible(true);S27.setVisible(true);
              		   S28.setVisible(true);S29.setVisible(true);S30.setVisible(true);S31.setVisible(true);S32.setVisible(true);S33.setVisible(true);S34.setVisible(true);
              		   S35.setVisible(true);S36.setVisible(true);S37.setVisible(true);S38.setVisible(true);S39.setVisible(true);S40.setVisible(true);S41.setVisible(true);
              	   }
              	   if(seats==42)
              	   {
              		   S1.setVisible(true);S2.setVisible(true);S3.setVisible(true);S4.setVisible(true);S4.setVisible(true);S5.setVisible(true);S6.setVisible(true);
              		   S7.setVisible(true);S8.setVisible(true);S9.setVisible(true);S10.setVisible(true);S11.setVisible(true);S12.setVisible(true);S13.setVisible(true);
              		   S14.setVisible(true);S15.setVisible(true);S16.setVisible(true);S17.setVisible(true);S18.setVisible(true);S19.setVisible(true);S20.setVisible(true);
              		   S21.setVisible(true);S22.setVisible(true);S23.setVisible(true);S24.setVisible(true);S25.setVisible(true);S26.setVisible(true);S27.setVisible(true);
              		   S28.setVisible(true);S29.setVisible(true);S30.setVisible(true);S31.setVisible(true);S32.setVisible(true);S33.setVisible(true);S34.setVisible(true);
              		   S35.setVisible(true);S36.setVisible(true);S37.setVisible(true);S38.setVisible(true);S39.setVisible(true);S40.setVisible(true);S41.setVisible(true);
              		   S42.setVisible(true);
              	   }
              	   if(seats==43)
              	   {
              		   S1.setVisible(true);S2.setVisible(true);S3.setVisible(true);S4.setVisible(true);S4.setVisible(true);S5.setVisible(true);S6.setVisible(true);
              		   S7.setVisible(true);S8.setVisible(true);S9.setVisible(true);S10.setVisible(true);S11.setVisible(true);S12.setVisible(true);S13.setVisible(true);
              		   S14.setVisible(true);S15.setVisible(true);S16.setVisible(true);S17.setVisible(true);S18.setVisible(true);S19.setVisible(true);S20.setVisible(true);
              		   S21.setVisible(true);S22.setVisible(true);S23.setVisible(true);S24.setVisible(true);S25.setVisible(true);S26.setVisible(true);S27.setVisible(true);
              		   S28.setVisible(true);S29.setVisible(true);S30.setVisible(true);S31.setVisible(true);S32.setVisible(true);S33.setVisible(true);S34.setVisible(true);
              		   S35.setVisible(true);S36.setVisible(true);S37.setVisible(true);S38.setVisible(true);S39.setVisible(true);S40.setVisible(true);S41.setVisible(true);
              		   S42.setVisible(true);S43.setVisible(true);
              	   }
              	   if(seats==44)
              	   {
              		   S1.setVisible(true);S2.setVisible(true);S3.setVisible(true);S4.setVisible(true);S4.setVisible(true);S5.setVisible(true);S6.setVisible(true);
              		   S7.setVisible(true);S8.setVisible(true);S9.setVisible(true);S10.setVisible(true);S11.setVisible(true);S12.setVisible(true);S13.setVisible(true);
              		   S14.setVisible(true);S15.setVisible(true);S16.setVisible(true);S17.setVisible(true);S18.setVisible(true);S19.setVisible(true);S20.setVisible(true);
              		   S21.setVisible(true);S22.setVisible(true);S23.setVisible(true);S24.setVisible(true);S25.setVisible(true);S26.setVisible(true);S27.setVisible(true);
              		   S28.setVisible(true);S29.setVisible(true);S30.setVisible(true);S31.setVisible(true);S32.setVisible(true);S33.setVisible(true);S34.setVisible(true);
              		   S35.setVisible(true);S36.setVisible(true);S37.setVisible(true);S38.setVisible(true);S39.setVisible(true);S40.setVisible(true);S41.setVisible(true);
              		   S42.setVisible(true);S43.setVisible(true);S44.setVisible(true);
              	   }
              	   
              	   if(seats==45)
              	   {
              		   S1.setVisible(true);S2.setVisible(true);S3.setVisible(true);S4.setVisible(true);S4.setVisible(true);S5.setVisible(true);S6.setVisible(true);
              		   S7.setVisible(true);S8.setVisible(true);S9.setVisible(true);S10.setVisible(true);S11.setVisible(true);S12.setVisible(true);S13.setVisible(true);
              		   S14.setVisible(true);S15.setVisible(true);S16.setVisible(true);S17.setVisible(true);S18.setVisible(true);S19.setVisible(true);S20.setVisible(true);
              		   S21.setVisible(true);S22.setVisible(true);S23.setVisible(true);S24.setVisible(true);S25.setVisible(true);S26.setVisible(true);S27.setVisible(true);
              		   S28.setVisible(true);S29.setVisible(true);S30.setVisible(true);S31.setVisible(true);S32.setVisible(true);S33.setVisible(true);S34.setVisible(true);
              		   S35.setVisible(true);S36.setVisible(true);S37.setVisible(true);S38.setVisible(true);S39.setVisible(true);S40.setVisible(true);S41.setVisible(true);
              		   S42.setVisible(true);S43.setVisible(true);S44.setVisible(true);S45.setVisible(true);
              	   }
              	   if(seats==46)
              	   {
              		   S1.setVisible(true);S2.setVisible(true);S3.setVisible(true);S4.setVisible(true);S4.setVisible(true);S5.setVisible(true);S6.setVisible(true);
              		   S7.setVisible(true);S8.setVisible(true);S9.setVisible(true);S10.setVisible(true);S11.setVisible(true);S12.setVisible(true);S13.setVisible(true);
              		   S14.setVisible(true);S15.setVisible(true);S16.setVisible(true);S17.setVisible(true);S18.setVisible(true);S19.setVisible(true);S20.setVisible(true);
              		   S21.setVisible(true);S22.setVisible(true);S23.setVisible(true);S24.setVisible(true);S25.setVisible(true);S26.setVisible(true);S27.setVisible(true);
              		   S28.setVisible(true);S29.setVisible(true);S30.setVisible(true);S31.setVisible(true);S32.setVisible(true);S33.setVisible(true);S34.setVisible(true);
              		   S35.setVisible(true);S36.setVisible(true);S37.setVisible(true);S38.setVisible(true);S39.setVisible(true);S40.setVisible(true);S41.setVisible(true);
              		   S42.setVisible(true);S43.setVisible(true);S44.setVisible(true);S45.setVisible(true);S46.setVisible(true);
              	   }
              	   if(seats==47)
              	   {
              		   S1.setVisible(true);S2.setVisible(true);S3.setVisible(true);S4.setVisible(true);S4.setVisible(true);S5.setVisible(true);S6.setVisible(true);
              		   S7.setVisible(true);S8.setVisible(true);S9.setVisible(true);S10.setVisible(true);S11.setVisible(true);S12.setVisible(true);S13.setVisible(true);
              		   S14.setVisible(true);S15.setVisible(true);S16.setVisible(true);S17.setVisible(true);S18.setVisible(true);S19.setVisible(true);S20.setVisible(true);
              		   S28.setVisible(true);S29.setVisible(true);S30.setVisible(true);S31.setVisible(true);S32.setVisible(true);S33.setVisible(true);S34.setVisible(true);
              		   S35.setVisible(true);S36.setVisible(true);S37.setVisible(true);S38.setVisible(true);S39.setVisible(true);S40.setVisible(true);S41.setVisible(true);
              		   S42.setVisible(true);S43.setVisible(true);S44.setVisible(true);S45.setVisible(true);S46.setVisible(true);S47.setVisible(true);
              	   }
              	   if(seats==48)
              	   {
              		   S1.setVisible(true);S2.setVisible(true);S3.setVisible(true);S4.setVisible(true);S4.setVisible(true);S5.setVisible(true);S6.setVisible(true);
              		   S7.setVisible(true);S8.setVisible(true);S9.setVisible(true);S10.setVisible(true);S11.setVisible(true);S12.setVisible(true);S13.setVisible(true);
              		   S14.setVisible(true);S15.setVisible(true);S16.setVisible(true);S17.setVisible(true);S18.setVisible(true);S19.setVisible(true);S20.setVisible(true);
              		   S21.setVisible(true);S22.setVisible(true);S23.setVisible(true);S24.setVisible(true);S25.setVisible(true);S26.setVisible(true);S27.setVisible(true);
              		   S28.setVisible(true);S29.setVisible(true);S30.setVisible(true);S31.setVisible(true);S32.setVisible(true);S33.setVisible(true);S34.setVisible(true);
              		   S35.setVisible(true);S36.setVisible(true);S37.setVisible(true);S38.setVisible(true);S39.setVisible(true);S40.setVisible(true);S41.setVisible(true);
              		   S42.setVisible(true);S43.setVisible(true);S44.setVisible(true);S45.setVisible(true);S46.setVisible(true);S47.setVisible(true);S48.setVisible(true);
              	   }
              	   if(seats==49)
              	   {
              		   S1.setVisible(true);S2.setVisible(true);S3.setVisible(true);S4.setVisible(true);S4.setVisible(true);S5.setVisible(true);S6.setVisible(true);
              		   S7.setVisible(true);S8.setVisible(true);S9.setVisible(true);S10.setVisible(true);S11.setVisible(true);S12.setVisible(true);S13.setVisible(true);
              		   S14.setVisible(true);S15.setVisible(true);S16.setVisible(true);S17.setVisible(true);S18.setVisible(true);S19.setVisible(true);S20.setVisible(true);
              		   S21.setVisible(true);S22.setVisible(true);S23.setVisible(true);S24.setVisible(true);S25.setVisible(true);S26.setVisible(true);S27.setVisible(true);
              		   S28.setVisible(true);S29.setVisible(true);S30.setVisible(true);S31.setVisible(true);S32.setVisible(true);S33.setVisible(true);S34.setVisible(true);
              		   S35.setVisible(true);S36.setVisible(true);S37.setVisible(true);S38.setVisible(true);S39.setVisible(true);S40.setVisible(true);S41.setVisible(true);
              		   S42.setVisible(true);S43.setVisible(true);S44.setVisible(true);S45.setVisible(true);S46.setVisible(true);S47.setVisible(true);S48.setVisible(true);
              		   S49.setVisible(true);
              	   }
              	   if(seats==50)
              	   {
              		   S1.setVisible(true);S2.setVisible(true);S3.setVisible(true);S4.setVisible(true);S4.setVisible(true);S5.setVisible(true);S6.setVisible(true);
              		   S7.setVisible(true);S8.setVisible(true);S9.setVisible(true);S10.setVisible(true);S11.setVisible(true);S12.setVisible(true);S13.setVisible(true);
              		   S14.setVisible(true);S15.setVisible(true);S16.setVisible(true);S17.setVisible(true);S18.setVisible(true);S19.setVisible(true);S20.setVisible(true);
              		   S21.setVisible(true);S22.setVisible(true);S23.setVisible(true);S24.setVisible(true);S25.setVisible(true);S26.setVisible(true);S27.setVisible(true);
              		   S28.setVisible(true);S29.setVisible(true);S30.setVisible(true);S31.setVisible(true);S32.setVisible(true);S33.setVisible(true);S34.setVisible(true);
              		   S35.setVisible(true);S36.setVisible(true);S37.setVisible(true);S38.setVisible(true);S39.setVisible(true);S40.setVisible(true);S41.setVisible(true);
              		   S42.setVisible(true);S43.setVisible(true);S44.setVisible(true);S45.setVisible(true);S46.setVisible(true);S47.setVisible(true);S48.setVisible(true);
              		   S49.setVisible(true);S50.setVisible(true);
              	   }
              	   if(seats==51)
              	   {
              		   S1.setVisible(true);S2.setVisible(true);S3.setVisible(true);S4.setVisible(true);S4.setVisible(true);S5.setVisible(true);S6.setVisible(true);
              		   S7.setVisible(true);S8.setVisible(true);S9.setVisible(true);S10.setVisible(true);S11.setVisible(true);S12.setVisible(true);S13.setVisible(true);
              		   S14.setVisible(true);S15.setVisible(true);S16.setVisible(true);S17.setVisible(true);S18.setVisible(true);S19.setVisible(true);S20.setVisible(true);
              		   S21.setVisible(true);S22.setVisible(true);S23.setVisible(true);S24.setVisible(true);S25.setVisible(true);S26.setVisible(true);S27.setVisible(true);
              		   S28.setVisible(true);S29.setVisible(true);S30.setVisible(true);S31.setVisible(true);S32.setVisible(true);S33.setVisible(true);S34.setVisible(true);
              		   S35.setVisible(true);S36.setVisible(true);S37.setVisible(true);S38.setVisible(true);S39.setVisible(true);S40.setVisible(true);S41.setVisible(true);
              		   S42.setVisible(true);S43.setVisible(true);S44.setVisible(true);S45.setVisible(true);S46.setVisible(true);S47.setVisible(true);S48.setVisible(true);
              		   S49.setVisible(true);S50.setVisible(true);S51.setVisible(true);
              	   }
              	   if(seats==52)
              	   {
              		   S1.setVisible(true);S2.setVisible(true);S3.setVisible(true);S4.setVisible(true);S4.setVisible(true);S5.setVisible(true);S6.setVisible(true);
              		   S7.setVisible(true);S8.setVisible(true);S9.setVisible(true);S10.setVisible(true);S11.setVisible(true);S12.setVisible(true);S13.setVisible(true);
              		   S14.setVisible(true);S15.setVisible(true);S16.setVisible(true);S17.setVisible(true);S18.setVisible(true);S19.setVisible(true);S20.setVisible(true);
              		   S21.setVisible(true);S22.setVisible(true);S23.setVisible(true);S24.setVisible(true);S25.setVisible(true);S26.setVisible(true);S27.setVisible(true);
              		   S28.setVisible(true);S29.setVisible(true);S30.setVisible(true);S31.setVisible(true);S32.setVisible(true);S33.setVisible(true);S34.setVisible(true);
              		   S35.setVisible(true);S36.setVisible(true);S37.setVisible(true);S38.setVisible(true);S39.setVisible(true);S40.setVisible(true);S41.setVisible(true);
              		   S42.setVisible(true);S43.setVisible(true);S44.setVisible(true);S45.setVisible(true);S46.setVisible(true);S47.setVisible(true);S48.setVisible(true);
              		   S49.setVisible(true);S50.setVisible(true);S51.setVisible(true);S52.setVisible(true);
              	   }
              	   if(seats==53)
              	   {
              		   S1.setVisible(true);S2.setVisible(true);S3.setVisible(true);S4.setVisible(true);S4.setVisible(true);S5.setVisible(true);S6.setVisible(true);
              		   S7.setVisible(true);S8.setVisible(true);S9.setVisible(true);S10.setVisible(true);S11.setVisible(true);S12.setVisible(true);S13.setVisible(true);
              		   S14.setVisible(true);S15.setVisible(true);S16.setVisible(true);S17.setVisible(true);S18.setVisible(true);S19.setVisible(true);S20.setVisible(true);
              		   S21.setVisible(true);S22.setVisible(true);S23.setVisible(true);S24.setVisible(true);S25.setVisible(true);S26.setVisible(true);S27.setVisible(true);
              		   S28.setVisible(true);S29.setVisible(true);S30.setVisible(true);S31.setVisible(true);S32.setVisible(true);S33.setVisible(true);S34.setVisible(true);
              		   S35.setVisible(true);S36.setVisible(true);S37.setVisible(true);S38.setVisible(true);S39.setVisible(true);S40.setVisible(true);S41.setVisible(true);
              		   S42.setVisible(true);S43.setVisible(true);S44.setVisible(true);S45.setVisible(true);S46.setVisible(true);S47.setVisible(true);S48.setVisible(true);
              		   S49.setVisible(true);S50.setVisible(true);S51.setVisible(true);S52.setVisible(true);S53.setVisible(true);
              	   }
              	   if(seats==54)
              	   {
              		   S1.setVisible(true);S2.setVisible(true);S3.setVisible(true);S4.setVisible(true);S4.setVisible(true);S5.setVisible(true);S6.setVisible(true);
              		   S7.setVisible(true);S8.setVisible(true);S9.setVisible(true);S10.setVisible(true);S11.setVisible(true);S12.setVisible(true);S13.setVisible(true);
              		   S14.setVisible(true);S15.setVisible(true);S16.setVisible(true);S17.setVisible(true);S18.setVisible(true);S19.setVisible(true);S20.setVisible(true);
              		   S21.setVisible(true);S22.setVisible(true);S23.setVisible(true);S24.setVisible(true);S25.setVisible(true);S26.setVisible(true);S27.setVisible(true);
              		   S28.setVisible(true);S29.setVisible(true);S30.setVisible(true);S31.setVisible(true);S32.setVisible(true);S33.setVisible(true);S34.setVisible(true);
              		   S35.setVisible(true);S36.setVisible(true);S37.setVisible(true);S38.setVisible(true);S39.setVisible(true);S40.setVisible(true);S41.setVisible(true);
              		   S42.setVisible(true);S43.setVisible(true);S44.setVisible(true);S45.setVisible(true);S46.setVisible(true);S47.setVisible(true);S48.setVisible(true);
              		   S49.setVisible(true);S50.setVisible(true);S51.setVisible(true);S52.setVisible(true);S53.setVisible(true);S54.setVisible(true);
              	   }
              	   if(seats==55)
              	   {
              		   S1.setVisible(true);S2.setVisible(true);S3.setVisible(true);S4.setVisible(true);S4.setVisible(true);S5.setVisible(true);S6.setVisible(true);
              		   S7.setVisible(true);S8.setVisible(true);S9.setVisible(true);S10.setVisible(true);S11.setVisible(true);S12.setVisible(true);S13.setVisible(true);
              		   S14.setVisible(true);S15.setVisible(true);S16.setVisible(true);S17.setVisible(true);S18.setVisible(true);S19.setVisible(true);S20.setVisible(true);
              		   S21.setVisible(true);S22.setVisible(true);S23.setVisible(true);S24.setVisible(true);S25.setVisible(true);S26.setVisible(true);S27.setVisible(true);
              		   S28.setVisible(true);S29.setVisible(true);S30.setVisible(true);S31.setVisible(true);S32.setVisible(true);S33.setVisible(true);S34.setVisible(true);
              		   S35.setVisible(true);S36.setVisible(true);S37.setVisible(true);S38.setVisible(true);S39.setVisible(true);S40.setVisible(true);S41.setVisible(true);
              		   S42.setVisible(true);S43.setVisible(true);S44.setVisible(true);S45.setVisible(true);S46.setVisible(true);S47.setVisible(true);S48.setVisible(true);
              		   S49.setVisible(true);S50.setVisible(true);S51.setVisible(true);S52.setVisible(true);S53.setVisible(true);S54.setVisible(true);S55.setVisible(true);
              	   }
              	   if(seats==56)
              	   {
              		   S1.setVisible(true);S2.setVisible(true);S3.setVisible(true);S4.setVisible(true);S4.setVisible(true);S5.setVisible(true);S6.setVisible(true);
              		   S7.setVisible(true);S8.setVisible(true);S9.setVisible(true);S10.setVisible(true);S11.setVisible(true);S12.setVisible(true);S13.setVisible(true);
              		   S14.setVisible(true);S15.setVisible(true);S16.setVisible(true);S17.setVisible(true);S18.setVisible(true);S19.setVisible(true);S20.setVisible(true);
              		   S21.setVisible(true);S22.setVisible(true);S23.setVisible(true);S24.setVisible(true);S25.setVisible(true);S26.setVisible(true);S27.setVisible(true);
              		   S28.setVisible(true);S29.setVisible(true);S30.setVisible(true);S31.setVisible(true);S32.setVisible(true);S33.setVisible(true);S34.setVisible(true);
              		   S35.setVisible(true);S36.setVisible(true);S37.setVisible(true);S38.setVisible(true);S39.setVisible(true);S40.setVisible(true);S41.setVisible(true);
              		   S42.setVisible(true);S43.setVisible(true);S44.setVisible(true);S45.setVisible(true);S46.setVisible(true);S47.setVisible(true);S48.setVisible(true);
              		   S49.setVisible(true);S50.setVisible(true);S51.setVisible(true);S52.setVisible(true);S53.setVisible(true);S54.setVisible(true);S55.setVisible(true);
              		   S56.setVisible(true);
              	   }
              	   
              	   }  
              	   
                
               
      			}
        		catch (ClassNotFoundException e1) {
                  // TODO Auto-generated catch block
                  e1.printStackTrace();
              } catch (SQLException e1) {
                  // TODO Auto-generated catch block
                  e1.printStackTrace();
              }
        		
        		
            	try {
                    Class.forName("com.mysql.jdbc.Driver");
                    Connection con = DriverManager.getConnection("jdbc:mysql://localhost:3306/airline", "root", "root");
                    Statement stmt = con.createStatement();
                    String sql1 = "select * from reserve where class='"+sc.getText()+"' AND fid='"+fid.getText()+"'and doj='"+doj.getText()+"'";						//Refine the search by adding flightID and coach type
                    rs = stmt.executeQuery(sql1);
                    while (rs.next()) {

                        int check = Integer.parseInt(rs.getString("seatid"));
                        switch (check) {
                            case 1: {
                                S1.setEnabled(false);
                                S1.setBackground(Color.yellow);
                                break;
                            }
                            case 2: {
                                S2.setEnabled(false);
                                S2.setBackground(Color.yellow);
                                break;
                            }
                            case 3: {
                                S3.setEnabled(false);
                                S3.setBackground(Color.yellow);
                                break;
                            }
                            case 4: {
                                S4.setEnabled(false);
                                S4.setBackground(Color.yellow);
                                break;
                            }
                            case 5: {
                                S5.setEnabled(false);
                                S5.setBackground(Color.yellow);
                                break;
                            }
                            case 6: {
                                S6.setEnabled(false);
                                S6.setBackground(Color.yellow);
                                break;
                            }
                            case 7: {
                                S7.setEnabled(false);
                                S7.setBackground(Color.yellow);
                                break;
                            }
                            case 8: {
                                S8.setEnabled(false);
                                S8.setBackground(Color.yellow);
                                break;
                            }
                            case 9: {
                                S9.setEnabled(false);
                                S9.setBackground(Color.yellow);
                                break;
                            }
                            case 10:{
                                S10.setEnabled(false);
                                S10.setBackground(Color.yellow);
                                break;
                            }
                            case 11: {
                                S11.setEnabled(false);
                                S11.setBackground(Color.yellow);
                                break;
                            }
                            case 12: {
                                S12.setEnabled(false);
                                S12.setBackground(Color.yellow);
                                break;
                            }
                            case 13: {
                                S13.setEnabled(false);
                                S13.setBackground(Color.yellow);
                                break;
                            }
                            case 14: {
                                S14.setEnabled(false);
                                S14.setBackground(Color.yellow);
                                break;
                            }
                            case 15: {
                                S15.setEnabled(false);
                                S15.setBackground(Color.yellow);
                                break;
                            }
                            case 16: {
                                S16.setEnabled(false);
                                S16.setBackground(Color.yellow);
                                break;
                            }
                            case 17: {
                                S17.setEnabled(false);
                                S17.setBackground(Color.yellow);
                                break;
                            }
                            case 18: {
                                S18.setEnabled(false);
                                S18.setBackground(Color.yellow);
                                break;
                            }
                            case 19: {
                                S19.setEnabled(false);
                                S19.setBackground(Color.yellow);
                                break;
                            }
                            case 20: {
                                S20.setEnabled(false);
                                S20.setBackground(Color.yellow);
                                break;
                            }
                            case 21: {
                                S21.setEnabled(false);
                                S21.setBackground(Color.yellow);
                                break;
                            }
                            case 22: {
                                S22.setEnabled(false);
                                S22.setBackground(Color.yellow);
                                break;
                            }
                            case 23: {
                                S23.setEnabled(false);
                                S23.setBackground(Color.yellow);
                                break;
                            }
                            case 24: {
                                S24.setEnabled(false);
                                S24.setBackground(Color.yellow);
                                break;
                            }
                            case 25: {
                                S25.setEnabled(false);
                                S25.setBackground(Color.yellow);
                                break;
                            }
                            case 26: {
                                S26.setEnabled(false);
                                S26.setBackground(Color.yellow);
                                break;
                            }
                            case 27: {
                                S27.setEnabled(false);
                                S27.setBackground(Color.yellow);
                                break;
                            }
                            case 28: {
                                S28.setEnabled(false);
                                S28.setBackground(Color.yellow);
                                break;
                            }
                            case 29: {
                                S29.setEnabled(false);
                                S29.setBackground(Color.yellow);
                                break;
                            }
                            case 30: {
                                S30.setEnabled(false);
                                S30.setBackground(Color.yellow);
                                break;
                            }
                            case 31: {
                                S31.setEnabled(false);
                                S31.setBackground(Color.yellow);
                                break;
                            }
                            case 32: {
                                S32.setEnabled(false);
                                S32.setBackground(Color.yellow);
                                break;
                            }
                            case 33: {
                                S33.setEnabled(false);
                                S33.setBackground(Color.yellow);
                                break;
                            }
                            case 34: {
                                S34.setEnabled(false);
                                S34.setBackground(Color.yellow);
                                break;
                            }
                            case 35: {
                                S35.setEnabled(false);
                                S35.setBackground(Color.yellow);
                                break;
                            }
                            case 36: {
                                S36.setEnabled(false);
                                S36.setBackground(Color.yellow);
                                break;
                            }
                            case 37: {
                                S37.setEnabled(false);
                                S37.setBackground(Color.yellow);
                                break;
                            }
                            case 38: {
                                S38.setEnabled(false);
                                S38.setBackground(Color.yellow);
                                break;
                            }
                            case 39: {
                                S39.setEnabled(false);
                                S39.setBackground(Color.yellow);
                                break;
                            }
                            case 40: {
                                S40.setEnabled(false);
                                S40.setBackground(Color.yellow);
                                break;
                            }
                            case 41: {
                                S41.setEnabled(false);
                                S41.setBackground(Color.yellow);
                                break;
                            }
                            case 42: {
                                S42.setEnabled(false);
                                S42.setBackground(Color.yellow);
                                break;
                            }
                            case 43: {
                                S43.setEnabled(false);
                                S43.setBackground(Color.yellow);
                                break;
                            }
                            case 44: {
                                S44.setEnabled(false);
                                S44.setBackground(Color.yellow);
                                break;
                            }
                            case 45: {
                                S45.setEnabled(false);
                                S45.setBackground(Color.yellow);
                                break;
                            }
                            case 46: {
                                S46.setEnabled(false);
                                S46.setBackground(Color.yellow);
                                break;
                            }
                            case 47: {
                                S47.setEnabled(false);
                                S47.setBackground(Color.yellow);
                                break;
                            }
                            case 48: {
                                S48.setEnabled(false);
                                S48.setBackground(Color.yellow);
                                break;
                            }
                            case 49: {
                                S49.setEnabled(false);
                                S49.setBackground(Color.yellow);
                                break;
                            }
                            case 50: {
                                S50.setEnabled(false);
                                S50.setBackground(Color.yellow);
                                break;
                            }
                            case 51: {
                                S51.setEnabled(false);
                                S51.setBackground(Color.yellow);
                                break;
                            }
                            case 52: {
                                S52.setEnabled(false);
                                S52.setBackground(Color.yellow);
                                break;
                            }
                            case 53: {
                                S53.setEnabled(false);
                                S53.setBackground(Color.yellow);
                                break;
                            }
                            case 54: {
                                S54.setEnabled(false);
                                S54.setBackground(Color.yellow);
                                break;
                            }
                            case 55: {
                                S55.setEnabled(false);
                                S55.setBackground(Color.yellow);
                                break;
                            }
                            case 56: {
                                S56.setEnabled(false);
                                S56.setBackground(Color.yellow);
                                break;
                            }
                                                  
                        }
                    }
                } catch (ClassNotFoundException e1) {
                    // TODO Auto-generated catch block
                    e1.printStackTrace();
                } catch (SQLException e1) {
                    // TODO Auto-generated catch block
                    e1.printStackTrace();
                }
        	}
        });
        button_2.setBounds(323, 55, 116, 25);
        classpanel.add(button_2);
        
        sc = new JTextField();
        sc.setEditable(false);
        sc.setForeground(Color.WHITE);
        sc.setHorizontalAlignment(SwingConstants.CENTER);
        sc.setFont(new Font("Times New Roman", Font.BOLD, 16));
        sc.setBackground(Color.LIGHT_GRAY);
        sc.setBounds(188, 13, 116, 22);
        classpanel.add(sc);
        sc.setColumns(10);
        sc.setVisible(false);
        
        ta = new JTextField();
        ta.setHorizontalAlignment(SwingConstants.CENTER);
        ta.setFont(new Font("Times New Roman", Font.BOLD, 16));
        ta.setEditable(false);
        ta.setBounds(188, 13, 116, 22);
        classpanel.add(ta);
        ta.setColumns(10);
        
        JLabel lblNewLabel_1 = new JLabel("Availability");
        lblNewLabel_1.setHorizontalAlignment(SwingConstants.CENTER);
        lblNewLabel_1.setFont(new Font("Times New Roman", Font.BOLD, 16));
        lblNewLabel_1.setBounds(86, 13, 90, 29);
        classpanel.add(lblNewLabel_1);
        
      
        
        
        

        
        
        
        JScrollPane scrollPane = new JScrollPane();
        scrollPane.setBounds(22, 133, 587, 231);
        frame.getContentPane().add(scrollPane);
        
        search = new JTable();
        scrollPane.setColumnHeaderView(search);
        search.setFont(new Font("Times New Roman", Font.BOLD, 16));
        search.addMouseListener(new MouseAdapter() {
        	@Override
        	public void mouseClicked(MouseEvent arg0) {
        			int booked=0,avail=0,ts=0;
        			classpanel.setVisible(true);
        			seatpanel.setVisible(true);
        			submit.setVisible(true);
        			doj.setText(dateofjourney.getText());
        			DefaultTableModel model =(DefaultTableModel)search.getModel();
            		int selectedRowIndex =search.getSelectedRow(); 
            		fid.setText(model.getValueAt(selectedRowIndex, 0).toString());
            		fname.setText(model.getValueAt(selectedRowIndex, 1).toString());
            		board.setText(model.getValueAt(selectedRowIndex, 2).toString());
            		dt.setText(model.getValueAt(selectedRowIndex, 3).toString());
            		destination.setText(model.getValueAt(selectedRowIndex, 4).toString());
            		at.setText(model.getValueAt(selectedRowIndex, 5).toString());
            		
        		try {
					Class.forName("com.mysql.jdbc.Driver");
					Connection con=DriverManager.getConnection("jdbc:mysql://localhost:3306/airline","root","root");
					Statement stmt=con.createStatement();
					String sql1="select * from reserve where fid='"+fid.getText()+"' and doj='"+doj.getText()+"'";
					rs=stmt.executeQuery(sql1);
					while(rs.next())
					{
						booked++;
					
					}
					String sql2="select * from flightdetails where fid='"+fid.getText()+"'";
					rs=stmt.executeQuery(sql2);
        		while(rs.next())
        		{
        			ts=Integer.parseInt(rs.getString("ts"));
        		}
//					
					avail=ts-booked;
					ta.setText(String.valueOf(avail));
					
//						
					
				} catch (ClassNotFoundException e11) {
					// TODO Auto-generated catch block
					e11.printStackTrace();
				} catch (SQLException e1) {
					// TODO Auto-generated catch block
					e1.printStackTrace();
				}
        		
        		
        		
        		
        		}
        });
        search.setBorder(new BevelBorder(BevelBorder.LOWERED, null, null, null, null));
        search.setModel(new DefaultTableModel(
        	new Object[][] {
        		{null, null, null, null, null, null},
        	},
        	new String[] {
        		"fid", "fname", "source", "dt", "dest", "at"
        	}
        ));
        
        JPanel panel = new JPanel();
        panel.setLayout(null);
        panel.setBorder(new BevelBorder(BevelBorder.LOWERED, new Color(135, 206, 250), new Color(135, 206, 250), new Color(135, 206, 250), new Color(135, 206, 250)));
        panel.setBackground(new Color(211, 211, 211));
        panel.setBounds(0, 0, 1332, 52);
        frame.getContentPane().add(panel);
        
        time = new JLabel("");
        time.setHorizontalAlignment(SwingConstants.CENTER);
        time.setFont(new Font("Times New Roman", Font.BOLD, 26));
        time.setBounds(692, 0, 316, 49);
        panel.add(time);
        
        date = new JLabel("");
        date.setHorizontalAlignment(SwingConstants.CENTER);
        date.setFont(new Font("Times New Roman", Font.BOLD, 26));
        date.setBounds(359, 0, 320, 50);
        panel.add(date);
        
        JLabel lblBooking = new JLabel("Reservation");
        lblBooking.setHorizontalAlignment(SwingConstants.CENTER);
        lblBooking.setIcon(new ImageIcon(Booking.class.getResource("/airlineimages/ticketbook.png")));
        lblBooking.setFont(new Font("Times New Roman", Font.BOLD, 28));
        lblBooking.setBounds(96, -3, 335, 52);
        panel.add(lblBooking);
        
        JButton back = new JButton("Back");
        back.addActionListener(new ActionListener() {
        	public void actionPerformed(ActionEvent arg0) {
        		
        		HomePage.HomePage();
        	}
        });
        back.setFont(new Font("Times New Roman", Font.BOLD, 15));
        back.setIcon(new ImageIcon(Booking.class.getResource("/airlineimages/back1.png")));
        back.setBounds(0, 0, 131, 49);
        panel.add(back);
        
 
        
        
        
    }
}
