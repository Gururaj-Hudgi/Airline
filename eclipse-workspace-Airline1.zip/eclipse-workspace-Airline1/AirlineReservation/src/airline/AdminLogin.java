package airline;

import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.JLabel;
import javax.swing.JOptionPane;

import java.awt.Font;
import javax.swing.ImageIcon;
import javax.swing.border.BevelBorder;
import java.awt.Color;
import javax.swing.JTextField;
import javax.swing.JButton;
import javax.swing.SwingConstants;
import java.awt.event.ActionListener;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.Statement;
import java.util.Calendar;
import java.util.GregorianCalendar;
import java.awt.event.ActionEvent;

public class AdminLogin {

	private JFrame frame;
	private final JPanel panel = new JPanel();
	private JLabel lblAdminName;
	private JTextField aname;
	private JLabel lblNewLabel;
	private JTextField apass;
	private JButton btnLogin;
	private JLabel date;
	private JLabel time;

	/**
	 * Launch the application.
	 */
	public static void AdminLogin() {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					AdminLogin window = new AdminLogin();
					window.frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the application.
	 */
	
	private void clock()
	{
		
		Thread clock = new Thread()
				{
					public void run()
					{
						for(;;)
						{	
							Calendar cal=new GregorianCalendar();
							int month=cal.get(Calendar.MONTH)+1;
							int year=cal.get(Calendar.YEAR);
							int day=cal.get(Calendar.DAY_OF_MONTH);
							date.setText("Date: "+day+"/"+month+"/"+year);
							
							int second =cal.get(Calendar.SECOND);
							int minute =cal.get(Calendar.MINUTE);
							int hour =cal.get(Calendar.HOUR_OF_DAY);
							time.setText("Time: "+hour+":"+minute+":"+second);
							try {
								sleep(1000);
							} catch (InterruptedException e) {
								// TODO Auto-generated catch block
								e.printStackTrace();
							}
						}
					}
				};
				clock.start();
	}
	public AdminLogin() {
		initialize();
		clock();
	}

	/**
	 * Initialize the contents of the frame.
	 */
	private void initialize() {
		frame = new JFrame();
		frame.getContentPane().setBackground(new Color(240,245,255));
		frame.setBounds(300, 100, 1350, 870);
		frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		frame.getContentPane().setLayout(null);
		panel.setBackground(new Color(211,211,211));
		panel.setBorder(new BevelBorder(BevelBorder.LOWERED, new Color(135, 206, 250), new Color(135, 206, 250), new Color(135, 206, 250), new Color(135, 206, 250)));
		panel.setBounds(0, 0, 1332, 76);
		frame.getContentPane().add(panel);
		panel.setLayout(null);
		
		time = new JLabel("");
		time.setBounds(692, 15, 316, 49);
		panel.add(time);
		time.setHorizontalAlignment(SwingConstants.CENTER);
		time.setFont(new Font("Times New Roman", Font.BOLD, 26));
		
		date = new JLabel("");
		date.setBounds(362, 15, 320, 50);
		panel.add(date);
		date.setHorizontalAlignment(SwingConstants.CENTER);
		date.setFont(new Font("Times New Roman", Font.BOLD, 26));
		
		JLabel lblAdminLogin = new JLabel("Admin Login");
		lblAdminLogin.setIcon(new ImageIcon(AdminLogin.class.getResource("/airlineimages/admin1.png")));
		lblAdminLogin.setFont(new Font("Tahoma", Font.BOLD, 30));
		lblAdminLogin.setBounds(62, 11, 273, 54);
		panel.add(lblAdminLogin);
		
		lblAdminName = new JLabel("Admin Name");
		lblAdminName.setHorizontalAlignment(SwingConstants.TRAILING);
		lblAdminName.setFont(new Font("Times New Roman", Font.BOLD, 20));
		lblAdminName.setBounds(259, 348, 148, 57);
		frame.getContentPane().add(lblAdminName);
		
		aname = new JTextField();
		aname.setBounds(612, 361, 225, 34);
		frame.getContentPane().add(aname);
		aname.setColumns(10);
		
		lblNewLabel = new JLabel("Admin Password");
		lblNewLabel.setHorizontalAlignment(SwingConstants.TRAILING);
		lblNewLabel.setFont(new Font("Times New Roman", Font.BOLD, 20));
		lblNewLabel.setBounds(291, 394, 148, 59);
		frame.getContentPane().add(lblNewLabel);
		
		apass = new JTextField();
		apass.setBounds(612, 408, 225, 34);
		frame.getContentPane().add(apass);
		apass.setColumns(10);
		
		btnLogin = new JButton("Login");
		btnLogin.setIcon(new ImageIcon(AdminLogin.class.getResource("/airlineimages/admin.png")));
		btnLogin.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
			
				try{
					
					Class.forName("com.mysql.jdbc.Driver");
					Connection con=DriverManager.getConnection("jdbc:mysql://localhost:3306/airline","root","root");
					Statement st=con.createStatement();
					String sql="Select * from admin where aname='"+aname.getText()+"' and apass='"+apass.getText().toString()+"'";
					ResultSet rs=st.executeQuery(sql);
					if(rs.next()){
						JOptionPane.showMessageDialog(null,"Login Sucessfully...");
						AdminMenu.AdminMenu();
						
					}
						else{
							JOptionPane.showMessageDialog(null,"Incorrect username and password");}
					con.close();
				}
				catch(Exception e1)
				{
					System.out.println(e1);
					}
			}
			
		});
		btnLogin.setFont(new Font("Times New Roman", Font.BOLD, 20));
		btnLogin.setBounds(481, 522, 160, 59);
		frame.getContentPane().add(btnLogin);
		
		JButton button = new JButton("Back");
		button.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				HomePage.HomePage();
			}
		});
		button.setIcon(new ImageIcon("C:\\Users\\lenovo\\Downloads\\eclipse-workspace-Airline1\\AirlineReservation\\src\\airlineimages\\back1.png"));
		button.setFont(new Font("Times New Roman", Font.BOLD, 20));
		button.setBounds(0, 782, 130, 41);
		frame.getContentPane().add(button);
	}
}
