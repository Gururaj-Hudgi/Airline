package airline;

import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.ImageIcon;
import java.awt.Font;
import javax.swing.JTextField;
import javax.swing.JPasswordField;
import javax.swing.JButton;
import java.awt.Color;
import javax.swing.border.BevelBorder;
import javax.swing.SwingConstants;
import java.awt.event.ActionListener;
import java.sql.*;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.Statement;
import java.util.Calendar;
import java.util.GregorianCalendar;
import java.awt.event.ActionEvent;

public class UserLogin {

	private JFrame frame;
	protected JTextField cname;
	private JPasswordField upass;
	private String temp;
	private JLabel date;
	private JLabel time;
	/**
	 * Launch the application.
	 */
	public static void UserLogin() {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					UserLogin window = new UserLogin();
					window.frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the application.
	 */
	
	private void clock()
	{
		
		Thread clock = new Thread()
				{
					public void run()
					{
						for(;;)
						{	
							Calendar cal=new GregorianCalendar();
							int month=cal.get(Calendar.MONTH)+1;
							int year=cal.get(Calendar.YEAR);
							int day=cal.get(Calendar.DAY_OF_MONTH);
							date.setText("Date: "+day+"/"+month+"/"+year);
							
							int second =cal.get(Calendar.SECOND);
							int minute =cal.get(Calendar.MINUTE);
							int hour =cal.get(Calendar.HOUR_OF_DAY);
							time.setText("Time: "+hour+":"+minute+":"+second);
							try {
								sleep(1000);
							} catch (InterruptedException e) {
								// TODO Auto-generated catch block
								e.printStackTrace();
							}
						}
					}
				};
				clock.start();
	}
	
	public UserLogin() {
		initialize();
		clock();
	}

	/**
	 * Initialize the contents of the frame.
	 */
	private void initialize() {
		frame = new JFrame();
		frame.setTitle("T9 Airllines Pvt Ltd.");
		frame.getContentPane().setBackground(new Color(240, 248, 255));
		frame.setBounds(300, 100, 1350, 870);
		frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		frame.getContentPane().setLayout(null);
		
		JPanel panel = new JPanel();
		panel.setBorder(new BevelBorder(BevelBorder.LOWERED, new Color(135, 206, 250), new Color(135, 206, 250), new Color(135, 206, 250), new Color(135, 206, 235)));
		panel.setBackground(new Color(211, 211, 211));
		panel.setBounds(0, 0, 1332, 74);
		frame.getContentPane().add(panel);
		panel.setLayout(null);
		
		time = new JLabel("");
		time.setHorizontalAlignment(SwingConstants.CENTER);
		time.setFont(new Font("Times New Roman", Font.BOLD, 26));
		time.setBounds(671, 11, 316, 49);
		panel.add(time);
		
		date = new JLabel("");
		date.setHorizontalAlignment(SwingConstants.CENTER);
		date.setFont(new Font("Times New Roman", Font.BOLD, 26));
		date.setBounds(341, 11, 320, 50);
		panel.add(date);
		
		JLabel lblNewLabel = new JLabel("User Login");
		lblNewLabel.setFont(new Font("Tahoma", Font.BOLD, 30));
		lblNewLabel.setIcon(new ImageIcon(UserLogin.class.getResource("/airlineimages/man-icon.png")));
		lblNewLabel.setBounds(30, 11, 223, 52);
		panel.add(lblNewLabel);
		
		JLabel lblUserName = new JLabel("User Name");
		lblUserName.setHorizontalAlignment(SwingConstants.CENTER);
		lblUserName.setFont(new Font("Sitka Subheading", Font.BOLD, 26));
		lblUserName.setBounds(137, 303, 474, 41);
		frame.getContentPane().add(lblUserName);
		
		JLabel lblPassword = new JLabel("Password");
		lblPassword.setHorizontalAlignment(SwingConstants.CENTER);
		lblPassword.setFont(new Font("Sitka Subheading", Font.BOLD, 26));
		lblPassword.setBounds(137, 357, 474, 41);
		frame.getContentPane().add(lblPassword);
		
		cname = new JTextField();
		cname.setBounds(623, 303, 306, 41);
		frame.getContentPane().add(cname);
		cname.setColumns(10);
		
		upass = new JPasswordField();
		upass.setBounds(623, 359, 306, 41);
		frame.getContentPane().add(upass);
		
		JButton btnLogin = new JButton("Login\r\n");
		btnLogin.setIcon(new ImageIcon(UserLogin.class.getResource("/airlineimages/man-icon.png")));
		btnLogin.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
							{
				try{
					
					Class.forName("com.mysql.jdbc.Driver");
					Connection con=DriverManager.getConnection("jdbc:mysql://localhost:3306/airline","root","root");
					Statement st=con.createStatement();
					String sql="Select * from NewRegistration where cname='"+cname.getText()+"' and upass='"+upass.getText().toString()+"'";
					ResultSet rs=st.executeQuery(sql);
					if(rs.next()){
						JOptionPane.showMessageDialog(null,"Login Sucessfully...");
						
						UserMenu.UserMenu();
						
					}
						else{
							JOptionPane.showMessageDialog(null,"Incorrect username and password");}
					con.close();
				}
				catch(Exception e)
				{
					System.out.println(e);
					}
				}
			}
				
				
			
		});
		btnLogin.setFont(new Font("Times New Roman", Font.BOLD, 30));
		btnLogin.setBounds(544, 461, 174, 57);
		frame.getContentPane().add(btnLogin);
		
		JButton btnNewButton = new JButton("Back");
		btnNewButton.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				
				HomePage.HomePage();
			}
		});
		btnNewButton.setFont(new Font("Sitka Banner", Font.BOLD, 26));
		btnNewButton.setIcon(new ImageIcon(UserLogin.class.getResource("/airlineimages/back1.png")));
		btnNewButton.setBounds(0, 782, 135, 41);
		frame.getContentPane().add(btnNewButton);
	}
}
