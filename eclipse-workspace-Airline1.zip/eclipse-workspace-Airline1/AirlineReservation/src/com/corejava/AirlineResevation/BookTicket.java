package com.corejava.AirlineResevation;

import java.awt.EventQueue;
import java.sql.*;

import javax.swing.AbstractButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;

import java.awt.Font;
import javax.swing.JTextField;
import javax.swing.JComboBox;
import com.toedter.calendar.JDateChooser;
import javax.swing.JRadioButton;
import javax.swing.JButton;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.Statement;
import java.util.Enumeration;
import javax.swing.ButtonGroup;
import javax.swing.DefaultComboBoxModel;

public class BookTicket {

	java.util.Date date;
	java.sql.Date sqldate;
	
	private JFrame frame;
	private JTextField pname;
	private JTextField source;
	private JTextField age;
	private JTextField dest;
	private final ButtonGroup buttonGroup = new ButtonGroup();

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					BookTicket window = new BookTicket();
					window.frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the application.
	 */
	public BookTicket() {
		initialize();
	}

	/**
	 * Initialize the contents of the frame.
	 */
	private void initialize() {
		frame = new JFrame();
		frame.setBounds(10, -45, 985, 527);
		frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		frame.getContentPane().setLayout(null);
		
		JLabel lblBookTicket = new JLabel("BOOK TICKET");
		lblBookTicket.setFont(new Font("Times New Roman", Font.BOLD, 22));
		lblBookTicket.setBounds(240, 72, 305, 32);
		frame.getContentPane().add(lblBookTicket);
		
		JLabel lblPassengerName = new JLabel("PASSENGER NAME");
		lblPassengerName.setFont(new Font("Times New Roman", Font.PLAIN, 15));
		lblPassengerName.setBounds(69, 157, 162, 32);
		frame.getContentPane().add(lblPassengerName);
		
		JLabel lblSource = new JLabel("SOURCE");
		lblSource.setFont(new Font("Times New Roman", Font.PLAIN, 15));
		lblSource.setBounds(69, 204, 68, 16);
		frame.getContentPane().add(lblSource);
		
		JLabel lblAge = new JLabel("AGE");
		lblAge.setFont(new Font("Times New Roman", Font.PLAIN, 15));
		lblAge.setBounds(69, 249, 56, 16);
		frame.getContentPane().add(lblAge);
		
		JLabel lblClass = new JLabel("CLASS");
		lblClass.setFont(new Font("Times New Roman", Font.PLAIN, 15));
		lblClass.setBounds(69, 286, 56, 16);
		frame.getContentPane().add(lblClass);
		
		JLabel lblNewLabel = new JLabel("DATE OF BOARDING");
		lblNewLabel.setFont(new Font("Times New Roman", Font.PLAIN, 15));
		lblNewLabel.setBounds(69, 324, 146, 32);
		frame.getContentPane().add(lblNewLabel);
		
		pname = new JTextField();
		pname.setBounds(293, 162, 252, 22);
		frame.getContentPane().add(pname);
		pname.setColumns(10);
		
		source = new JTextField();
		source.setBounds(293, 201, 116, 22);
		frame.getContentPane().add(source);
		source.setColumns(10);
		
		age = new JTextField();
		age.setBounds(293, 236, 116, 22);
		frame.getContentPane().add(age);
		age.setColumns(10);
		
		final JComboBox ctype = new JComboBox();
		ctype.setModel(new DefaultComboBoxModel(new String[] {"Economy", "ABC", "QWERTY"}));
		ctype.setBounds(293, 283, 116, 22);
		frame.getContentPane().add(ctype);
		
		final JDateChooser Date = new JDateChooser();
		Date.setBounds(293, 336, 116, 22);
		frame.getContentPane().add(Date);
		
		JLabel lblDestination = new JLabel("DESTINATION");
		lblDestination.setFont(new Font("Times New Roman", Font.PLAIN, 15));
		lblDestination.setBounds(562, 204, 116, 16);
		frame.getContentPane().add(lblDestination);
		
		dest = new JTextField();
		dest.setBounds(769, 201, 116, 22);
		frame.getContentPane().add(dest);
		dest.setColumns(10);
		
		JLabel lblGender = new JLabel("GENDER");
		lblGender.setFont(new Font("Times New Roman", Font.PLAIN, 15));
		lblGender.setBounds(562, 249, 116, 16);
		frame.getContentPane().add(lblGender);
		
		JRadioButton male = new JRadioButton("MALE");
		male.setSelected(true);
		buttonGroup.add(male);
		male.setBounds(758, 245, 86, 25);
		frame.getContentPane().add(male);
		
		JRadioButton female = new JRadioButton("FEMALE");
		buttonGroup.add(female);
		female.setBounds(848, 245, 98, 25);
		frame.getContentPane().add(female);
		
		JButton btnBookTicket = new JButton("BOOK TICKET");
		btnBookTicket.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				PreparedStatement pst=null;
				Connection con=null;
				ResultSet rs=null;
				Statement stmt=null;
				
				try{
					Class.forName("com.mysql.jdbc.Driver");
					con=DriverManager.getConnection("jdbc:mysql://localhost:3306/airline","root","root");
					stmt=con.createStatement();
					date =Date.getDate();
					sqldate =new java.sql.Date(date.getTime());
					
				
				Enumeration<AbstractButton> bg = buttonGroup.getElements();
				
				
					JRadioButton rdbtnMale = (JRadioButton) bg.nextElement();
					if(rdbtnMale.isSelected())
					{
					
						String sql="insert into bookticket(pname,source,age,ctype,Date,dest,gender) values ('"+pname.getText()+"','"+source.getText()+"','"+age.getText()+"','"+ctype.getSelectedItem().toString()+"','"+sqldate+"','"+dest.getText()+"','male')";
						stmt.executeUpdate(sql);
					}
					else
					{
						String sql="insert into bookticket(pname,source,age,ctype,Date,dest,gender) values ('"+pname.getText()+"','"+source.getText()+"','"+age.getText()+"','"+ctype.getSelectedItem().toString()+"','"+sqldate+"','"+dest.getText()+"','female')";
						stmt.executeUpdate(sql);
					}
					
					JOptionPane.showMessageDialog(null,"Your ticket is Booked");
					
				}

					
				catch(Exception e)
				{
					System.out.println(e);
				}
			}
		});
		btnBookTicket.setFont(new Font("Times New Roman", Font.PLAIN, 15));
		btnBookTicket.setBounds(404, 414, 154, 44);
		frame.getContentPane().add(btnBookTicket);
	}


}
