package airline;

import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.JLabel;
import javax.swing.JDesktopPane;
import javax.swing.ImageIcon;
import java.awt.Font;
import javax.swing.JButton;
import javax.swing.SwingConstants;
import java.awt.SystemColor;
import java.awt.Color;
import javax.swing.border.BevelBorder;
import org.eclipse.wb.swing.FocusTraversalOnArray;
import java.awt.Component;
import java.awt.event.ActionListener;
import java.util.Calendar;
import java.util.GregorianCalendar;
import java.awt.event.ActionEvent;
import javax.swing.GroupLayout;
import javax.swing.GroupLayout.Alignment;
import javax.swing.LayoutStyle.ComponentPlacement;

public class HomePage {

	private JFrame frame;
	private JLabel time;
	private JLabel date;
	/**
	 * Launch the application.
	 */
	
	private void clock()
	{
		
		Thread clock = new Thread()
				{
					public void run()
					{
						for(;;)
						{	
							Calendar cal=new GregorianCalendar();
							int month=cal.get(Calendar.MONTH)+1;
							int year=cal.get(Calendar.YEAR);
							int day=cal.get(Calendar.DAY_OF_MONTH);
							date.setText("Date: "+day+"/"+month+"/"+year);
							
							int second =cal.get(Calendar.SECOND);
							int minute =cal.get(Calendar.MINUTE);
							int hour =cal.get(Calendar.HOUR_OF_DAY);
							time.setText("Time: "+hour+":"+minute+":"+second);
							try {
								sleep(1000);
							} catch (InterruptedException e) {
								// TODO Auto-generated catch block
								e.printStackTrace();
							}
						}
					}
				};
				clock.start();
	}
	
	public static void HomePage() {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					HomePage window = new HomePage();
					window.frame.setVisible(true);
//					window.frame.setExtendedState(JFrame.MAXIMIZED_BOTH);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the application.
	 */
	public HomePage() {
		initialize();
		clock();
	}

	/**
	 * Initialize the contents of the frame.
	 */
	private void initialize() {
		frame = new JFrame();
		frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		frame.getContentPane().setBackground(new Color(240, 248, 255));
		frame.setBounds(300, 100, 1350, 870);
		
		JButton btnRegistration = new JButton(" Registration");
		btnRegistration.setBounds(1009, 410, 248, 65);
		btnRegistration.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				
				Registration.Registration();
			}
		});
		btnRegistration.setBackground(SystemColor.activeCaption);
		btnRegistration.setFont(new Font("Times New Roman", Font.BOLD, 24));
		btnRegistration.setIcon(new ImageIcon(HomePage.class.getResource("/airlineimages/regist.png")));
		
		JButton btnUserLogin = new JButton("User Login");
		btnUserLogin.setBounds(1009, 306, 248, 65);
		btnUserLogin.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				
				UserLogin.UserLogin();
			}
		});
		btnUserLogin.setBackground(SystemColor.activeCaption);
		btnUserLogin.setFont(new Font("Times New Roman", Font.BOLD, 24));
		btnUserLogin.setIcon(new ImageIcon(HomePage.class.getResource("/airlineimages/user.png")));
		
		JButton btnAdminLogin = new JButton("Admin Login");
		btnAdminLogin.setBounds(720, 306, 248, 65);
		btnAdminLogin.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				
				AdminLogin.AdminLogin();
			}
		});
		btnAdminLogin.setBackground(SystemColor.activeCaption);
		btnAdminLogin.setFont(new Font("Times New Roman", Font.BOLD, 24));
		btnAdminLogin.setIcon(new ImageIcon(HomePage.class.getResource("/airlineimages/admin.png")));
		
		JPanel panel_1 = new JPanel();
		panel_1.setBounds(29, 140, 653, 577);
		
		JLabel lblWelcomeToAirline = new JLabel("");
		lblWelcomeToAirline.setBounds(0, 0, 653, 577);
		lblWelcomeToAirline.setHorizontalAlignment(SwingConstants.CENTER);
		lblWelcomeToAirline.setToolTipText("");
		lblWelcomeToAirline.setIcon(new ImageIcon(HomePage.class.getResource("/airlineimages/air.png")));
		lblWelcomeToAirline.setBackground(new Color(176, 224, 230));
		lblWelcomeToAirline.setFont(new Font("Tahoma", Font.BOLD, 17));
		panel_1.setFocusTraversalPolicy(new FocusTraversalOnArray(new Component[]{lblWelcomeToAirline}));
		
		JPanel panel = new JPanel();
		panel.setBounds(0, 0, 1332, 95);
		panel.setBorder(new BevelBorder(BevelBorder.RAISED, new Color(119, 136, 153), new Color(119, 136, 153), new Color(119, 136, 153), new Color(119, 136, 153)));
		
		JLabel lblNewLabel = new JLabel("  Airline Reservation System");
		lblNewLabel.setBounds(2, 2, 505, 91);
		lblNewLabel.setBackground(SystemColor.activeCaption);
		lblNewLabel.setFont(new Font("Tahoma", Font.BOLD, 30));
		lblNewLabel.setIcon(new ImageIcon(HomePage.class.getResource("/airlineimages/home.png")));
		panel_1.setLayout(null);
		panel_1.add(lblWelcomeToAirline);
		frame.getContentPane().setLayout(null);
		panel.setLayout(null);
		panel.add(lblNewLabel);
		frame.getContentPane().add(panel);
		
		time = new JLabel("");
		time.setHorizontalAlignment(SwingConstants.CENTER);
		time.setFont(new Font("Times New Roman", Font.BOLD, 26));
		time.setBounds(849, 21, 316, 61);
		panel.add(time);
		
		date = new JLabel("");
		date.setHorizontalAlignment(SwingConstants.CENTER);
		date.setFont(new Font("Times New Roman", Font.BOLD, 26));
		date.setBounds(519, 21, 320, 61);
		panel.add(date);
		frame.getContentPane().add(panel_1);
		frame.getContentPane().add(btnRegistration);
		frame.getContentPane().add(btnUserLogin);
		frame.getContentPane().add(btnAdminLogin);
		
		JButton btnGuestBooking = new JButton("Guest Booking");
		btnGuestBooking.setIcon(new ImageIcon(HomePage.class.getResource("/airlineimages/ticket.png")));
		btnGuestBooking.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				
				Booking.Booking();
			}
		});
		btnGuestBooking.setFont(new Font("Times New Roman", Font.BOLD, 24));
		btnGuestBooking.setBackground(SystemColor.activeCaption);
		btnGuestBooking.setBounds(720, 410, 248, 65);
		frame.getContentPane().add(btnGuestBooking);
	}
}
