
//**************No Use************************//



package com.corejava.AirlineResevation;

import java.awt.EventQueue;
import java.awt.event.*;
import javax.swing.*;
import java.sql.*;
import java.awt.event.ActionListener;

import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JTextField;
import javax.swing.JButton;

public class Work extends JFrame implements ActionListener{

	private JFrame frame;
	private JTextField id;
	private JTextField name;
	private JTextField lname;
	private JTextField age;

	/**
	 * Launch the application.
	 */
	public void actionPerformed(ActionEvent e)
	{
		Function f= new Function();
		ResultSet rs=null;
		String fname= "name";
		String ltname= "lname";
		String cage= "age";
		
		rs = f.find(id.getText());
		try{
			if(rs.next())
			{
				name.setText(rs.getString("name"));
				lname.setText(rs.getString("lname"));
				age.setText(rs.getString("age"));
				
				
			}
			else{
				JOptionPane.showMessageDialog(null,"No data for this id");
			}
		}
		catch(Exception ex)
		{
			JOptionPane.showMessageDialog(null,ex.getMessage());
		}
	}
	
	public class Function
	{
		Connection con = null;
		ResultSet rs = null;
		PreparedStatement pst = null;
		public ResultSet find(String s){
			try{
			Class.forName("com.mysql.jdbc.Driver");
			con = DriverManager.getConnection("jdbc:mysql://localhost:3306/airline","root","root");
			
			pst = con.prepareStatement("select * from info where id=?");
			pst.setString(1,s);
			rs = pst.executeQuery();
			}
			catch(Exception e)
			{
				JOptionPane.showMessageDialog(null,e.getMessage());
			}
			return rs;
		}
		
		
	}
	public static void main(String[] args) {
		new Work();
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					Work window = new Work();
					window.frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the application.
	 */
	public Work() {
		initialize();
			
	}

	/**
	 * Initialize the contents of the frame.
	 */
	private void initialize() {
		frame = new JFrame();
		frame.setBounds(100, 100, 583, 300);
		frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		frame.getContentPane().setLayout(null);
		
		JLabel lblId = new JLabel("id");
		lblId.setBounds(53, 59, 56, 16);
		frame.getContentPane().add(lblId);
		
		JLabel lblName = new JLabel("name");
		lblName.setBounds(53, 113, 56, 16);
		frame.getContentPane().add(lblName);
		
		JLabel lblLastName = new JLabel("last name");
		lblLastName.setBounds(53, 161, 87, 16);
		frame.getContentPane().add(lblLastName);
		
		JLabel lblAge = new JLabel("age");
		lblAge.setBounds(53, 197, 56, 16);
		frame.getContentPane().add(lblAge);
		
		id = new JTextField();
		id.setBounds(245, 56, 116, 22);
		frame.getContentPane().add(id);
		id.setColumns(10);
		
		name = new JTextField();
		name.setBounds(245, 110, 116, 22);
		frame.getContentPane().add(name);
		name.setColumns(10);
		
		lname = new JTextField();
		lname.setBounds(245, 158, 116, 22);
		frame.getContentPane().add(lname);
		lname.setColumns(10);
		
		age = new JTextField();
		age.setBounds(245, 194, 116, 22);
		frame.getContentPane().add(age);
		age.setColumns(10);
		
		JButton search = new JButton("search");
		search.setBounds(421, 55, 97, 25);
		search.addActionListener(this);
		frame.getContentPane().add(search);
	}
}
