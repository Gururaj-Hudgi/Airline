package airline;



import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.JLabel;
import javax.swing.JOptionPane;

import java.awt.Font;
import java.awt.Image;

import javax.swing.AbstractButton;
import javax.swing.ButtonGroup;
import javax.swing.ImageIcon;
import java.awt.Color;
import javax.swing.border.BevelBorder;
import javax.swing.filechooser.FileNameExtensionFilter;
import javax.swing.JTextField;
import javax.swing.JRadioButton;
import com.toedter.calendar.JCalendar;
import com.toedter.calendar.JDateChooser;
import javax.swing.JCheckBox;
import javax.swing.JTextArea;
import javax.swing.JEditorPane;
import javax.swing.JFileChooser;
import javax.swing.JTextPane;
import java.awt.TextArea;
import javax.swing.JPasswordField;
import javax.swing.JButton;
import java.awt.event.ActionListener;
import java.io.File;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.Statement;
import java.util.*;
import java.awt.event.ActionEvent;
import javax.swing.SwingConstants;

public class Registration {
	
	java.util.Date date;
	java.sql.Date sqldate;

	private JFrame frame;
	private JTextField cname;
	private JTextField phno;
	private JTextField address;
	private final ButtonGroup buttonGroup = new ButtonGroup();
	private JPasswordField upass;
	String s;
	private JTextField cid;
	private JLabel ddate;
	private JLabel dtime;
	
	

	/**
	 * Launch the application.
	 */
	public static void Registration() {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					Registration window = new Registration();
					window.frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the application.
	 */
	
	public void random()
	{
		Random ran =new Random();
		int n = ran.nextInt(1000)+1;
		String val=String.valueOf(n);
		cid.setText(val);
		
	}
	private void clock()
	{
		
		Thread clock = new Thread()
				{
					public void run()
					{
						for(;;)
						{	
							Calendar cal=new GregorianCalendar();
							int month=cal.get(Calendar.MONTH)+1;
							int year=cal.get(Calendar.YEAR);
							int day=cal.get(Calendar.DAY_OF_MONTH);
							ddate.setText("Date: "+day+"/"+month+"/"+year);
							
							int second =cal.get(Calendar.SECOND);
							int minute =cal.get(Calendar.MINUTE);
							int hour =cal.get(Calendar.HOUR_OF_DAY);
							dtime.setText("Time: "+hour+":"+minute+":"+second);
							try {
								sleep(1000);
							} catch (InterruptedException e) {
								// TODO Auto-generated catch block
								e.printStackTrace();
							}
						}
					}
				};
				clock.start();
	}
	public Registration() {
		initialize();
		clock();
		random();
	}

	/**
	 * Initialize the contents of the frame.
	 */
	private void initialize() {
		frame = new JFrame();
		frame.getContentPane().setBackground(new Color(240, 248, 255));
		frame.setBounds(300, 100, 1350, 870);
		frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		frame.getContentPane().setLayout(null);
		
		JPanel panel = new JPanel();
		panel.setBorder(new BevelBorder(BevelBorder.LOWERED, new Color(175, 238, 238), new Color(175, 238, 238), new Color(176, 224, 230), new Color(176, 224, 230)));
		panel.setBackground(new Color(211, 211, 211));
		panel.setBounds(0, 0, 1332, 74);
		frame.getContentPane().add(panel);
		panel.setLayout(null);
		
		JLabel lblRegistration = new JLabel("  Registration");
		lblRegistration.setIcon(new ImageIcon(Registration.class.getResource("/airlineimages/regi.png")));
		lblRegistration.setFont(new Font("Tahoma", Font.BOLD, 30));
		lblRegistration.setBounds(23, 11, 286, 50);
		panel.add(lblRegistration);
		
		ddate = new JLabel("");
		ddate.setHorizontalAlignment(SwingConstants.CENTER);
		ddate.setFont(new Font("Times New Roman", Font.BOLD, 26));
		ddate.setBounds(402, 11, 320, 50);
		panel.add(ddate);
		
		dtime = new JLabel("");
		dtime.setHorizontalAlignment(SwingConstants.CENTER);
		dtime.setFont(new Font("Times New Roman", Font.BOLD, 26));
		dtime.setBounds(732, 11, 316, 49);
		panel.add(dtime);
		
		JLabel lblCostumerName = new JLabel("Costumer Name");
		lblCostumerName.setFont(new Font("Times New Roman", Font.BOLD, 20));
		lblCostumerName.setBounds(470, 273, 261, 74);
		frame.getContentPane().add(lblCostumerName);
		
		cname = new JTextField();
		cname.setFont(new Font("Times New Roman", Font.BOLD, 18));
		cname.setBounds(738, 297, 220, 25);
		frame.getContentPane().add(cname);
		cname.setColumns(10);
		
		JLabel lblGender = new JLabel("Gender");
		lblGender.setFont(new Font("Times New Roman", Font.BOLD, 20));
		lblGender.setBounds(470, 411, 261, 41);
		frame.getContentPane().add(lblGender);
		
		JRadioButton male = new JRadioButton("Male");
		male.setHorizontalAlignment(SwingConstants.CENTER);
		buttonGroup.add(male);
		male.setFont(new Font("Times New Roman", Font.BOLD, 16));
		male.setBounds(739, 411, 102, 48);
		frame.getContentPane().add(male);
		
		JRadioButton female = new JRadioButton("Female");
		female.setHorizontalAlignment(SwingConstants.CENTER);
		buttonGroup.add(female);
		female.setFont(new Font("Times New Roman", Font.BOLD, 16));
		female.setBounds(856, 411, 102, 48);
		frame.getContentPane().add(female);
		
		JLabel lblDateOfBirth = new JLabel("Date Of Birth");
		lblDateOfBirth.setFont(new Font("Times New Roman", Font.BOLD, 20));
		lblDateOfBirth.setBounds(470, 453, 220, 48);
		frame.getContentPane().add(lblDateOfBirth);
		
		JDateChooser Date = new JDateChooser();
		Date.setDateFormatString("dd MMM, yyyy");
		Date.setBounds(738, 468, 220, 25);
		frame.getContentPane().add(Date);
		
		JLabel lblPhoneNo = new JLabel("Phone No.");
		lblPhoneNo.setFont(new Font("Times New Roman", Font.BOLD, 20));
		lblPhoneNo.setBounds(470, 514, 220, 41);
		frame.getContentPane().add(lblPhoneNo);
		
		phno = new JTextField();
		phno.setFont(new Font("Times New Roman", Font.BOLD, 18));
		phno.setBounds(738, 522, 220, 25);
		frame.getContentPane().add(phno);
		phno.setColumns(10);
		
		JLabel lblAddress = new JLabel("Address");
		lblAddress.setFont(new Font("Times New Roman", Font.BOLD, 20));
		lblAddress.setBounds(470, 568, 220, 41);
		frame.getContentPane().add(lblAddress);
		
		address = new JTextField();
		address.setFont(new Font("Times New Roman", Font.BOLD, 18));
		address.setBounds(738, 576, 220, 25);
		frame.getContentPane().add(address);
		address.setColumns(10);
		
		JLabel lblPassword = new JLabel("Password");
		lblPassword.setFont(new Font("Times New Roman", Font.BOLD, 20));
		lblPassword.setBounds(470, 344, 261, 64);
		frame.getContentPane().add(lblPassword);
		
		upass = new JPasswordField();
		upass.setFont(new Font("Times New Roman", Font.BOLD, 18));
		upass.setBounds(738, 368, 220, 20);
		frame.getContentPane().add(upass);
		
		JButton btnSave = new JButton("Save");
		btnSave.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				
				PreparedStatement pst=null;
				Connection con=null;
				ResultSet rs=null;
				Statement stmt=null;
				
				try {
					
					if(cname.getText().trim().isEmpty() || upass.getText().isEmpty() || buttonGroup.isSelected(null))
					{
						JOptionPane.showMessageDialog(null,"Enter the data");
					}
					else
					{
					Class.forName("com.mysql.jdbc.Driver");
					con=DriverManager.getConnection("jdbc:mysql://localhost:3306/airline","root","root");
					stmt=con.createStatement();
					date =Date.getDate();
					sqldate =new java.sql.Date(date.getTime());
					
				
				Enumeration<AbstractButton> bg = buttonGroup.getElements();
				
				
					JRadioButton rdbtnMale = (JRadioButton) bg.nextElement();
					if(rdbtnMale.isSelected())
					{
					
						String sql="insert into NewRegistration(cid,cname,upass,gender,Date,phno,address) values ('"+cid.getText()+"','"+cname.getText()+"','"+upass.getText()+"','male','"+sqldate+"','"+phno.getText()+"','"+address.getText()+"')";
						stmt.executeUpdate(sql);
					}
					else
					{
						String sql="insert into NewRegistration(cid,cname,upass,gender,Date,phno,address) values ('"+cid.getText()+"','"+cname.getText()+"','"+upass.getText()+"','female','"+sqldate+"','"+phno.getText()+"','"+address.getText()+"')";
						stmt.executeUpdate(sql);
					}
					
					JOptionPane.showMessageDialog(null,"Registered sucessfully");
					HomePage.HomePage();
					
				}
				}
				catch(Exception e1)
				{
					System.out.println(e1);
				}
				}
			
				
				
			
		});
		btnSave.setFont(new Font("Times New Roman", Font.BOLD, 20));
		btnSave.setBounds(587, 705, 144, 64);
		frame.getContentPane().add(btnSave);
		
		JButton btnBack = new JButton("Back");
		btnBack.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				
				HomePage.HomePage();

			}
		});
		btnBack.setFont(new Font("Times New Roman", Font.BOLD, 20));
		btnBack.setIcon(new ImageIcon(Registration.class.getResource("/airlineimages/back1.png")));
		btnBack.setBounds(0, 782, 130, 41);
		frame.getContentPane().add(btnBack);
		
		JLabel lblCustumerId = new JLabel("Customer ID");
		lblCustumerId.setFont(new Font("Times New Roman", Font.BOLD, 20));
		lblCustumerId.setBounds(470, 206, 261, 64);
		frame.getContentPane().add(lblCustumerId);
		
		cid = new JTextField();
		cid.setHorizontalAlignment(SwingConstants.CENTER);
		cid.setFont(new Font("Times New Roman", Font.BOLD, 18));
		cid.setEditable(false);
		cid.setBounds(738, 219, 220, 41);
		frame.getContentPane().add(cid);
		cid.setColumns(10);
	}
}
