package com.corejava.AirlineResevation;

import java.awt.EventQueue;
import java.sql.*;

import javax.swing.JFrame;
import java.awt.Color;

import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JLabel;
import java.awt.Font;
import javax.swing.JTextField;
import javax.swing.JButton;

import com.corejava.AirlineResevation.Work.Function;

import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;

public class FlightDetails extends JFrame implements ActionListener {

	private JFrame frame;
	private JTextField fid;
	private JTextField fname;
	private JTextField source;
	private JTextField departure;
	private JTextField fclass;
	private JTextField fcahrges;
	private JTextField seat;
	private JTextField dest;
	private JTextField at;

	/**
	 * Launch the application.
	 */
	public void actionPerformed(ActionEvent ae)
	{
		Function f= new Function();
		ResultSet rs=null;
		String id= "fid";
		String name= "fname";
		String fsource= "source";
		String fdeparture = "departure";
		String ffclass = "fclass";
		String ffcharges = "fcahrges";
		String fseat = "seat";
		String fdest = "dest";
		String fat = "at";
		
		rs = f.find(fid.getText());
		try{
			if(rs.next())
			{
				fname.setText(rs.getString("fname"));
				source.setText(rs.getString("source"));
				departure.setText(rs.getString("departure"));
				fclass.setText(rs.getString("fclass"));
				fcahrges.setText(rs.getString("fcahrges"));
				seat.setText(rs.getString("seat"));
				dest.setText(rs.getString("dest"));
				at.setText(rs.getString("at"));
				
			}
			else{
				JOptionPane.showMessageDialog(null,"No data for this id");
			}
		}

		catch(Exception ex)
		{
			JOptionPane.showMessageDialog(null,ex.getMessage());
		}
	}
	public class Function
	{
		Connection con = null;
		ResultSet rs = null;
		PreparedStatement pst = null;
		public ResultSet find(String s){
			try{
			Class.forName("com.mysql.jdbc.Driver");
			con = DriverManager.getConnection("jdbc:mysql://localhost:3306/airline","root","root");
			pst = con.prepareStatement("select * from flightdetails where fid=?");
			pst.setString(1,s);
			rs = pst.executeQuery();
			}
			catch(Exception e)
			{
				JOptionPane.showMessageDialog(null,e.getMessage());
			}
			return rs;
	}
	}
	public static void main(String[] args) {
		new FlightDetails();
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					FlightDetails window = new FlightDetails();
					window.frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the application.
	 */
	public FlightDetails() {
		initialize();
	}

	/**
	 * Initialize the contents of the frame.
	 */
	private void initialize() {
		frame = new JFrame();
		frame.getContentPane().setBackground(Color.WHITE);
		frame.getContentPane().setLayout(null);
		
		JLabel lblFlightDetails = new JLabel("Flight Details");
		lblFlightDetails.setFont(new Font("Times New Roman", Font.BOLD, 22));
		lblFlightDetails.setBounds(314, 74, 169, 27);
		frame.getContentPane().add(lblFlightDetails);
		
		JLabel lblFlightid = new JLabel("FLIGHT-ID");
		lblFlightid.setFont(new Font("Times New Roman", Font.PLAIN, 15));
		lblFlightid.setBounds(67, 172, 81, 16);
		frame.getContentPane().add(lblFlightid);
		
		JLabel lblFlightName = new JLabel("FLIGHT NAME");
		lblFlightName.setFont(new Font("Times New Roman", Font.PLAIN, 15));
		lblFlightName.setBounds(67, 217, 116, 16);
		frame.getContentPane().add(lblFlightName);
		
		JLabel lblSource = new JLabel("SOURCE");
		lblSource.setFont(new Font("Times New Roman", Font.PLAIN, 15));
		lblSource.setBounds(67, 253, 97, 16);
		frame.getContentPane().add(lblSource);
		
		JLabel lblDeparture = new JLabel("DEPARTURE");
		lblDeparture.setFont(new Font("Times New Roman", Font.PLAIN, 15));
		lblDeparture.setBounds(67, 288, 97, 16);
		frame.getContentPane().add(lblDeparture);
		
		JLabel lblFlightClass = new JLabel("FLIGHT CLASS");
		lblFlightClass.setFont(new Font("Times New Roman", Font.PLAIN, 15));
		lblFlightClass.setBounds(67, 327, 116, 16);
		frame.getContentPane().add(lblFlightClass);
		
		JLabel lblFlightCharges = new JLabel("FLIGHT CHARGES");
		lblFlightCharges.setFont(new Font("Times New Roman", Font.PLAIN, 15));
		lblFlightCharges.setBounds(67, 369, 128, 16);
		frame.getContentPane().add(lblFlightCharges);
		
		JLabel lblSeats = new JLabel("SEATS");
		lblSeats.setFont(new Font("Times New Roman", Font.PLAIN, 15));
		lblSeats.setBounds(67, 409, 56, 16);
		frame.getContentPane().add(lblSeats);
		
		fid = new JTextField();
		fid.setBounds(296, 169, 322, 22);
		frame.getContentPane().add(fid);
		fid.setColumns(10);
		
		fname = new JTextField();
		fname.setBounds(296, 214, 322, 22);
		frame.getContentPane().add(fname);
		fname.setColumns(10);
		
		source = new JTextField();
		source.setBounds(296, 250, 116, 22);
		frame.getContentPane().add(source);
		source.setColumns(10);
		
		departure = new JTextField();
		departure.setBounds(296, 285, 116, 22);
		frame.getContentPane().add(departure);
		departure.setColumns(10);
		
		fclass = new JTextField();
		fclass.setBounds(296, 324, 116, 22);
		frame.getContentPane().add(fclass);
		fclass.setColumns(10);
		
		fcahrges = new JTextField();
		fcahrges.setBounds(296, 363, 116, 22);
		frame.getContentPane().add(fcahrges);
		fcahrges.setColumns(10);
		
		seat = new JTextField();
		seat.setBounds(296, 406, 116, 22);
		frame.getContentPane().add(seat);
		seat.setColumns(10);
		
		JLabel lblDestination = new JLabel("DESTINATION");
		lblDestination.setFont(new Font("Times New Roman", Font.PLAIN, 15));
		lblDestination.setBounds(504, 253, 114, 16);
		frame.getContentPane().add(lblDestination);
		
		JLabel lblArrivalTime = new JLabel("ARRIVAL TIME");
		lblArrivalTime.setFont(new Font("Times New Roman", Font.PLAIN, 15));
		lblArrivalTime.setBounds(504, 288, 114, 16);
		frame.getContentPane().add(lblArrivalTime);
		
		dest = new JTextField();
		dest.setBounds(680, 250, 116, 22);
		frame.getContentPane().add(dest);
		dest.setColumns(10);
		
		at = new JTextField();
		at.setBounds(680, 285, 116, 22);
		frame.getContentPane().add(at);
		at.setColumns(10);
		
		JButton btnAddFlight = new JButton("ADD FLIGHT ");
		btnAddFlight.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
try{
					
					Class.forName("com.mysql.jdbc.Driver");
					Connection con=DriverManager.getConnection("jdbc:mysql://localhost:3306/airline","root","root");
					Statement st=con.createStatement();
					String sql="insert into flightdetails (fid,fname,source,departure,fclass,fcahrges,seat,dest,at) values('"+fid.getText()+"','"+fname.getText()+"','"+source.getText()+"','"+departure.getText()+"','"+fclass.getText()+"','"+fcahrges.getText()+"','"+seat.getText()+"','"+dest.getText()+"','"+at.getText()+"')";
				    
					st.executeUpdate(sql);
					JOptionPane.showMessageDialog(null,"Flight added sucessfully...");
					
					/*if(rs.next())
						JOptionPane.showMessageDialog(null,"Registered Sucessfully...");
						else
							JOptionPane.showMessageDialog(null,"Fill proper data");*/
					con.close();
				}
				catch(Exception e)
				{
					System.out.println(e);
					}
			}
		});
		btnAddFlight.setBounds(124, 568, 116, 39);
		frame.getContentPane().add(btnAddFlight);
		
		JButton btnDeleteFlight = new JButton("DELETE FLIGHT");
		btnDeleteFlight.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				try{
					Class.forName("com.mysql.jdbc.Driver");
					Connection con=DriverManager.getConnection("jdbc:mysql://localhost:3306/airline","root","root");
					Statement st=con.createStatement();
					String sql="DELETE FROM flightdetails WHERE fid='"+fid.getText()+"'";
				    
					st.executeUpdate(sql);
					JOptionPane.showMessageDialog(null,"Flight deleted sucessfully...");
					
					/*if(rs.next())
						JOptionPane.showMessageDialog(null,"Registered Sucessfully...");
						else
							JOptionPane.showMessageDialog(null,"Fill proper data");*/
					con.close();
				}
				catch(Exception e)
				{
					System.out.println(e);
					}
			}
		});
		btnDeleteFlight.setBounds(341, 568, 128, 39);
		frame.getContentPane().add(btnDeleteFlight);
		
		JButton btnUpdateFlight = new JButton("UPDATE FLIGHT");
		btnUpdateFlight.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
try{
					
					Class.forName("com.mysql.jdbc.Driver");
					Connection con=DriverManager.getConnection("jdbc:mysql://localhost:3306/airline","root","root");
					Statement st=con.createStatement();
					String sql="update flightdetails set fname='"+fname.getText()+"',source='"+source.getText()+"',departure='"+departure.getText()+"',fclass='"+fclass.getText()+"',fcahrges='"+fcahrges.getText()+"',dest='"+dest.getText()+"', at='"+at.getText()+"',  seat='"+seat.getText()+"'  WHERE `fid`='"+fid.getText()+"' ";
				    
					st.executeUpdate(sql);
					JOptionPane.showMessageDialog(null,"Flight updated sucessfully...");
					
					/*if(rs.next())
						JOptionPane.showMessageDialog(null,"Registered Sucessfully...");
						else
							JOptionPane.showMessageDialog(null,"Fill proper data");*/
					con.close();
				}
				catch(Exception e)
				{
					System.out.println(e);
					}
			}
		});
		btnUpdateFlight.setBounds(545, 568, 128, 39);
		frame.getContentPane().add(btnUpdateFlight);
		
		JButton btnShow = new JButton("show");
		btnShow.setBounds(680, 168, 97, 25);
		btnShow.addActionListener(this);
		
		frame.getContentPane().add(btnShow);
		frame.setBounds(100, 100, 826, 757);
		frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
	
	}
	}
