package airline;

import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.ImageIcon;
import java.awt.Font;
import java.awt.Color;
import javax.swing.border.BevelBorder;

import com.teknikindustries.bulksms.SMS;

import javax.swing.JTextField;
import javax.swing.JButton;
import java.awt.event.ActionListener;
import java.sql.*;
import java.util.Calendar;
import java.util.GregorianCalendar;
import java.awt.event.ActionEvent;
import javax.swing.JLayeredPane;
import javax.swing.JSlider;
import java.awt.event.KeyAdapter;
import java.awt.event.KeyEvent;
import javax.swing.SwingConstants;


public class CancelTicket {

	private JFrame frame;
	private JTextField TicketID;
	private ResultSet rs ;
    private PreparedStatement ps;
    private JTextField mob1;
    private JLabel date;
    private JLabel time;
	/**
	 * Launch the application.
	 */
	
	public static void CancelTicket() {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					CancelTicket window = new CancelTicket();
					window.frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the application.
	 */
	
	private void clock()
	{
		
		Thread clock = new Thread()
				{
					public void run()
					{
						for(;;)
						{	
							Calendar cal=new GregorianCalendar();
							int month=cal.get(Calendar.MONTH)+1;
							int year=cal.get(Calendar.YEAR);
							int day=cal.get(Calendar.DAY_OF_MONTH);
							date.setText("Date: "+day+"/"+month+"/"+year);
							
							int second =cal.get(Calendar.SECOND);
							int minute =cal.get(Calendar.MINUTE);
							int hour =cal.get(Calendar.HOUR_OF_DAY);
							time.setText("Time: "+hour+":"+minute+":"+second);
							try {
								sleep(1000);
							} catch (InterruptedException e) {
								// TODO Auto-generated catch block
								e.printStackTrace();
							}
						}
					}
				};
				clock.start();
	}
	public CancelTicket() {
		initialize();
		clock();
	}

	/**
	 * Initialize the contents of the frame.
	 */
	private void initialize() {
		frame = new JFrame();
		frame.getContentPane().setBackground(new Color(240, 248, 255));
		frame.setBounds(500, 300, 754, 492);
		frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		frame.getContentPane().setLayout(null);
		
		JPanel panel = new JPanel();
		panel.setBorder(new BevelBorder(BevelBorder.LOWERED, new Color(135, 206, 250), new Color(135, 206, 250), new Color(135, 206, 250), new Color(135, 206, 250)));
		panel.setBackground(new Color(211, 211, 211));
		panel.setBounds(0, 0, 812, 76);
		frame.getContentPane().add(panel);
		panel.setLayout(null);
		
		JLabel lblTicketCancellation = new JLabel(" Ticket Cancellation");
		lblTicketCancellation.setFont(new Font("Tahoma", Font.BOLD, 30));
		lblTicketCancellation.setIcon(new ImageIcon(CancelTicket.class.getResource("/airlineimages/ticket.png")));
		lblTicketCancellation.setBounds(0, 13, 356, 54);
		panel.add(lblTicketCancellation);
		
		date = new JLabel("");
		date.setHorizontalAlignment(SwingConstants.CENTER);
		date.setFont(new Font("Times New Roman", Font.BOLD, 26));
		date.setBounds(354, 13, 197, 50);
		panel.add(date);
		
		time = new JLabel("");
		time.setHorizontalAlignment(SwingConstants.CENTER);
		time.setFont(new Font("Times New Roman", Font.BOLD, 26));
		time.setBounds(540, 13, 197, 49);
		panel.add(time);
		
		JLabel lblTicketNumber = new JLabel("Ticket Number");
		lblTicketNumber.setHorizontalAlignment(SwingConstants.CENTER);
		lblTicketNumber.setFont(new Font("Tahoma", Font.BOLD, 18));
		lblTicketNumber.setBounds(27, 124, 280, 41);
		frame.getContentPane().add(lblTicketNumber);
		
		TicketID = new JTextField();
		
		TicketID.setBounds(382, 124, 280, 41);
		frame.getContentPane().add(TicketID);
		TicketID.setColumns(10);
		
		JButton btnDelete = new JButton("Cancel");
		btnDelete.setIcon(new ImageIcon(CancelTicket.class.getResource("/airlineimages/close-icon.png")));
		btnDelete.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				
				try{
					Class.forName("com.mysql.jdbc.Driver");
					Connection con=DriverManager.getConnection("jdbc:mysql://localhost:3306/airline","root","root");
					Statement st=con.createStatement();
					String sql="DELETE FROM reserve WHERE TicketID='"+TicketID.getText()+"'";
				    st.executeUpdate(sql);
					JOptionPane.showMessageDialog(null,"Your Ticket with Ticket ID:\t"+TicketID.getText()+" is deleted sucessfully...\n Your Amount will be Refunded to you in 3 to 4 working days");
					UserMenu.UserMenu();
					SMS sms = new SMS();
	            	sms.SendSMS("guru16529", "Gmh@1999", "Your ticket with TicketID:"+TicketID.getText()+" is cancelled successfully\n Your amount will be refunded in 3 to 4 days", "91"+mob1.getText(), "https://bulksms.vsms.net/eapi/submission/send_sms/2/2.0\r\n");
					UserMenu.UserMenu();
	            	con.close();
				}
				catch(Exception e1)
				{
					JOptionPane.showMessageDialog(null,"Error Please check you details once again");
					}
			}
		});
		btnDelete.setFont(new Font("Times New Roman", Font.BOLD, 16));
		btnDelete.setBounds(276, 391, 185, 41);
		frame.getContentPane().add(btnDelete);
		
		JButton btnNewButton = new JButton("Back");
		btnNewButton.setFont(new Font("Times New Roman", Font.BOLD, 16));
		btnNewButton.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				UserMenu.UserMenu();
			}
		});
		btnNewButton.setIcon(new ImageIcon(CancelTicket.class.getResource("/airlineimages/back1.png")));
		btnNewButton.setBounds(0, 391, 139, 41);
		frame.getContentPane().add(btnNewButton);
		
		JLabel lblMobileNumber = new JLabel("Mobile Number");
		lblMobileNumber.setHorizontalAlignment(SwingConstants.CENTER);
		lblMobileNumber.setFont(new Font("Tahoma", Font.BOLD, 18));
		lblMobileNumber.setBounds(27, 186, 280, 41);
		frame.getContentPane().add(lblMobileNumber);
		
		mob1 = new JTextField();
		mob1.setColumns(10);
		mob1.setBounds(382, 186, 280, 41);
		frame.getContentPane().add(mob1);
	}
}
