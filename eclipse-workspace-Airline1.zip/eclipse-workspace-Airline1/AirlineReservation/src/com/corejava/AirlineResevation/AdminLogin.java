package com.corejava.AirlineResevation;

import java.awt.EventQueue;
import javax.swing.JFrame;
import java.awt.Color;
import javax.swing.JLabel;
import java.awt.Font;

import javax.swing.JOptionPane;
import javax.swing.JTextField;
import javax.swing.JButton;
import javax.swing.JPasswordField;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.Statement;

public class AdminLogin {

	private JFrame frame;
	private JTextField aname;
	private JPasswordField apass;

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					AdminLogin window = new AdminLogin();
					window.frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the application.
	 */
	public AdminLogin() {
		initialize();
	}

	/**
	 * Initialize the contents of the frame.
	 */
	private void initialize() {
		frame = new JFrame();
		frame.getContentPane().setBackground(Color.WHITE);
		frame.getContentPane().setLayout(null);
		
		JLabel lblAdminLogin = new JLabel("ADMIN LOGIN");
		lblAdminLogin.setFont(new Font("Times New Roman", Font.BOLD, 22));
		lblAdminLogin.setBounds(284, 58, 168, 27);
		frame.getContentPane().add(lblAdminLogin);
		
		JLabel lblAdminName = new JLabel("ADMIN NAME");
		lblAdminName.setFont(new Font("Times New Roman", Font.PLAIN, 15));
		lblAdminName.setBounds(155, 146, 116, 16);
		frame.getContentPane().add(lblAdminName);
		
		JLabel lblAdminPass = new JLabel("ADMIN PASS");
		lblAdminPass.setFont(new Font("Times New Roman", Font.PLAIN, 15));
		lblAdminPass.setBounds(157, 222, 101, 16);
		frame.getContentPane().add(lblAdminPass);
		
		aname = new JTextField();
		aname.setBounds(392, 143, 116, 22);
		frame.getContentPane().add(aname);
		aname.setColumns(10);
		
		JButton btnLogin = new JButton("LOGIN");
		btnLogin.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				
				try{
					
					Class.forName("com.mysql.jdbc.Driver");
					Connection con=DriverManager.getConnection("jdbc:mysql://localhost:3306/airline","root","root");
					Statement st=con.createStatement();
					String sql="Select * from admin where aname='"+aname.getText()+"' and apass='"+apass.getText().toString()+"'";
					ResultSet rs=st.executeQuery(sql);
					if(rs.next()){
						JOptionPane.showMessageDialog(null,"Login Sucessfully...");
						//MenuPage mp=new MenuPage();
						//mp.NewScreen5();
					}
						else{
							JOptionPane.showMessageDialog(null,"Incorrect username and password");}
					con.close();
				}
				catch(Exception e)
				{
					System.out.println(e);
					}
			}
		});
		btnLogin.setFont(new Font("Times New Roman", Font.PLAIN, 15));
		btnLogin.setBounds(284, 330, 97, 34);
		frame.getContentPane().add(btnLogin);
		
		apass = new JPasswordField();
		apass.setBounds(392, 219, 116, 22);
		frame.getContentPane().add(apass);
		frame.setBounds(100, 100, 794, 502);
		frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
	}
}
