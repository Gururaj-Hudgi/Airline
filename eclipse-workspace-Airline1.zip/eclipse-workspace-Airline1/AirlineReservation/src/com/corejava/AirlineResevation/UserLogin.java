package com.corejava.AirlineResevation;

import java.awt.EventQueue;
import java.sql.*;
import javax.swing.*;


import javax.swing.JFrame;
import java.awt.Color;
import javax.swing.JLabel;
import java.awt.Font;
import javax.swing.JTextField;
import javax.swing.JButton;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;

public class UserLogin {

	private JFrame frame;
	private JTextField cname;
	private JPasswordField upass;

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					UserLogin window = new UserLogin();
					window.frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the application.
	 */
	public UserLogin() {
		initialize();
	}

	/**
	 * Initialize the contents of the frame.
	 */
	private void initialize() {
		frame = new JFrame();
		frame.getContentPane().setBackground(Color.WHITE);
		frame.setBounds(100, 100, 828, 504);
		frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		frame.getContentPane().setLayout(null);
		
		JLabel lblUserLogin = new JLabel("User Login");
		lblUserLogin.setFont(new Font("Times New Roman", Font.BOLD, 22));
		lblUserLogin.setBounds(245, 37, 168, 34);
		frame.getContentPane().add(lblUserLogin);
		
		JLabel lblUserId = new JLabel("USER ID");
		lblUserId.setFont(new Font("Times New Roman", Font.PLAIN, 15));
		lblUserId.setBounds(111, 137, 75, 16);
		frame.getContentPane().add(lblUserId);
		
		JLabel lblUserPasswrd = new JLabel("USER PASSWORD");
		lblUserPasswrd.setFont(new Font("Times New Roman", Font.PLAIN, 15));
		lblUserPasswrd.setBounds(111, 205, 131, 16);
		frame.getContentPane().add(lblUserPasswrd);
		
		cname = new JTextField();
		cname.setBounds(373, 134, 116, 22);
		frame.getContentPane().add(cname);
		cname.setColumns(10);
		
		JButton btnLogin = new JButton("LOGIN");
		btnLogin.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
try{
					
					Class.forName("com.mysql.jdbc.Driver");
					Connection con=DriverManager.getConnection("jdbc:mysql://localhost:3306/airline","root","root");
					Statement st=con.createStatement();
					String sql="Select * from registration where cname='"+cname.getText()+"' and upass='"+upass.getText().toString()+"'";
					ResultSet rs=st.executeQuery(sql);
					if(rs.next()){
						JOptionPane.showMessageDialog(null,"Login Sucessfully...");
						//MenuPage mp=new MenuPage();
						//mp.NewScreen5();
					}
						else{
							JOptionPane.showMessageDialog(null,"Incorrect username and password");}
					con.close();
				}
				catch(Exception e)
				{
					System.out.println(e);
					}
			}
		});
		btnLogin.setFont(new Font("Times New Roman", Font.PLAIN, 15));
		btnLogin.setBounds(245, 331, 97, 34);
		frame.getContentPane().add(btnLogin);
		
		upass = new JPasswordField();
		upass.setBounds(373, 202, 116, 22);
		frame.getContentPane().add(upass);
	}
}
